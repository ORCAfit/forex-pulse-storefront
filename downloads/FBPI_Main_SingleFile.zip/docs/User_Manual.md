# Forex Bigger Picture Intelligence System — User Manual

| Field | Value |
|---|---|
| Project ID | FBPI-MT4-001 |
| Product | Forex Bigger Picture Intelligence System v1.0 |
| Platform | MetaTrader 4 (MT4), MQL4 build 600+ |
| Date | 2026-11-27 |
| Companion documents | `Installation_Guide.md`, `Session_Configuration_Guide.md`, `Risk_Management_Guide.md`, `Technical_Architecture.md`, `Data_Source_Register.md` |
| Spec | `FBPI-MT4-001-spec.md` v1.0 (source of truth) |

> **Verification status — read first.** This indicator has been **statically audited only**: its behaviour was established by reading the source code. It has **never been compiled** (no `.ex4` exists — see the Installation Guide) and **never run in a live MT4 terminal**. Nothing in this manual describes a feature as "verified live in MT4", because no such verification exists yet. Where this manual says "the indicator does X", it means "the source code as written does X". If live behaviour differs, the code is the authority and the manual needs correcting.

> **The one rule that governs everything else:** this is an **analytical indicator only. It never trades.** It never places, modifies, or closes an order. There is no `OrderSend`, `OrderModify`, or `OrderClose` anywhere in the code. Every trade decision is yours, made outside the indicator, after human review.

---

## 1. What the indicator does — and what it does NOT do

### What it does

FBPI is a top-down analytical funnel. It takes you from the big picture to a single trade idea, in five stages, covering 23 layers:

1. **Global context (Layers 1–7)** — the macroeconomic environment, central-bank policy, financial conditions, and cross-market context (gold, oil, indices, futures).
2. **Higher-timeframe market structure (Layers 8–11)** — quarterly, monthly, weekly, and daily structure for the chart symbol, plus a multi-timeframe alignment table.
3. **Session intelligence (Layers 12–14)** — Asian / London / New York sessions, opening ranges, and an intraday auction classification built only from measurable price behaviour.
4. **Volume and liquidity (Layers 15–20)** — a tick-volume profile (POC, value area), key levels with historical touch probabilities, liquidity-sweep detection, and honest labels where MT4 has no real data (order book, true order flow).
5. **Confirmation, risk, and execution readiness (Layers 21–23)** — a six-factor confirmation score, a risk plan (position size, spread and commission cost, reward-to-risk), and a six-state execution-readiness status that ends at **READY FOR HUMAN REVIEW** — never at an order.

It shows all of this on one dark dashboard (Sections A–E plus a scoreboard panel), draws the key levels on the chart, records its forecasts in CSV files, and can alert you to 11 kinds of event.

### What it does NOT do

| It does NOT… | What that means in practice |
|---|---|
| Place, modify, or close trades | There is no order function in the system. `READY FOR HUMAN REVIEW` means *you* decide, in MT4 or with your broker, outside the indicator. |
| Generate signals automatically | There is no "signal". There is a *setup* (direction + entry + stop + target) assembled from the confirmation score and the nearest levels — and only when the code can determine a valid stop. A setup is an analytical suggestion to review, not a call to trade. |
| Predict the market | A historical touch probability (e.g. "72%") is a count of how often a level was touched in the past. It is not a prediction that price will touch it today, and it is never a guarantee. See §7. |
| Show consolidated volume | Spot Forex has no single centralised volume feed. Everything volume-related is **broker tick volume**, labelled as such. See §6. |
| Show a real order book or true order flow | MT4 does not provide a consolidated Forex order book. The dashboard says `ORDER BOOK UNAVAILABLE` and labels flow as `ESTIMATED TICK ACTIVITY`. See §8. |
| Know the macroeconomy on its own | Layers 1–3 (global economy, monetary policy, financial conditions) have no live feed in MT4. They are empty until **you** type the values in. See §4. |
| Read your broker account | The daily loss so far (`InpDailyLossSoFar`) is a number you type in. The indicator never reads your account balance, equity, or open positions. The "capital" it plans with is your paper capital input (`InpPaperCapital`, default $5,000), not your real account. |
| Recommend increasing risk to recover losses | It never does this. A risk-rule violation rejects the plan (`REJECTED — RISK RULE VIOLATION`) and the only compliant response is to reduce risk or skip the trade. |
| Use future information | Probabilities are computed from completed days only, with the forecast level reconstructed from days *before* the forecast day. Today is excluded from every lookback loop. See §7. |
| Hide missing data | Missing data is shown in grey as `DATA UNAVAILABLE`, `ORDER BOOK UNAVAILABLE`, or `INSUFFICIENT DATA (N=…)`. A missing value is never shown as zero and never silently replaced. |

### The analytical funnel, in one paragraph

Start at the top of the dashboard and work down. Section A tells you whether the global backdrop even supports the idea. Section B tells you which way the higher timeframes point. Section C tells you where you are in the trading day and what the sessions have already done. Section D tells you where the levels and liquidity are. Only then does Section E ask whether the confirmation score, the risk plan, and the execution status line up — and even when they do, the last step is still yours.

---

## 2. The 23 layers in plain language

You do not need to memorise the layer numbers, but they are the vocabulary the dashboard and this manual share. Each layer is one question the indicator tries to answer — or honestly says it cannot.

### Global context (Layers 1–7)

| Layer | Plain-language question | Where the answer comes from |
|---|---|---|
| 1 — Global Economy | Is the world economy expanding, contracting, or mixed? What are growth, inflation, unemployment doing? | **You type it in.** No live feed exists in v1. Until you enter values, the whole layer is `DATA UNAVAILABLE`. |
| 2 — Monetary Policy | What is each central bank's policy rate, what did it just do, and what is expected next? What is the rate gap between the two currencies in this pair? | **You type the rates in** (`InpRate_USD` etc.). The **differential** (base rate minus quote rate, in percentage points) is the one native calculation in this layer — it is computed only when both rates are present, and is `DATA UNAVAILABLE` if either is missing. |
| 3 — Financial Conditions | Are credit and funding tight or easy? Is dollar liquidity ample or tight? Is risk appetite on or off? Is the US 10-year yield entered? | **You type it in** (or it is derived from the Layer 2 rates you entered). MT4 does not possess this information natively. |
| 4 — Global Markets | What are gold, oil, and the major indices doing today? | **Your broker's symbols.** Gold (`InpGoldSymbol`, default `XAUUSD`), oil (`InpOilSymbol`, default `XTIUSD`), indices (`InpIndexSymbols`, default `US30,SPX500,NAS100`). Price, daily change %, daily high/low are calculated from broker bars. A symbol your broker does not offer is `DATA UNAVAILABLE` for that row — it is never guessed from a similar name. Correlations are Pearson correlations of daily closes over `InpCorrLookback` (default 20) days, shown with the warning that correlation is not permanent and not causal. |
| 5 — Asset Class | Which asset classes are strengthening or weakening — equities, fixed income, FX, commodities, precious metals, energy? | **Calculated** by ranking the daily % change of the Layer 4 proxies. Shown as contextual ranking only, never as a causal claim. A class with no proxy is omitted from the ranking, not given a zero. |
| 6 — Market Index | For each configured index: price, daily change, trend, daily high/low, relative performance. | **Your broker's symbols** (`InpIndexSymbols`). Broker naming differs (`US30` vs `DJ30`) — you must configure the exact symbol your broker uses. |
| 7 — Futures Contract | What are futures doing (e.g. NQ, ES, currency futures)? | **`DATA UNAVAILABLE` by default.** There is no futures feed in v1 (no WebRequest, no DLL). If you configure broker futures symbols (`InpFuturesSymbols`), they are shown in a separate row labelled **"broker CFD, not exchange futures"**. Spot, CFD, and futures prices are never merged into one price. |

### Higher-timeframe structure (Layers 8–11)

All four layers are calculated natively from **H1 bars** — an H1 bar's high/low are the true extremes of that hour, so scanning H1 bars gives exact extremes for any window.

| Layer | What is calculated | How to read it |
|---|---|---|
| 8 — Quarterly | Current quarter high/low/open/close, current quarterly range, price position within the range (%), quarterly trend. | Position ≥ 66.7% of the range = **upper range**; ≤ 33.3% = **lower range**; otherwise **midrange**. Range vs prior-quarter range > 110% = **expanding**; < 90% = **contracting**. |
| 9 — Monthly | Current month high/low/open/close, previous month high/low, monthly range, directional structure. | Structure comes from the last 3 monthly closes: higher highs + higher lows = bullish; lower lows + lower highs = bearish; otherwise consolidation. A close beyond the prior month's high/low is a breakout — confirmed only on the monthly close. Fewer than 3 monthly closes = `INSUFFICIENT DATA`. |
| 10 — Weekly | Previous week high/low/close, current week open/high/low, weekly range, expansion/contraction. | The trading week is Monday 00:00 UTC to Sunday 21:00 UTC (the cutoff). Expansion/contraction is judged against the prior week and against the 12-week average range (`InpWeeklyLookback` = 12). |
| 11 — Daily | Previous Day High/Low/Close/Open (PDH/PDL/PDC/PDO), current Day Open (DO), current day high/low, daily range, Average Daily Range (ADR). | ADR is the mean daily range over `InpADRPeriod` (default 14) completed days. The dashboard shows the current day's range as a % of ADR, and the distance to PDH/PDL in pips. Daily structure comes from daily closes. |

**Final vs provisional.** A level is *final* only when its source window has closed; until then it is the running extreme (the highest high / lowest low so far). A level that has not started yet (e.g. a session that has not opened) is invalid and shown as `DATA UNAVAILABLE`, never as zero.

### Session intelligence (Layers 12–14)

| Layer | What is calculated |
|---|---|
| 12 — Trading Session | Asian (default 00:00–09:00 UTC), London (07:00–16:00 UTC), New York (12:00–21:00 UTC) — all configurable. For each: open, high, low, range, direction. London breakout vs the Asian high/low; New York continuation or reversal vs the London high/low; the London–New York overlap (12:00–16:00 UTC default) reported as its own state. Up to 3 custom sessions can supplement the standard three. Full detail is in the Session Configuration Guide. |
| 13 — Opening Range | The high, low, and midpoint of the first `InpOpeningRangeMinutes` (15, 30, or 60; default 30) after the open of `InpOpeningRangeSession` (default New York). Independent London and New York ranges are also computed when `InpShowLondonOR` / `InpShowNewYorkOR` are true. Breakout above/below, failed breakout, retest (held/failed), and rejection are classified on **closed M15 bars only**. |
| 14 — Intraday Auction | One classification of current intraday behaviour: **Trend, Balance, Consolidation, Expansion, Reversal, Failed Breakout, Range Rejection**, or **Unknown** (fewer than 10 closed bars — the minimum is a fixed constant, `FBPI_AUCTION_MIN_BARS` = 10; there is no input for it). The classification uses only measurable behaviour: candle range vs ATR(14) on the chart timeframe, higher-high/lower-low sequences over the last 10 closed bars, closing-price location within the bar's range, range expansion (current range > 1.5× the 20-bar mean range), and breakout persistence. The dashboard shows the measurements behind the classification (ATR, range ratio, close location %, HH/HL/LH/LL counts, closed-bar count). It never claims to identify institutional intent from price movement alone. |

### Volume and liquidity (Layers 15–20)

| Layer | What is calculated | Honesty label |
|---|---|---|
| 15 — Volume Profile | A price-binned profile from **broker tick volume** on H1 bars: `InpProfileBins` (default 24) equal-width bins across the scope's high–low; each bar's tick volume is allocated across the bins its range covers; bin volumes sum exactly to total tick volume. POC = centre of the bin with the greatest tick volume (ties go to the lowest-price bin). High-volume nodes = bins ≥ 150% of mean bin volume; low-volume nodes = bins ≤ 50%. Scopes: daily, session, weekly. | The profile heading always carries its source label — **"tick volume"** by default. It is never called consolidated volume. |
| 16 — Value Area | From the profile: the smallest contiguous price range around the POC containing `InpValueAreaPct` (default 70%) of total tick volume → VAH (top) / VAL (bottom). Built by starting at the POC bin and adding the adjacent bin with the larger tick volume (ties go up) until the percentage is reached. Price vs value: above VAH / inside / below VAL. Acceptance = 3 consecutive closed bars inside the value area after being outside; rejection = a closed bar's wick beyond VAH/VAL with its close back inside; migration = POC moved by more than one bin vs the prior scope's POC. (The 3-bar acceptance count is a fixed constant, `FBPI_VP_VA_CONFIRM_BARS` = 3; there is no input for it.) | Same tick-volume label as Layer 15. |
| 17 — Key Levels | 28 level kinds (see §7): quarterly/monthly/weekly/daily, session, overnight, opening-range, and POC/VAH/VAL levels, each with price, distance from current price in pips, and — for 7 of them — a historical touch probability. Monitored for breakout, rejection, liquidity sweep, and retest. | Probabilities always carry their sample size N and Wilson interval; see §7. |
| 18 — Order Book | Nothing in v1. | **`ORDER BOOK UNAVAILABLE`** — always, in grey. Resting orders are never invented from candlestick patterns. |
| 19 — Order Flow | An *estimate* only: delta proxy per bar = tick volume × sign(close − open); cumulative delta is the running sum over up to 500 closed bars; imbalance = (up-tick-volume − down-tick-volume) / total tick volume per price bin. | **`ESTIMATED TICK ACTIVITY`** — never presented as verified institutional order flow. True bid/ask flow exists only as a record shape for a future external feed; no such feed is configured in v1. |
| 20 — Footprint Candle | The same tick-volume estimate, per price bin. | **`ESTIMATED TICK ACTIVITY`** — not a true bid/ask footprint. |

### Confirmation, risk, execution (Layers 21–23)

| Layer | What it does |
|---|---|
| 21 — Confirmation | Six weighted factors scored 0–100 (see §9). The score is an **analytical score, not an empirically established probability** — the dashboard carries that footnote in Section E. Missing data scores **0** for that factor, never a positive score. |
| 22 — Risk Plan | From your paper capital and risk %: risk amount, stop distance, position size (rounded **down** to the broker lot step), pip value from broker contract specs, spread cost, commission, potential profit, reward-to-risk. Violations reject the plan. Full detail is in the Risk Management Guide. |
| 23 — Execution Readiness | Assembles the setup (pair, direction, entry, stop, target, size, risk %, R:R, confirmation score, session, key level, liquidity event, rationale) and derives one of six statuses (see §10). Contains no button and no order function. |

---

## 3. Reading the dashboard

The dashboard is one fixed-width panel (**470 px** wide), dark by default (`InpTheme` = `FBPI_THEME_DARK`; a light theme exists but the dark theme is the only fully designed one), with white text, gold accents, green for bullish, red (tomato) for bearish, gold for caution, and grey for unavailable data. It is positioned by `InpDashCorner` (default top-left, `CORNER_LEFT_UPPER`) plus `InpDashX` = 10, `InpDashY` = 15.

**Controls (in the title bar):**

- **Drag to move:** drag the panel by its title bar/background. The panel is content-driven in height (it grows/shrinks with its rows) — there is no free resize.
- **Minimise / expand:** the `[-]` / `[+]` toggle in the title bar collapses the panel to its title bar.
- **Close:** the close control in the title bar hides the dashboard. Re-attach the indicator to bring it back.
- **Scoreboard panel:** a separate panel sits below the dashboard (8 px gap), with its own `[-]` / `[+]` toggle and an **[export CSV]** control that writes the scoreboard summary (see §11).

**Refresh:** the dashboard redraws on a timer every `InpRefreshSeconds` (default 5 s, allowed 1–300; 0 is **not** supported — there is no "no timer" mode) and on every new bar. Between recalculations, ticks refresh only the live price labels. Probabilities are recomputed only on a new bar, at forecast time, or when an input changes — never on a timer tick.

**Hiding sections:** there is no per-section hide switch in v1. You can hide the whole dashboard (`InpShowDashboard` = false) or hide families of level lines (see §7). The architecture's "hide, reposition, or resize panels" is implemented as: reposition by dragging; resize is content-driven only.

### Section A — Global Context (Layers 1–7)

One row per item. What you will see on a first run — and what it means:

- **Rate differential `<BASE>/<QUOTE>`:** e.g. `Rate differential EUR/USD: 1.75 pp (EUR 4.00% - USD 2.25%) | Calculated`. If either rate is missing: `DATA UNAVAILABLE (enter both policy rates)`. The differential is base minus quote, in percentage points.
- **One row per central bank** (Fed, ECB, BoE, BoJ, SNB, BoC, RBA, RBNZ): `USD Federal Reserve: 4.00% (prev 4.25%) | Hold 2026.09.17 | Exp: Cut | Next: 2026.12.10 | Current` — or `DATA UNAVAILABLE (no manual rate entered)` when no rate has been entered. A value older than its max age is shown in caution colour with a **STALE DATA** warning (rates: 90 days, `InpRateMaxAgeHours` = 2160; other macro values: 7 days, `InpMacroMaxAgeHours` = 168).
- **Macro observations** (global condition, growth, inflation, unemployment, trade note, risk sentiment, bond yield, credit/funding conditions, dollar liquidity, risk appetite, stress note, context note): each shows its entered value with its source, or `DATA UNAVAILABLE`. The free-text context note row is hidden when empty.
- **Cross-market rows:** gold, oil, up to 3 indices, then any extra cross symbols you configured. Each shows price, daily change %, daily high/low — or `DATA UNAVAILABLE` if your broker does not offer that symbol.
- **Futures row:** `Futures: DATA UNAVAILABLE (no broker futures symbols configured)` by default. If you configured `InpFuturesSymbols`, each row is labelled **"(broker CFD, not exchange futures)"**.

**How to read Section A:** if most rows are grey, the indicator is telling you it has no global context — because nobody has entered it. That is a fact about your setup, not a market view. Do not trade "the global backdrop" until you have entered the values (see §4).

### Section B — Market Structure (Layers 8–11)

- **Quarterly:** `Quarterly: price in upper range | Q 1.0500–1.1200` (or `DATA UNAVAILABLE (insufficient history)`).
- **Monthly / Weekly / Daily:** one row each, e.g. `Monthly (MN1): Bullish | Higher high`.
- **Previous highs/lows:** `Prev month H/L: … / …`, `Prev week H/L: … / …`, `Prev day H/L/C: … / … / …`, `Day open: …`. A price that cannot be computed shows as `—` in that row (the dashboard formats an invalid price as a dash).
- **ADR:** `ADR (14d): 82.4 pips | Day range 63% of ADR`.
- **Market location:** `above PDH`, `below PDL`, or `inside prev-day range`.
- **Multi-timeframe alignment table** (6 rows — MN1, W1, D1, H4, H1, M15):

```
TF   | Direction | Structure
MN1  | Bullish   | Higher high
W1   | Bullish   | Higher low
D1   | Bearish   | Pullback
H4   | Bearish   | Lower high
H1   | Neutral   | Consolidation
M15  | Bullish   | Confirmation pending
```

These are *illustrative values only* — the table is never hardcoded; each row is computed from the last two completed closes plus the HH/HL or LL/LH structure on that timeframe. A timeframe with fewer than 20 bars shows `— | insufficient bars`. (The underlying table holds 9 timeframes, M1–MN1; the dashboard displays 6 of them.)

- **Watchlist scan** (only if `InpEnableWatchlistScan` = true — it is **false** by default): one line per scanned pair, e.g. `EURUSD 1.0850 | 12.3 pips above PDH`, `GBPUSD 1.2700 | inside prev-day range`, or `AUDJPY: symbol not offered by broker`. The scan compares each pair's current Bid with its previous trading day's high/low on H1. It scans at most `InpScanMaxPairs` (default 15) pairs.

### Section C — Session Intelligence (Layers 12–14)

- **Current session:** `Current session: New York (market open)` — or `(market closed — no recent bar)`. "Market open" requires a current bar within the last 10 minutes; the clock alone is not enough, so a Saturday will not claim a session is active. Session precedence when windows overlap: custom window first, then the London–New York overlap, then New York, then London, then Asian.
- **One row per session** (Asian blue, London orange, New York purple): `London: H 1.0870 L 1.0820 | 50.0 pts | Bullish | Active` — plus `| Final` once the session window has closed. A session that has not started yet says `not started — no bars yet`.
- **Custom sessions:** one row each, only when configured.
- **Overlap:** `Overlap (London/New York): 32.0 pts | Bullish` (shown only when the overlap window is valid).
- **Overnight:** `Overnight H/L (21:00–07:00 UTC): 1.0860 / 1.0810`. This is the genuine overnight window, **not** the Asian session high/low — a distinction the previous FLR indicator got wrong and this one corrects.
- **Opening ranges:** `Opening range (New York, 30m): H … L … Mid … | Breakout up (sustained)` plus separate London and New York OR rows when `InpShowLondonOR` / `InpShowNewYorkOR` are true. Possible states: `Breakout up/down`, `Breakout up/down (sustained)`, `Failed breakout up/down`, `Retest held`, `Retest failed`, `Rejection of range high/low`.
- **Auction:** `Auction: Trend` followed by an evidence row: `ATR … | Range ratio 1.62 | Close loc 78% | HH 3 HL 2 LH 1 LL 0 | 10 closed bars`. If fewer than 10 closed bars: `Auction: Unknown — fewer than 10 closed bars`.
- **Session interactions:** `London broke Asian high: yes | broke Asian low: no`, `NY vs London: …`, `NY continuation: yes | NY reversal: no`.

### Section D — Liquidity and Volume (Layers 15–20)

The heading itself says **"D — LIQUIDITY AND VOLUME (tick volume)"** — the honesty label is in the title.

- **POC / VAH / VAL:** `POC 1.0845 | VAH 1.0870 | VAL 1.0820 (70% value area, Tick volume)` — or `DATA UNAVAILABLE (fewer than 10 bars in scope)`. Followed by: `Price vs value: Inside value | Value-area accepted: no | Rejected: no`.
- **Session / weekly POC:** `Session POC: … | Weekly POC: …` (`—` when not computable).
- **Key levels (10 rows):** PDH, PDL, PDC, PWH, PWL, ASH, ASL, ORH, ORL, POC. Each row: abbreviation, price, distance in pips above/below current price, `TOUCHED TODAY` when applicable, and the probability text — e.g. `PDH 1.0870 | 12.5 pips above | 72.0% (N=100, Wilson 62.4–80.6)`. (That percentage is the *format* of the display, not a result.) A level that is not valid shows `DATA UNAVAILABLE`.
- **Sweeps / breakouts today:** `Sweeps today: 2 | Breakouts today: 1`, then up to the 3 most recent events with time, kind, level, price, and excursion size in points — or `No sweep / breakout events recorded yet`. Counters reset at the trading-day rollover.
- **Volume activity:** `Daily tick volume: 48210 (Tick volume) | Session tick volume: 12340`. Never "consolidated volume".
- **Order book:** `Order book: ORDER BOOK UNAVAILABLE` (grey).
- **Order flow:** `Order flow: ESTIMATED TICK ACTIVITY` followed by the delta line, e.g. `ESTIMATED TICK ACTIVITY - Delta(20 bars): 1240 | Cum. delta: 8560 (tick-volume units)`.

### Section E — Execution Readiness (Layers 21–23)

- **Bias + score:** `Bias: Bullish | Score 72/100 (Moderate)`.
- **Six factor rows** (see §9 for the rules). Every factor is always shown, in the form `Higher-Timeframe Alignment 20/20 pts - MN1+W1+D1 agree Bullish`. A factor with no data shows `0 pts` in grey with evidence `No data` (or a specific reason such as `No key level within 5.0 pips`).
- **Entry / stop / target:** `Entry 1.0850 | Stop 1.0830 | Target 1.0890`, then `Setup session: New York | Key level: PDH | Liquidity: Sweep up`. When no setup exists but a manual plan was entered, the manual plan's entry/stop/target are shown instead. When neither exists: `No setup identified and no manual plan entered (InpPlanEntry / InpPlanStop / InpPlanTarget are 0)`.
- **Size / risk / R:R:** `Size 0.12 lots | Risk 0.50% ($25.00 USD) | R:R 1:2.40`, then `Stop distance: 20.0 pips | Spread cost: $1.44 USD | Commission: $0.00 USD`.
- **Execution status:** one of the six statuses (§10), coloured green only for `READY FOR HUMAN REVIEW`, red for `REJECTED — RISK RULE VIOLATION`, gold otherwise.
- **Warning line** (only when a rule is violated): `WARNING: …` with the specific reason.
- **Rationale:** the first line of the setup's rationale (truncated at 110 characters on the dashboard).
- **Footnotes (always shown):** `Confirmation scores are analytical, not probabilities.` and `Analytical only — no automatic trading. Human approval required.`

### Scoreboard panel (spec §12)

Below the dashboard, the scoreboard panel shows the historical record of the indicator's own forecasts:

- Before any forecast has been finalised: `No finalised scoreboard rows yet — forecasts are captured daily; rows appear after the first finalisation.`
- Afterwards: `Finalised rows: 214 | Touches: 148 | Hit rate: 69.2%`, then `Mean forecast: 68.4% | Mean Brier: 0.2140 (lower is better; 0 = perfect)`, then (when computable) `Brier skill vs climatology: 0.083 | Forecast accuracy is NOT trading profitability.`

That last sentence is the point of the panel: it measures **forecast accuracy** (did the level get touched as often as the forecast percentage implied?), not trading profitability. A well-calibrated 70% forecast that touches 70% of the time scores well even if no trade was ever taken — and a profitable trade taken against a bad forecast does not improve the score. Full detail is in §11.

### Chart level lines

When `InpShowLevelLines` = true (default), every valid level is drawn as a horizontal line with an abbreviation + price label at the current bar. PDH, PDL, and POC use width 2; all other levels width 1. Families can be hidden with `InpShowQuarterly` / `InpShowMonthly` / `InpShowWeekly` / `InpShowDaily` (session, opening-range, and profile levels have no family switch in v1 — they follow only the master switch). Sweep and breakout events are marked with arrows at the excursion bar: up-arrow (code 234, green) for upward events, down-arrow (code 233, red) for downward events; at most the 10 most recent are drawn. Alert-triggered sweeps also draw a gold arrow at the current price.

---

## 4. Manual macro inputs — entering central-bank rates and global context

Layers 1–3 and 7 have no live feed. They are filled by hand, in the Inputs tab, in the **MACRO** group. The rules for every manual value:

- **Numbers use `-999.0` to mean "not entered".** That is the default for every manual double input (`InpRate_USD`, `InpGlobalGrowthPct`, `InpBondYield10Y`, …). Do not type 0 to mean "unknown" — 0 is a real value (a 0% rate) and would be displayed as one. Leave `-999.0` unless you have a real number.
- **Text uses `""` (empty) to mean "not entered".** Leave a text input empty unless you have a real value.
- **Dates use `yyyy.mm.dd`** — e.g. `2026.12.10`. A date that does not parse is rejected by the macro module's validation (a rate must be −5…+25% and a date must parse; invalid values are treated as not entered and printed in the Experts tab).
- **Staleness:** a manual value older than its max age is flagged `STALE` and shown in caution colour with a `STALE DATA` warning — it never silently becomes current. Policy rates: 90 days (`InpRateMaxAgeHours` = 2160). Other macro values: 7 days (`InpMacroMaxAgeHours` = 168). The age is measured from when the value was entered (the observation is stamped with the entry time).
- **Changing a value requires re-attaching or editing inputs.** Inputs are read at attach time. To update a rate, open the Inputs tab (right-click chart → Indicators List → FBPI_Main → Edit), change the value, and click OK.

### What to enter, field by field

**Global economy (Layer 1):**

| Input | What to type | Example |
|---|---|---|
| `InpGlobalCondition` | `Expansion`, `Contraction`, `Mixed`, or `Unknown` | `Mixed` |
| `InpGlobalGrowthPct` | Global GDP growth, % | `3.1` |
| `InpGlobalInflationPct` | Global CPI, % | `2.4` |
| `InpGlobalUnemploymentPct` | Global unemployment, % | `5.0` |
| `InpGlobalTradeNote` | Free text on the trade balance direction | `US deficit widening` |
| `InpRiskSentiment` | `Risk-on`, `Risk-off`, or `Neutral` — labelled as your judgement | `Risk-on` |
| `InpMacroContextNote` | Free-text one-line summary of the macro backdrop | `Fed on hold; ECB easing bias` |

**Monetary policy (Layer 2) — the same six fields per currency** (`USD, EUR, GBP, JPY, CHF, CAD, AUD, NZD`):

| Input pattern | What to type |
|---|---|
| `InpRate_<CCY>` | Current policy rate, % (e.g. `InpRate_USD` = `4.00`) |
| `InpPrevRate_<CCY>` | Previous policy rate, % |
| `InpDecision_<CCY>` | `Hike`, `Hold`, or `Cut` |
| `InpDecisionDate_<CCY>` | Date of the latest decision, `yyyy.mm.dd` |
| `InpExpectedDir_<CCY>` | `Hike`, `Hold`, `Cut`, or `Unknown` |
| `InpNextMeeting_<CCY>` | Date of the next scheduled announcement, `yyyy.mm.dd` |

**Financial conditions (Layer 3):**

| Input | What to type |
|---|---|
| `InpBondYield10Y` | US 10-year yield, % (e.g. `4.20`) |
| `InpCreditConditions` | `Tightening`, `Neutral`, `Easing`, or `Unknown` |
| `InpFundingConditions` | Same four options |
| `InpDollarLiquidity` | `Ample`, `Neutral`, `Tight`, or `Unknown` |
| `InpRiskAppetite` | `Risk-on`, `Neutral`, or `Risk-off` |
| `InpStressNote` | Free text on financial stress |

**Worked example — the rate differential.** Suppose you enter `InpRate_EUR` = `2.15` and `InpRate_USD` = `4.00`. On a EURUSD chart, Section A shows: `Rate differential EUR/USD: -1.85 pp (EUR 2.15% - USD 4.00%) | Calculated`. The negative sign means the quote currency's rate is higher. If you enter only one of the two rates, the differential is `DATA UNAVAILABLE` — the indicator will not compute a differential from a single rate, and it will not show 0.

**What the indicator will never do with your inputs:** it will not fetch a rate from the internet, it will not update a rate when a central bank meets, and it will not warn you that a rate is out of date except through the staleness flag above. Keeping Layer 2 current is a manual discipline — update the rates after each policy decision, or accept that Section A goes stale (and says so).

---

## 5. The daily workflow

This is the intended rhythm of use. It mirrors the indicator's own daily cycle (capture at day start, finalise at the next day start).

### At the start of the trading day (00:00 UTC)

1. **Check Section A.** Are the rates and macro values current? If a row says `STALE DATA`, update it now (see §4) — a stale backdrop is worse than an empty one, because it looks like information.
2. **Read Section B top-down.** Quarterly position → monthly → weekly → daily → ADR. Note where price sits (above PDH, inside the previous day's range, etc.) and whether the MTF table agrees or conflicts.
3. **Read Section C.** Which session is next, and what did the sessions so far do? Note the overnight high/low and the Asian range before London opens.
4. **Read Section D.** Which levels are near price? What are their probabilities and sample sizes? Has anything been swept already today?
5. **Note the forecast capture.** At the day start the indicator freezes today's forecast for the 7 probability levels (PDH, PDL, PDC, ONH, ONL, ORH, ORL) and writes it to `FBPI_Forecasts_<SYMBOL>.csv`. The frozen forecast is never revised during the day, even if price moves — that is what makes the scoreboard honest. If MT4 was off at the day start, the forecast is captured late from the bars available at the original forecast time, and the lateness is logged (see §11).

### During the day

- **Let the dashboard refresh.** It recalculates on each new bar and refreshes live prices every `InpRefreshSeconds` (default 5 s). You do not need to do anything.
- **Watch for alerts** (see §10 for the 11 types). An alert is a prompt to look at the chart, not an instruction to trade.
- **Do not re-interpret a probability intraday.** The probability for PDH was frozen at the day start from history before today. Price approaching PDH at 14:00 does not change the 72% — the 72% was always "in about 72 of 100 past days like this, the level was touched before the 21:00 UTC cutoff". The Wilson interval next to it is the honest statement of how uncertain that number is.
- **If a sweep fires**, check Section D: the event, the level, the excursion size, and whether the close came back inside (sweep) or stayed beyond (breakout). The sweep/breakout counters for the day are in Section D.

### At the end of the trading day (21:00 UTC cutoff) / next day start

1. **Finalisation happens automatically** at the next trading-day start (`CheckNewDay`): yesterday's frozen forecasts are evaluated — touched or not, with the touch time — Brier contributions are computed, and one 21-column row per level is appended to `FBPI_Scoreboard_<SYMBOL>.csv`. The open-forecast file is deleted. This is idempotent: a restart across the boundary finalises from the saved forecast file instead of losing the day.
2. **Read the scoreboard panel.** Finalised rows, hit rate, mean forecast, mean Brier, Brier skill. Compare the mean forecast with the actual hit rate: if the indicator forecasts 70% on average and levels actually touch 70% of the time, it is calibrated — whether or not any trade was taken.
3. **Update `InpDailyLossSoFar`** if you traded (see the Risk Management Guide). The indicator does not know your results unless you tell it — and the input **does not reset itself**: it is a plain input, so yesterday's value stays in force until you change it. At the start of each trading day, set it to 0 (no loss yet today) and then update it as the day's losses occur; otherwise yesterday's loss will wrongly count against today's limit. If you leave it at 0, the dashboard notes "daily loss not entered" and the daily-loss check effectively cannot bind until you enter a loss.
4. **Review, don't chase.** A day with no setup (`ANALYSIS INCOMPLETE` all day) is a valid outcome. The indicator's job is to say "nothing meets the rules" when nothing does.

### Weekly / monthly review

- Open the scoreboard CSV in a spreadsheet and look at the per-level, per-session, and per-day-of-week breakdowns (the export summary includes SESSION, DOW, and CAL sections). Ask: which levels' forecasts are calibrated, and which are consistently over- or under-confident? A level whose mean forecast is 80% but whose actual touch rate is 55% is over-confident — treat its future probabilities with extra scepticism, and consider whether the lookback or minimum sample needs adjusting (see §9 of this manual for the settings).
- Never judge the indicator by one day, one level, or one trade. The Brier score is a mean over finalised rows; it needs rows to mean anything.

---

## 6. Volume profile and value area — reading them honestly

- **What you are looking at is tick volume.** Your broker counts price changes (ticks) per bar; that count is the "volume" in the profile. It is not the volume of the global Forex market, it is not exchange volume, and the same symbol on another broker can give a different POC. The dashboard labels it "tick volume" everywhere for exactly this reason.
- **POC** is the price where the most tick volume traded in the scope (daily / session / weekly). It is the centre of the highest-volume bin.
- **VAH / VAL** bound the smallest contiguous range around the POC holding 70% (default) of the day's tick volume. Price above VAH is "above value"; below VAL is "below value"; between them is "inside value".
- **Acceptance vs rejection:** acceptance (3 consecutive closed bars inside after being outside) says price is *staying* in value; rejection (a wick beyond VAH/VAL with a close back inside) says price probed outside value and came back. Neither is a trade signal on its own — they are two of the facts the confirmation score can use.
- **Migration:** if today's POC has moved by more than one bin vs the prior scope's POC, value has migrated. A migrating POC and a static POC tell different stories about where trading is concentrating.
- **What the profile cannot tell you:** who traded, in what size, or whether the volume was buying or selling. The tick-volume estimate of delta (see §8) is a proxy, not a measurement of aggressive buying or selling.

---

## 7. Key levels and probabilities — what N and the Wilson interval mean

### The 28 levels

| Family | Levels |
|---|---|
| Quarterly | QH, QL |
| Monthly | MH, ML, PMH (prev month high), PML (prev month low) |
| Weekly | WH, WL, PWH, PWL |
| Daily | PDH, PDL, PDC, PDO, DO |
| Session | ASH, ASL, LONH, LONL, NYH, NYL |
| Overnight | ONH, ONL (21:00–07:00 UTC — **not** the Asian session) |
| Opening range | ORH, ORL |
| Profile | POC, VAH, VAL |

The dashboard's Section D shows 10 of them (PDH, PDL, PDC, PWH, PWL, ASH, ASL, ORH, ORL, POC); all 28 are drawn as chart lines when valid and `InpShowLevelLines` is true.

### The 7 probability levels

Only 7 levels get a historical touch probability: **PDH, PDL, PDC, ONH, ONL, ORH, ORL**. The other levels are shown without a probability — not because they are less important, but because the probability engine is defined only for these seven.

### How a probability is computed

For a level (say PDH) and a lookback of `InpProbLookback` (default 100) days, the engine does the following, for each past day D (1 to 100 days ago):

1. **Reconstruct D's forecast level using only days before D.** For PDH, that is the high of the day before D. No information from D itself, and nothing from after D, is used to build the level.
2. **Evaluate the touch inside D's window only:** from the day start (00:00 UTC) to the 21:00 UTC cutoff. For ONH/ONL the window runs from the end of the Asian session to the cutoff; for ORH/ORL it runs from the end of the opening range to the cutoff.
3. **Count the day as eligible** only if the whole evaluation window lies inside available history. A day partly outside available history is **excluded from N** — the sample shrinks honestly, and the dashboard can show that history is short, instead of silently computing a probability from partial days.
4. **Count a touch** with the direction-aware test (one helper, used identically for the live status, the alert path, and the probability loop):
   - Upward level (e.g. PDH): a bar touches it when `High >= level`.
   - Downward level (e.g. PDL): a bar touches it when `Low <= level`.
   - Neutral level (PDC): a bar touches it when its range *contains* the level — `High >= level AND Low <= level`. (An earlier design used OR here, which is true for every bar and made the PDC probability always 100%. That form is forbidden in this code.)
   - **Spread adjustment** (`InpSpreadAdjPoints`, default 0.0): when set, it *narrows* the touch zone — the level is moved against the touch (up: `level + spread`; down: `level − spread`). At the default of 0 it has no effect. The touch method is `InpTouchMethod` (default `FBPI_TOUCH_HIGH_LOW`).
5. **Probability = touches / eligible days × 100.**

**Today (day 0) is excluded from every lookback loop.** The forecast for today is evaluated only inside today; it never contributes to its own probability.

### What N means

N is the number of **eligible** days — the denominator. A probability without N is meaningless, which is why the indicator never displays one without it. The display format is:

```
72.0% (N=100, Wilson 62.4–80.6)
```

- **72.0%** — the historical touch rate: the level was touched on 72 of the 100 eligible days.
- **N=100** — the sample size. If N is small, the percentage is fragile: 75% from N=4 means 3 touches out of 4 days, which proves almost nothing.
- **Wilson 62.4–80.6** — the **Wilson 95% interval** (z = 1.96). It is the range of true touch rates consistent with the observed data. With N=100 and 72 touches, the honest statement is "the underlying rate is plausibly anywhere from about 62% to about 81%". With N=20 and 14 touches (70%), the interval would be far wider — roughly 48% to 85% — and the dashboard shows that width instead of hiding it.

### INSUFFICIENT DATA

If N is below `InpMinSample` (default 20), the level shows:

```
INSUFFICIENT DATA (N=12)
```

No probability is shown, no scoreboard row is written for that level that day, and the confirmation score treats that level's probability as missing (see §9 — the Key-Level Location factor scores 0 on the probability part when the data is insufficient). This is not an error. It is the indicator refusing to present a small-sample percentage as if it meant something.

### How to use a probability — and how not to

- **Do use it** as a base rate: "levels like this have historically been touched on about 7 days in 10 before the cutoff; the plausible range is 62–81%".
- **Do not use it as a prediction** that price *will* touch the level today, or as a guarantee of any kind. A 72% historical rate is fully compatible with the level not being touched today — that happens roughly 28% of the time, by the indicator's own numbers.
- **Do not compare probabilities across different N** without looking at the Wilson interval. A 90% (N=20, Wilson ~70–97%) is weaker evidence than a 75% (N=100, Wilson ~66–82%).
- **Do not use a probability as a trade entry.** The probability says nothing about *where* price goes after touching, how far it goes, or whether a trade at the level would profit. The confirmation score and risk plan are the parts that address entry and risk — and they use the probability only as one input among six factors.
- **Do not expect the probability to be stable.** It is recomputed only on a new bar, at forecast time, or when an input changes — but as days roll through the 100-day window, old days drop out and new days enter, so the number drifts. A probability that moved from 72% to 68% over a month is normal window drift, not a regime change.

### Sweep vs breakout vs failed breakout (the liquidity state machine)

Eight levels are monitored for liquidity events: **PDH, PDL, ASH, ASL, LONH, LONL, ORH, ORL**. Classification uses **closed bars only** — an excursion is detected on a closed bar's High/Low, never on a live tick — and the bar open times are recorded, not tick times:

1. A closed bar whose High (buy-side) or Low (sell-side) goes beyond the level **opens an excursion**. The excursion bar time and the maximum excursion are recorded.
2. On each subsequent closed bar:
   - **Close back inside within `InpConfirmBars` (default 3) bars, with no close beyond the level → SWEEP.** A `SweepEvent` is recorded, a marker is drawn, and the sweep alert fires (throttled).
   - **Close beyond the level, then close back inside → FAILED BREAKOUT.** Recorded as its own event type (an earlier design detected this shape but did not record it). No sweep is counted.
   - **Still beyond the level after `InpBreakoutBars` (default 3) bars → SUSTAINED BREAKOUT.** Counted as a breakout.
   - **Close back inside too late** (after `InpConfirmBars` but before `InpBreakoutBars`, with no close beyond) → the state is dropped silently; no event is recorded.
3. State resets at the day rollover, and the daily sweep/breakout counters reset with it.

Note the boundary: with both `InpConfirmBars` and `InpBreakoutBars` at their default of 3, "within 3 bars" and "after 3 bars" meet exactly — a close back inside on the 3rd bar after the excursion, with no close beyond, is a sweep; still being beyond after 3 bars is a breakout.

---

## 8. Order book / order flow — the honesty labels

This section is short because there is little to describe — and that is the point.

- **Order book: `ORDER BOOK UNAVAILABLE`.** MT4 does not guarantee access to a consolidated global Forex order book, and no depth feed is configured in v1. The module contains a single marked integration point for a future feed, but no feed is written and no depth value is ever synthesised. If you ever see a bid/ask depth number on this dashboard, something is wrong — report it.
- **Order flow: `ESTIMATED TICK ACTIVITY`.** The delta proxy is tick volume × sign(close − open) per bar; cumulative delta is the running sum over up to 500 closed bars; imbalance is (up-tick-volume − down-tick-volume) / total tick volume per price bin. Every value in this mode is labelled as an estimate. It is **not** aggressive buying or selling, it is **not** institutional order flow, and it must never be described that way — including by you, when you talk about what the indicator showed.
- **Footprint: `ESTIMATED TICK ACTIVITY`.** The per-price-bin view is built from the same tick-volume estimate. A true bid/ask footprint requires a genuine bid/ask volume feed, which v1 does not have.
- **What would change this:** only a configured external feed (a file dropped in `MQL4\Files\` or a future integration) could activate the true bid/ask mode. That integration is specified as a future step, not built. Until then, these two labels are permanent features of the dashboard, not placeholders waiting for data.

---

## 9. Confirmation score — the six factors

The confirmation score is a weighted sum of six factors, each scored from 0 up to its weight. The weights are inputs and **must sum to 100** — if they do not, `OnInit()` fails and the indicator will not attach.

| # | Factor | Default weight | Full points when | Half points when | Zero when |
|---|---|---|---|---|---|
| 1 | Higher-Timeframe Alignment | 20 (`InpWeightHTF`) | MN1, W1, and D1 directions all agree with the setup direction | 2 of the 3 agree (10 pts) | Any of MN1/W1/D1 invalid, or directions conflict |
| 2 | Key-Level Location | 20 (`InpWeightLevel`) | Price is at/near a key level (within `InpApproachPips`, default 5.0 pips) **and** that level's historical touch probability is ≥ 65% | Probability is 50–64% (10 pts) | No level within range; or the level's probability is `INSUFFICIENT DATA`; or probability < 50% |
| 3 | Liquidity Event | 20 (`InpWeightLiquidity`) | A sweep in the setup direction occurred within the last 20 bars (fixed constant `FBPI_CONF_LIQ_LOOKBACK_BARS` = 20; there is no input for it) | — (no half credit) | No sweep in the setup direction in the window. A failed breakout in the opposite direction scores 0, not negative |
| 4 | Market Structure | 20 (`InpWeightStructure`) | A structure shift (break of swing + close beyond) in the setup direction on H1 or H4 | The auction classification is Trend in the setup direction but there is no H1/H4 structure shift (10 pts) | No shift, or a shift against the direction |
| 5 | Candle Confirmation | 10 (`InpWeightCandle`) | The last closed candle closed beyond a level, or is an engulfing candle in the setup direction (closed candle only when `InpRequireClosedCandle` = true, default) | — (no half credit) | No confirming close |
| 6 | Session Alignment | 10 (`InpWeightSession`) | The current session is London or New York (or the overlap) and the setup direction matches the session direction so far | The session is London/New York (or overlap) but its direction so far is neutral (5 pts) | Session is Asian only with no London/New York confirmation, or no session is active |

**Rules that apply to every factor:**

- **Missing data scores 0, never positive.** A factor with no data shows `hasData = false` and evidence `No data` (or a specific reason). The code enforces this after scoring (`if(!hasData) score = 0`), so a factor cannot accidentally receive partial credit from a missing input.
- **Every factor row is always shown**, with its individual contribution and a one-line evidence string that can be checked against the chart (e.g. `At PDH (2.1 pips), touch prob 72% (N=100)`). Never judge the total without reading the rows: a 70 could be four solid factors and two zeroes, or six mediocre ones — those are different situations.
- **The candidate direction comes from the higher timeframes.** It is the D1 direction, confirmed against H4: if D1 and H4 disagree, the code's candidate-direction logic resolves the conflict (see the Confirmation module header for the exact precedence). If there is no bullish/bearish higher-timeframe direction at all, no setup is identified and the status is `ANALYSIS INCOMPLETE` — but the score is still computed and shown.

### Bands (all three thresholds are inputs)

| Score | Band | Input | Default |
|---|---|---|---|
| 80–100 | **Strong confirmation** | `InpConfStrong` | 80 |
| 65–79 | **Moderate confirmation** | `InpConfModerate` | 65 |
| 50–64 | **Weak confirmation** | `InpConfWeak` | 50 |
| Below 50 | **Insufficient confirmation** | — | — |

The thresholds must be strictly decreasing (Strong > Moderate > Weak) and within 0–100, or `OnInit()` fails. The minimum score for a setup to progress past `WAITING FOR CONFIRMATION` is `InpMinConfScore` (default 50) — note this is a separate input from the Weak band threshold, even though both default to 50. Changing one does not change the other.

### What the score is not

The score is **not an empirically established probability**. It is a weighted checklist: somebody (the spec author) decided that HTF alignment is worth 20 points and candle confirmation 10, and the code adds them up. No backtest in this project establishes that an 80-point setup wins more often than a 60-point setup. The scoreboard (which measures *level-touch forecasts*, not confirmation scores) does not validate the score either. Treat the score as a disciplined way to check you have considered six things before trading — not as a measured edge. If you change the weights, you are changing the checklist, and the bands move with it; re-read the factor rows after any weight change, because a score of 72 under your weights is not comparable to a 72 under the defaults.

---

## 10. Execution statuses — the six states

The status is derived by a state machine evaluated in this order (from `FBPI_Risk_ExecStatus()` — note that a risk violation is checked *before* the confirmation threshold, so a violating plan is rejected even if its score is high):

| # | Status | Meaning | What to do |
|---|---|---|---|
| 1 | `ANALYSIS INCOMPLETE` | No setup has been identified — no bullish/bearish higher-timeframe direction, no valid stop could be determined, or no live price. | Nothing to review. Wait, or check whether the missing piece is data (e.g. too few bars). |
| 2 | `WAITING FOR CONFIRMATION` | A setup exists, but its confirmation score is below `InpMinConfScore` (default 50). | Watch the factor rows. The setup may strengthen (e.g. a sweep occurs, a candle confirms) or disappear. Do not trade it yet. |
| 3 | `SETUP IDENTIFIED` | Score ≥ minimum, but no current risk plan has been computed for this setup yet. | Transient in normal running (the risk plan is computed in the same recalculation pass). If it persists, the risk calculation is failing — check the Experts tab. |
| 4 | `RISK VALIDATED` | The risk plan is valid, but at least one confirmation factor had missing data. | The plan passes the rules, but the analysis behind it is incomplete. A setup whose score rests on missing factors is `RISK VALIDATED` at best — never `READY`. Decide whether the missing factor matters to you. |
| 5 | `READY FOR HUMAN REVIEW` | The risk plan is valid, the score is ≥ minimum, **and all six factors had data**. | **You decide now, outside the indicator.** Check the entry, stop, target, size, and rationale one more time, place the order yourself if you agree — or decline it. The indicator's work is done. |
| 6 | `REJECTED — RISK RULE VIOLATION` | The plan for the current setup violates a risk rule (minimum R:R, daily-loss limit, lot step, spread ≥ stop distance, or pip value unavailable). Overrides every other state. | Do not trade this plan. Reduce the risk, widen the target (only if the chart justifies it), or skip the trade. Never increase risk to "fix" a rejection. |

**How a setup's entry / stop / target are determined** (so you can sanity-check them before you trust them):

- **Entry:** the live price at identification — Ask for a bullish setup, Bid for a bearish setup. It is a market price, not a pending-order level: by the time you read it, it has already moved. Treat the entry as "around here", not as a fill price.
- **Stop:** the nearest level on the protective side of the entry, offset by `InpSweepTolerancePts` (default 0 points) beyond that level — or, if there is no protective level, the extreme of the last up to 20 closed H1 bars (lowest low for a bullish setup, highest high for a bearish one), also offset by the tolerance. If neither exists, no setup is identified at all.
- **Target:** the nearest level beyond the entry in the trade direction, *if* it gives a reward-to-risk of at least `InpMinRR` (default 2.0). Otherwise the target is a **2R projection** — entry ± 2 × the risk distance. Note the consequence: if you raise `InpMinRR` above 2.0, the 2R fallback target gives a computed R:R of 2.0, which is below your minimum — so the plan will be rejected for violating the minimum R:R. That is the code working as written, not a bug: with a minimum above 2.0, only a level-derived target can pass.
- **Identified time:** the first identification time is frozen and never moves while the same setup (same symbol, same direction) persists. If the setup disappears and a new one appears, the time resets.

---

## 11. Alerts — all 11 types

Alerts are **edge-triggered and throttled**. "Edge-triggered" means most alerts fire only on a *transition* (e.g. below → at/above the threshold), not continuously while the condition is true. "Throttled" means the same (alert type, key) cannot re-fire inside `InpAlertCooldownMinutes` (default 15 minutes; 0 = no throttle; maximum 1440). Delivery is: popup (`Alert()`) if `InpAlertPopup` = true, sound (`alert.wav`) if `InpAlertSound` = true, push notification (`SendNotification()`) if `InpAlertPush` = true — push also requires MT4's own notification settings (Tools → Options → Notifications, with your MetaQuotes ID). A sweep alert additionally draws a gold arrow marker at the current price.

**Defaults: only two alert types are on.** `InpAlertLevelTouch` = true and `InpAlertSweep` = true. All nine others default to **false**. If you enable nothing, you will still get touch and sweep alerts. If you want the rest, enable them deliberately — enabling all 11 on a busy chart is noisy by design.

| # | Alert | Input | Default | Fires when |
|---|---|---|---|---|
| 1 | New session opening | `InpAlertSessionOpen` | false | The current session changes to a different session (edge; the first session seen after attach does not fire). |
| 2 | Previous-day/week high/low approach | `InpAlertLevelApproach` | false | Price comes within `InpApproachPips` (default 5.0 **pips**, not points) of PDH, PDL, PWH, or PWL. **No edge latch:** it re-fires after each cooldown while price stays within range. |
| 3 | Previous-day/week high/low touch | `InpAlertLevelTouch` | **true** | A level's `touchedToday` flag flips from false to true (PDH, PDL, PWH, PWL). |
| 4 | Liquidity sweep | `InpAlertSweep` | **true** | A new sweep event is recorded (count-based: only genuinely new events fire). Also draws a gold arrow. |
| 5 | Opening range breakout | `InpAlertORBreakout` | false | The opening range breaks out (edge: no breakout → breakout). |
| 6 | Value-area breakout | `InpAlertVABreakout` | false | Price moves from inside the value area to outside it (edge: inside → above VAH or below VAL). |
| 7 | POC interaction | `InpAlertPOCTouch` | false | Price moves from far to within `InpApproachPips` of the daily POC (edge). |
| 8 | Market structure shift | `InpAlertStructShift` | false | The auction classification changes *into* Reversal or Failed Breakout (edge). |
| 9 | Confirmation score threshold | `InpAlertConfThreshold` | false | The confirmation score crosses from below to at/above `InpMinConfScore` (edge). |
| 10 | Risk-plan violation | `InpAlertRiskViolation` | false | A computed plan changes from valid to violating (edge; only when a plan actually exists). |
| 11 | Execution readiness | `InpAlertExecReady` | false | The status becomes `READY FOR HUMAN REVIEW` (edge). The message states explicitly that no order will be placed by the indicator. |

**Dedup details worth knowing:**

- The throttle is per **(alert type, key)** — the key is the level abbreviation for level alerts, the session name for session alerts, and a hash of the message otherwise. A PDH touch and a PDL touch have separate cooldowns; two PDH touches share one.
- The approach alert (type 2) is the only one without an edge latch. If price sits 3 pips from PDH for an hour with a 15-minute cooldown, expect roughly four approach alerts. Raise the cooldown or disable the type if that annoys you — do not mistake it for a malfunction.
- Alerts are evaluated in `FBPI_Main_CheckAlerts()` on every recalculation. They are not evaluated on ticks between recalculations.
- An alert is a prompt to look, not a trade instruction. In particular, the execution-readiness alert (type 11) fires when the status *becomes* ready — the setup may stop being ready minutes later if price moves or a factor loses its data.

---

## 12. Watchlist scan

- **What it is:** an optional bounded scan of the watchlist pairs, comparing each pair's current Bid with its previous trading day's high/low on H1. It is **off by default** (`InpEnableWatchlistScan` = false). Turn it on only if you want the scan rows in Section B.
- **Pairs:** `InpWatchlist` (default the 15 spec pairs: EURUSD, GBPUSD, USDJPY, USDCHF, USDCAD, AUDUSD, NZDUSD, EURGBP, EURJPY, GBPJPY, AUDJPY, CADJPY, CHFJPY, EURAUD, GBPAUD). Capacity 30 (`FBPI_MAX_SYMBOLS`); add custom pairs by appending them, comma-separated. At most `InpScanMaxPairs` (default 15) are scanned.
- **Broker mapping:** each base symbol is mapped with `InpSymbolPrefix` / `InpSymbolSuffix` (e.g. suffix `.pro` turns `EURUSD` into `EURUSD.pro`). A pair that maps to nothing your broker offers is shown as `symbol not offered by broker` — a warning, not a fatal error. A pair with no H1 history shows `prev-day H/L DATA UNAVAILABLE (no H1 history)`.
- **What it is not:** the scan does **not** compute ADR, probabilities, or confirmation scores for the scanned pairs — that would multiply the H1 scans ~30×. It is a one-line PDH/PDL position check per pair. Full analysis happens only on the chart symbol.
- **Cost:** one H1 window scan per pair per recalculation. With the default 15 pairs this is cheap; with 30 pairs and a 1-second refresh it is still bounded, but there is no reason to run the scan faster than you need it.

---

## 13. The scoreboard — what is recorded and how to read it

### The daily cycle

1. **Capture (once per trading day, after the Liquidity calculation):** today's frozen forecast for the 7 probability levels — forecast %, N, forecast time — is written to `FBPI_Forecasts_<SYMBOL>.csv`. A second capture the same day never overwrites the frozen forecast. If the terminal was off at the day start, the forecast is captured late, computed only from bars available at the original forecast time.
2. **Finalise (at the next trading-day start, before Liquidity recalculates for the new day):** each open forecast is evaluated — touched or not, and the touch time — the Brier contribution `(forecast − outcome)²` is computed, and one row per (symbol, trading day, level) is appended to `FBPI_Scoreboard_<SYMBOL>.csv`. Rows are append-only, deduplicated by `symbol|trading_day|level`, and **never edited** after being written.
3. **Aggregates** are rebuilt from the CSV on load and refreshed in memory; the file is the record, the memory is only a cache.

### The 21-column file

```
symbol,trading_day,level,session,day_of_week,forecast_time,cutoff_time,forecast_pct,observations,touches_at_forecast,forecast_prob,outcome,touch_time,brier_contribution,wilson_lower_pct,wilson_upper_pct,price_basis,touch_method,lookback_days,day_start_hour_utc,finalised_at
```

- The first line of the file is a comment recording the settings the rows were computed under (e.g. `# FBPI-MT4-001 day_start_utc=0 cutoff_utc=21 lookback=100 touch=HIGH_LOW`). If you change those settings, a new file is started — rows computed under different settings are never mixed in one file.
- If the header does not match the 21-column header exactly on load, the file is not loaded; a new `<name>_v2.csv` is started and the mismatch is printed. The old file is kept.
- **Sweeps** live in a separate file, `FBPI_Sweeps_<SYMBOL>.csv`: one row per event (including failed breakouts): symbol, event time, excursion bar time, confirm bar time, kind, level, level price, excursion in points, bars to confirm.
- **Sample data:** the project ships (or will ship, as a Phase 11 deliverable) a `Sample_Scoreboard.csv` in the exact 21-column shape with example values labelled EXAMPLE. Those numbers are invented for format illustration — never present them as results.

### Reading the numbers

- **Brier score** = mean `(forecast − outcome)²` over finalised rows, where forecast is the frozen probability (0–1) and outcome is 1 (touched) or 0 (not touched). **0 is perfect; lower is better.** A forecaster that always says 70% and is right 70% of the time scores about 0.21 — that is the score of a calibrated but uncertain forecast, not a bad one. A forecaster that says 100% and is wrong scores 1.0 on that row.
- **Brier skill vs climatology** = `1 − Brier / Brier_climatology`, where climatology is the overall actual touch rate. Positive skill means the forecasts beat the naive "always predict the base rate" forecast; zero means they tie; negative means they are worse than naive. It is a property of the *forecasts*, not of any trading.
- **Hit rate** = touches / finalised rows. Compare it with the **mean forecast**: if the mean forecast is 68% and the hit rate is 69%, the system is calibrated in aggregate. If the mean forecast is 80% and the hit rate is 55%, it is over-confident.
- **Calibration bins:** the export summary groups finalised rows into probability bins (deciles) with each bin's mean forecast vs actual touch rate, plus per-level, per-session, and per-day-of-week breakdowns. A bin whose actual rate is far below its mean forecast is where the over-confidence lives. Use the export (`[export CSV]` on the scoreboard panel, which requires `InpExportCSV` = true) for this analysis — the panel itself shows only the headline aggregates.
- **What the scoreboard cannot tell you:** whether the indicator makes money. It records level touches, not trades. No row in any of these files is a trade, and no aggregate in them is a profit figure.

### Files and their switches

| Input | Default | Effect |
|---|---|---|
| `InpEnableScoreboard` | true | Master switch for capture/finalisation and the scoreboard panel. |
| `InpPersistentStorage` | true | Load the scoreboard from file on attach; without it, aggregates start empty each session. |
| `InpExportCSV` | true | Enables the `[export CSV]` summary export. |

---

## 14. Settings reference — every input, its default, and its limits

All inputs live only in `FBPI_Main.mq4`, grouped with `input group`. `OnInit()` rejects the attach (`INIT_PARAMETERS_INCORRECT`) if any value below is outside its allowed range — the Experts tab names the offending input.

> **Inputs that do not exist in v1 (do not look for them):** there is no `InpAuctionMinBars` (auction minimum is the fixed constant 10), no `InpVAConfirmBars` (value-area acceptance is the fixed constant 3 bars), no `InpLevelProximityPips` (proximity reuses `InpApproachPips`), no `InpLiquidityLookbackBars` (the liquidity lookback is the fixed constant 20 bars), no `InpOrderFlowSource` and no `InpOrderBookSource` (no external flow/book feed exists in v1). Two inputs are **declared but reserved** (they do nothing in v1): `InpHistoryDays` (default 200 — modules size history from `InpProbLookback` / `InpWeeklyLookback` instead) and `InpProfileScope` (default daily — all three profile scopes are built in v1 regardless).

### General

| Input | Default | Allowed range / notes |
|---|---|---|
| `InpShowDashboard` | true | Show/hide the dashboard. |
| `InpDashCorner` | `CORNER_LEFT_UPPER` | Any `ENUM_CORNER` value. |
| `InpDashX` / `InpDashY` | 10 / 15 | ≥ 0 (pixels from the corner). |
| `InpTheme` | `FBPI_THEME_DARK` | Dark (fully designed) or light (secondary). |
| `InpRefreshSeconds` | 5 | 1–300. **0 is not supported** — there is no "no timer" mode. |
| `InpHistoryDays` | 200 | 1–1000. **Reserved in v1 — no effect.** |
| `InpShowLevelLines` | true | Master switch for chart level lines. |

### Symbols

| Input | Default |
|---|---|
| `InpWatchlist` | `EURUSD,GBPUSD,USDJPY,USDCHF,USDCAD,AUDUSD,NZDUSD,EURGBP,EURJPY,GBPJPY,AUDJPY,CADJPY,CHFJPY,EURAUD,GBPAUD` (15 pairs; capacity 30) |
| `InpSymbolPrefix` / `InpSymbolSuffix` | `""` / `""` |
| `InpGoldSymbol` | `XAUUSD` |
| `InpOilSymbol` | `XTIUSD` |
| `InpIndexSymbols` | `US30,SPX500,NAS100` |
| `InpCrossSymbols` | `""` (extra cross-market broker symbols) |
| `InpFuturesSymbols` | `""` (broker futures symbols — shown as CFDs, never exchange futures) |
| `InpEnableWatchlistScan` | false |
| `InpScanMaxPairs` | 15 (1–30) |

### Macro (Layers 1–7)

| Input | Default | Notes |
|---|---|---|
| `InpMacroMaxAgeHours` | 168 (7 days) | ≥ 1. Staleness limit for L1/L3 manual values. |
| `InpRateMaxAgeHours` | 2160 (90 days) | ≥ 1. Staleness limit for policy rates. |
| `InpCorrLookback` | 20 | 5–252 days for Pearson correlation. |
| `InpGlobalCondition` | `""` | `Expansion` / `Contraction` / `Mixed` / `Unknown` |
| `InpGlobalGrowthPct` / `InpGlobalInflationPct` / `InpGlobalUnemploymentPct` | −999.0 | %; −999.0 = not entered |
| `InpGlobalTradeNote` | `""` | Free text |
| `InpRiskSentiment` | `""` | `Risk-on` / `Risk-off` / `Neutral` |
| `InpMacroContextNote` | `""` | Free text (hidden when empty) |
| `InpBondYield10Y` | −999.0 | % |
| `InpCreditConditions` / `InpFundingConditions` | `""` | `Tightening` / `Neutral` / `Easing` / `Unknown` |
| `InpDollarLiquidity` | `""` | `Ample` / `Neutral` / `Tight` / `Unknown` |
| `InpRiskAppetite` | `""` | `Risk-on` / `Neutral` / `Risk-off` |
| `InpStressNote` | `""` | Free text |
| `InpRate_<CCY>`, `InpPrevRate_<CCY>` | −999.0 | Per currency: USD, EUR, GBP, JPY, CHF, CAD, AUD, NZD; valid rates −5…+25% |
| `InpDecision_<CCY>` | `""` | `Hike` / `Hold` / `Cut` |
| `InpDecisionDate_<CCY>` | `""` | `yyyy.mm.dd` |
| `InpExpectedDir_<CCY>` | `""` | `Hike` / `Hold` / `Cut` / `Unknown` |
| `InpNextMeeting_<CCY>` | `""` | `yyyy.mm.dd` |

### Market structure (Layers 8–11)

| Input | Default | Allowed |
|---|---|---|
| `InpADRPeriod` | 14 | 1–500 days |
| `InpWeeklyLookback` | 12 | 2–52 weeks |
| `InpShowQuarterly` / `InpShowMonthly` / `InpShowWeekly` / `InpShowDaily` | true | Also gates the matching level-line families |
| `InpDayStartUTC` | `"00:00"` | `"HH:MM"`; must parse |
| `InpCutoffHourUTC` | 21 | 0–23 (UTC) |
| `InpBrokerGMTOffset` | 0.0 | −12…+14 hours, **double** (half-hours such as +5.5 allowed) |

### Sessions (Layers 12–13) — see also the Session Configuration Guide

| Input | Default | Allowed |
|---|---|---|
| `InpUseUTCReference` | true | When false, the broker offset is treated as 0 (see the Session Guide) |
| `InpDSTMode` | `FBPI_DST_US` | `Off` / `US` / `EU` / `Manual` |
| `InpDSTShiftHours` | 1.0 | 0–2 |
| `InpAsianStartUTC` / `InpAsianEndUTC` | `"00:00"` / `"09:00"` | `"HH:MM"` |
| `InpLondonStartUTC` / `InpLondonEndUTC` | `"07:00"` / `"16:00"` | `"HH:MM"` |
| `InpNYStartUTC` / `InpNYEndUTC` | `"12:00"` / `"21:00"` | `"HH:MM"` |
| `InpCustomSession1..3` | `""` | `"HH:MM-HH:MM"` optionally followed by `\|Name`; `""` = disabled |
| `InpOpeningRangeMinutes` | 30 | **15, 30, or 60 only** |
| `InpOpeningRangeSession` | `FBPI_OR_NEWYORK` | New York / London / Asian / Day start |
| `InpShowLondonOR` / `InpShowNewYorkOR` | true | Show the independent London / New York opening-range rows |

### Volume (Layers 15–16)

| Input | Default | Allowed |
|---|---|---|
| `InpValueAreaPct` | 70.0 | 50–90 (%) |
| `InpProfileBins` | 24 | 1–100 |
| `InpProfileScope` | `FBPI_PROFILE_DAILY` | **Reserved in v1 — all three scopes are built regardless.** |

### Liquidity (Layer 17)

| Input | Default | Allowed |
|---|---|---|
| `InpProbLookback` | 100 | 5–500 days |
| `InpMinSample` | 20 | 5–100, and ≤ `InpProbLookback` |
| `InpTouchMethod` | `FBPI_TOUCH_HIGH_LOW` | Touch-test method |
| `InpSpreadAdjPoints` | 0.0 | ≥ 0; narrows the touch zone |
| `InpConfirmBars` | 3 | 1–10 |
| `InpBreakoutBars` | 3 | 1–10 |
| `InpSweepTolerancePts` | 0 | ≥ 0 points beyond a level that still counts (also offsets setup stops) |

### Confirmation (Layer 21)

| Input | Default | Allowed |
|---|---|---|
| `InpWeightHTF` / `InpWeightLevel` / `InpWeightLiquidity` / `InpWeightStructure` | 20 each | Weights **must sum to 100** with the two below |
| `InpWeightCandle` / `InpWeightSession` | 10 each | |
| `InpMinConfScore` | 50 | 0–100 |
| `InpConfStrong` / `InpConfModerate` / `InpConfWeak` | 80 / 65 / 50 | Must be strictly decreasing, 0–100 |
| `InpRequireClosedCandle` | true | Candle confirmation on closed candles only |
| `InpApproachPips` | 5.0 | 0.1–100 **pips** (not points); also the key-level proximity for the confirmation factor |

### Risk (Layers 22–23) — see also the Risk Management Guide

| Input | Default | Allowed |
|---|---|---|
| `InpPaperCapital` | 5000.0 | > 0 |
| `InpRiskPct` | 0.5 | 0.1–5.0 (%) |
| `InpMaxDailyLossPct` | 2.0 | 0.5–10 (%), and ≥ `InpRiskPct` |
| `InpMinRR` | 2.0 | 1.0–5.0 |
| `InpPrefRR` | 3.0 | ≥ `InpMinRR` (preferred, not enforced) |
| `InpAccountCurrency` | `"USD"` | Display currency for money values |
| `InpCommissionPerLot` | 0.0 | ≥ 0 (per lot, in account currency) |
| `InpDailyLossSoFar` | 0.0 | ≥ 0; **manual** — the indicator never reads your account; 0 = not entered |
| `InpPlanEntry` / `InpPlanStop` / `InpPlanTarget` | 0.0 | Manual plan; **all three must be set, or all three 0** (a partial plan fails validation); stop/target must differ from entry |

### Alerts (spec §11)

| Input | Default |
|---|---|
| `InpAlertSessionOpen`, `InpAlertLevelApproach`, `InpAlertORBreakout`, `InpAlertVABreakout`, `InpAlertPOCTouch`, `InpAlertStructShift`, `InpAlertConfThreshold`, `InpAlertRiskViolation`, `InpAlertExecReady` | false |
| `InpAlertLevelTouch`, `InpAlertSweep` | **true** |
| `InpAlertSound` / `InpAlertPopup` | true |
| `InpAlertPush` | false |
| `InpAlertCooldownMinutes` | 15 (0–1440; 0 = no throttle) |

### Statistics (spec §12)

| Input | Default |
|---|---|
| `InpEnableScoreboard` | true |
| `InpPersistentStorage` | true |
| `InpExportCSV` | true |

---

## 15. Limitations you should keep in mind

1. **Never compiled, never run live.** Everything above is a static-audit description. Treat the first live run as a test, not as a deployment.
2. **Tick volume is broker-relative.** Profiles, value areas, and estimated flow can differ between brokers for the same symbol.
3. **The probability engine needs history.** About 100 days of H1 history for a full N; shorter history shrinks N honestly but gives wide Wilson intervals.
4. **DST-transition days are 23 or 25 hours long.** Day windows are computed from UTC anchors, so the UTC frame stays correct, but a session window straddling the transition is computed from the offset in force at the window start. Test the transition days explicitly (see the Session Configuration Guide).
5. **The dashboard never writes market data.** It only displays what the calculation modules produced. If a value is missing from the dashboard, the missing calculation is the defect — the dashboard will not fill it in.
6. **A known pending code item:** the Sessions module still contains a duplicate H1-scan helper (`FBPI_Sessions_ScanH1`, a copy of the MarketStructure scan) that the Sessions author left with a note to delete. It is dead weight, not a behaviour difference — but it is a reminder that the code is a first build, not a finished product. Do not "fix" it yourself in the delivered files unless you are prepared to re-verify the six call sites.
7. **The confirmation score is a checklist, not a measured edge** (see §9). The scoreboard measures level-touch forecasts, not the score and not trading results.

*End of User Manual — FBPI-MT4-001 v1.0.*
