# Forex Bigger Picture Intelligence System — Session Configuration Guide

| Field | Value |
|---|---|
| Project ID | FBPI-MT4-001 |
| Product | Forex Bigger Picture Intelligence System v1.0 |
| Platform | MetaTrader 4 (MT4), MQL4 build 600+ |
| Date | 2026-11-27 |
| Companion documents | `User_Manual.md` (dashboard Sections B–C), `Technical_Architecture.md` §4.1/§4.5, `Installation_Guide.md` |
| Spec | `FBPI-MT4-001-spec.md` §3 Layer 12–13, §15 Sessions |

> **Verification status.** The session logic described here is taken from the source code (`FBPI_Sessions.mqh`, `FBPI_OpeningRange.mqh`, `FBPI_Main.mq4`). It has been statically audited only — it has never been compiled and never run in a live MT4 terminal. Session boundaries, DST transitions, and the worked examples below are **unverified live** until tested on your laptop. If a live session window disagrees with this guide, trust the live chart and the Experts-tab output, and treat the discrepancy as a defect to report.

---

## 1. The one idea: everything is UTC first

Every time in FBPI is defined in **UTC** and only converted to broker time when the indicator needs to look up a bar. This is deliberate, and it is a correction of the earlier FLR indicator, which defined its day start and cutoff in broker time.

The chain is:

```
UTC time (the reference frame)
   → + broker offset (InpBrokerGMTOffset, plus DST shift when in force)
   → broker time (used only to find the right H1 / M15 bars)
```

Consequences you can rely on:

- **Two brokers in different timezones show the same sessions.** A GMT+2 broker and a GMT−5 broker both compute the London session as 07:00–16:00 UTC; they only look it up at different broker clock times. The *analysis* is identical; only the bar lookup shifts.
- **Changing your broker offset never changes what a session means** — it changes which bars the indicator reads. If your sessions look wrong after changing broker, the offset is wrong, not the session definitions.
- **The trading day, the cutoff, and the overnight window are all UTC.** The day starts at `InpDayStartUTC` (default 00:00 UTC) and the forecast evaluation window ends at `InpCutoffHourUTC` (default 21:00 UTC). Neither moves when your broker changes its clocks.

### The inputs that define the reference frame

| Input | Default | Meaning |
|---|---|---|
| `InpUseUTCReference` | true | When true, the UTC frame described above is used. When false, the broker offset is treated as 0 — i.e. broker time is taken as UTC. Only set it to false if your broker's server time *is* UTC (offset 0 with no DST). |
| `InpDayStartUTC` | `"00:00"` | The trading day starts at this UTC time. Format `"HH:MM"`. |
| `InpCutoffHourUTC` | 21 | The forecast evaluation window ends at this UTC hour (21:00 UTC). Allowed 0–23. |
| `InpBrokerGMTOffset` | 0.0 | Your broker's server offset from UTC in hours. A **double**: half-hour offsets such as +5.5 are representable (the FLR indicator used an integer and could not represent them). Allowed −12…+14. |

**How to find your broker's offset.** In MT4, compare the time shown on a chart (the broker server time, top-right of the chart) with the current UTC time. The difference, in hours, is the offset — *before* DST. Examples: server time 14:00 while UTC is 12:00 → offset +2.0. Server time 07:00 while UTC is 12:00 → offset −5.0. If your broker observes daylight saving, that +2.0 or −5.0 is the *standard* (winter) offset; the DST shift is handled separately in §3 — do not bake the summer shift into this number.

**What happens if the offset is wrong.** Every session window, the day start, the cutoff, and the overnight window will be looked up at the wrong bars. Sessions will appear to start early or late by exactly the error, levels (ASH/ASL, LONH/LONL, NYH/NYL, ONH/ONL) will be computed from the wrong hours, and the probabilities built on those levels will be wrong too. A wrong offset is the single most damaging misconfiguration in this indicator — and the hardest to notice, because the dashboard will still show confident-looking numbers. Verify the offset first whenever anything session-related looks off.

---

## 2. The six session "HH:MM" strings

Session times are **strings** in `"HH:MM"` 24-hour format — not integer hours. That is what allows a session to start at 07:30, which integer-hour sessions could not express. Every one of the six strings is validated in `OnInit()`: a string that does not parse as `"HH:MM"` fails the attach with `INIT_PARAMETERS_INCORRECT` and an Experts-tab line naming the bad value.

| Input | Default | Session |
|---|---|---|
| `InpAsianStartUTC` | `"00:00"` | Asian session opens |
| `InpAsianEndUTC` | `"09:00"` | Asian session closes |
| `InpLondonStartUTC` | `"07:00"` | London session opens |
| `InpLondonEndUTC` | `"16:00"` | London session closes |
| `InpNYStartUTC` | `"12:00"` | New York session opens |
| `InpNYEndUTC` | `"21:00"` | New York session closes |

**Defaults visualised (UTC):**

```
00:00 ├──────── Asian ────────┤
07:00      ├──────── London ────────┤
12:00           ├──────── New York ────────┤ 21:00
     |--- overlap 12:00–16:00 ---|
```

**Overlaps are intentional.** London (07:00–16:00) overlaps Asian (00:00–09:00) from 07:00–09:00, and overlaps New York (12:00–21:00) from 12:00–16:00. The indicator does not treat an overlap as an error. The **London–New York overlap (12:00–16:00 UTC by default)** is reported as its own state (`FBPI_SESS_OVERLAP`, "London/New York overlap"), with its own range and direction in Section C.

**Which session is "current"?** Precedence, evaluated from the UTC time: a custom window first (see §4), then the London–New York overlap, then New York, then London, then Asian. If no window contains the current time, there is no current session (`FBPI_SESS_NONE`).

**"Market open" is more than a clock test.** The dashboard's `(market open)` label also requires a current bar within the last 10 minutes. The clock alone would return a session name on a Saturday; the recency test prevents that. At weekends all sessions report `Closed`.

**Windows that cross midnight.** If a session's end time is earlier than or equal to its start time (e.g. `"22:00"`–`"06:00"`), the window is treated as crossing midnight and 24 hours are added to the end. This applies to the standard sessions and to custom sessions alike. The overnight window (§5) is the built-in example of a window that crosses the day boundary.

**Session levels.** For each session the indicator computes open, high, low, range, and direction from H1 bars in the window, capped at `min(windowEnd, now)` — a session still in progress shows its running extreme; a session that has not started is invalid (shown as `DATA UNAVAILABLE` / "not started — no bars yet"), never zero. A session's `isFinal` flag becomes true only after its window has closed. Session interactions are also computed: London breakout (London close vs the Asian high/low), and New York continuation or reversal (New York close vs the London high/low).

---

## 3. Broker offset and daylight saving — the four DST modes

The effective broker offset at any moment is:

```
effective offset = InpBrokerGMTOffset + DST shift in force
```

The DST shift is determined by `InpDSTMode` (`ENUM_FBPI_DST`). The shift amount is `InpDSTShiftHours` (default 1.0, allowed 0–2).

| `InpDSTMode` | Value | Rule |
|---|---|---|
| `FBPI_DST_OFF` | Off | Shift is always 0. Use this when your broker does not observe daylight saving (its server offset is constant all year), or when you want the offset frozen at `InpBrokerGMTOffset`. |
| `FBPI_DST_US` | US (default) | Shift applies from the **second Sunday in March at 07:00 UTC** to the **first Sunday in November at 06:00 UTC**. |
| `FBPI_DST_EU` | EU | Shift applies from the **last Sunday in March at 01:00 UTC** to the **last Sunday in October at 01:00 UTC**. |
| `FBPI_DST_MANUAL` | Manual | `InpDSTShiftHours` is applied **unconditionally**, all year. Use this when your broker's DST does not follow the US or EU rules, or when you want to force the summer offset by hand. Remember to change it back when your broker's DST ends — the indicator will not do it for you. |

**Exact rule dates** (verified against the calendar; the rules themselves are in the code — the dates below are what those rules produce):

| Year | US starts (2nd Sun Mar, 07:00 UTC) | US ends (1st Sun Nov, 06:00 UTC) | EU starts (last Sun Mar, 01:00 UTC) | EU ends (last Sun Oct, 01:00 UTC) |
|---|---|---|---|---|
| 2026 | Sunday 2026-03-08 | Sunday 2026-11-01 | Sunday 2026-03-29 | Sunday 2026-10-25 |
| 2027 | Sunday 2027-03-14 | Sunday 2027-11-07 | Sunday 2027-03-28 | Sunday 2027-10-31 |

**How the rule is evaluated.** The code converts the broker time to an approximate UTC time (subtracting the *base* offset), determines the calendar year, computes the start/end instants for that year from the rules above, and applies the shift if the approximate UTC time falls inside `[start, end)`. The transition instants are UTC instants (07:00/06:00 UTC for the US, 01:00 UTC for the EU) — they are not local times.

**Which mode should you choose?** Match the mode to your *broker's* DST behaviour, not to your own location. The question is always "does my broker's server clock jump, and by which rule?" If you do not know, ask your broker for its server timezone and DST policy — it is usually in their FAQ or trading conditions. Common cases:

- Broker server is GMT+2 in winter and GMT+3 in summer (a very common MT4 setup): `InpBrokerGMTOffset` = 2.0, `InpDSTMode` = EU (if the broker follows the EU rule) — see Worked Example 1.
- Broker server is GMT−5 (EST) in winter and GMT−4 (EDT) in summer: `InpBrokerGMTOffset` = −5.0, `InpDSTMode` = US — see Worked Example 2.
- Broker server is fixed at UTC or GMT all year (some brokers): `InpBrokerGMTOffset` = 0.0, `InpDSTMode` = Off.
- Broker server is fixed at GMT+3 all year (some brokers never shift): `InpBrokerGMTOffset` = 3.0, `InpDSTMode` = Off.

**Known limitation — DST-transition days.** On the day the clocks change, the broker day is 23 or 25 hours long. Day windows are computed from UTC anchors, so the UTC frame stays correct — but a session window that straddles the transition is computed from the offset in force at the *window start*. A window that starts before the transition and ends after it will therefore be looked up with a single offset for its whole length. This is a documented limitation (Technical Architecture §8.3 L-5), not a tested behaviour: **check the session levels by hand on the transition days in March and October/November**, and do not rely on that day's probabilities or sweep classifications without a manual sanity check.

---

## 4. Custom sessions

Up to three custom windows can be defined. They **supplement** the standard three sessions — they do not replace them. (The spec's wording suggested replacement; the architecture deliberately changed this, because deleting the Asian/London/New York sessions would remove the levels the rest of the system depends on. If you do not want to see the standard sessions, hide their dashboard rows by other means — the sessions themselves stay computed.)

| Input | Default | Format |
|---|---|---|
| `InpCustomSession1` | `""` | `"HH:MM-HH:MM"` optionally followed by `\|Name` |
| `InpCustomSession2` | `""` | Same |
| `InpCustomSession3` | `""` | Same |

- `""` (empty) = disabled. That is the default for all three.
- **Format:** `"HH:MM-HH:MM"`, e.g. `"21:00-00:00"`. The times are UTC, like the standard sessions, and a window whose end is earlier than its start crosses midnight.
- **Optional name:** append `|Name`, e.g. `"21:00-00:00|New York close"` or `"03:00-05:00|Tokyo lunch"`. The name is what appears in Section C (`Custom (Tokyo lunch): H … L …`). Without a name, the row shows the window itself.
- **Precedence:** custom windows are checked **first** when determining the current session — a time inside a custom window reports `FBPI_SESS_CUSTOM` even if it is also inside a standard session. The standard sessions' levels are still computed.
- **Malformed input:** a custom-session string that does not parse is not a fatal attach failure — the window is disabled and a message is printed in the Experts tab (`FBPI Sessions: malformed InpCustomSession…`). Check the Experts tab if a custom session does not appear.
- **Suggested uses:** a pre-London "Frankfurt open" window, a New York afternoon / close window, or a window covering a specific economic-release time you watch. Keep the number small: three is the maximum, and each custom window adds a row to Section C and a session to the precedence check.

---

## 5. Day start, cutoff, and the genuine overnight window

### Day start — 00:00 UTC by default

`InpDayStartUTC` (default `"00:00"`) is the start of the trading day. All daily windows — PDH/PDL/PDC/PDO, the current day open (DO), the daily profile, the sweep counters, the forecast capture — are anchored to it. If the current time is before the day start in UTC terms, the trading day is taken to have started yesterday (UTC). The day start is converted to broker time only for bar lookup.

**Changing the day start changes everything downstream.** A day start of `"22:00"` (used by some traders to align with the New York close) moves PDH/PDL, the daily profile, the sweep counters, and the forecast capture to a 22:00–22:00 day. The scoreboard's settings comment records `day_start_utc`, and changing the day start starts a new scoreboard file — rows computed under different day starts are never mixed. Do not change the day start casually on a live scoreboard.

### Cutoff — 21:00 UTC by default

`InpCutoffHourUTC` (default 21) is the hour at which the forecast evaluation window ends. A level's touch probability is the fraction of past days on which the level was touched between the day start and **21:00 UTC** — touches after 21:00 UTC do not count for that day's forecast. The cutoff is applied in the UTC frame (the FLR indicator applied it as 21:00 broker time; that is corrected here).

The cutoff also bounds the trading week: the week runs Monday 00:00 UTC to **Sunday 21:00 UTC**.

### The overnight window — 21:00–07:00 UTC, genuinely overnight

The overnight high/low (**ONH/ONL**) are computed from the window **[21:00 UTC previous day, 07:00 UTC current day)**. This window crosses the trading-day boundary by construction: it starts at yesterday's cutoff and ends at 07:00 UTC today (the London open). It is computed by a dedicated scan that spans the boundary.

**ONH/ONL are not the Asian session high/low.** The Asian session is 00:00–09:00 UTC; the overnight window is 21:00–07:00 UTC. They overlap (00:00–07:00) but they are different windows with different opens, and they will generally give different highs and lows. The FLR indicator used the Asian high/low as the overnight high/low; this indicator corrects that. If ONH looks identical to ASH on your chart, something is wrong — check it.

The overnight window also defines the evaluation window for the ONH/ONL probabilities: ONH/ONL touches are evaluated from the end of the Asian session to the cutoff (see the User Manual, §7).

---

## 6. Opening range — anchored to the session open

### The main opening range

| Input | Default | Meaning |
|---|---|---|
| `InpOpeningRangeMinutes` | 30 | Duration in minutes. **15, 30, or 60 only** — any other value fails `OnInit()`. |
| `InpOpeningRangeSession` | `FBPI_OR_NEWYORK` | Which session's open anchors the range: New York (default), London, Asian, or Day start. |

The range is the first N minutes **after the open of the chosen session** — for the default, the first 30 minutes of New York (12:00–12:30 UTC). It is computed from **M15 bars** (finer than H1: a 15-minute range needs M15 granularity) inside that window: ORH is the highest high, ORL the lowest low, and the midpoint is their average.

**This is a correction of the FLR behaviour**, which started the range at the trading-day start (00:00–00:30 UTC) — a range that meant nothing. If you set `InpOpeningRangeSession` to Day start (`FBPI_OR_DAYSTART`), you get the old FLR behaviour back deliberately; the option exists only for explicit comparison.

**Before the session opens**, ORH/ORL are invalid (`DATA UNAVAILABLE`) — the range does not exist yet, and the indicator will not invent one from earlier bars. **Before the range window has finished**, ORH/ORL are provisional (the running high/low of the M15 bars so far).

### Independent London and New York ranges

| Input | Default | Meaning |
|---|---|---|
| `InpShowLondonOR` | true | Compute and show the independent London opening range. |
| `InpShowNewYorkOR` | true | Compute and show the independent New York opening range. |

These are separate ranges with their own ORH/ORL values, computed the same way from their own session opens and the same `InpOpeningRangeMinutes` duration. Note the storage detail: the main ORH/ORL live in the shared level slots (`g_fbpiLevels[ORH/ORL]`); the London and New York ranges have their own state. All three are classified independently (see below). Setting `InpShowLondonOR` = false hides the London row; it does not stop the London range being the anchor if `InpOpeningRangeSession` is London.

### Breakout / retest / rejection classification (closed M15 bars only)

After the range window ends, each subsequent **closed** M15 bar is classified:

- **Breakout above/below:** a closed bar's close beyond ORH/ORL. Sustained breakout: `InpBreakoutBars` (default 3) consecutive closes beyond the level.
- **Failed breakout:** a close beyond the level followed by a close back inside.
- **Retest held / retest failed:** price returns to the broken level and either holds (closes on the breakout side) or fails (closes back inside).
- **Rejection:** a wick beyond the level with the close back inside the range.

The dashboard's state text for the main range (and for the London/New York rows) is one of: `Breakout up/down`, `Breakout up/down (sustained)`, `Failed breakout up/down`, `Retest held`, `Retest failed`, `Rejection of range high/low`. The opening-range breakout alert (`InpAlertORBreakout`) fires on the breakout edge.

### Choosing a duration

- **15 minutes** gives the tightest range and the most breakouts (and the most false ones). Useful on fast pairs or when you trade the New York open aggressively.
- **30 minutes (default)** is the middle ground and the spec's default.
- **60 minutes** gives a wider, more significant range and fewer breakouts. The range is less likely to be broken by noise, but by the time it breaks, more of the move may have happened.

There is no "correct" duration. Pick one, keep it fixed while you build scoreboard history, and judge it by the opening-range outcomes recorded over weeks — not by one morning.

---

## 7. Worked examples

All times below are computed from the rules in §1–§3. Broker times are what you would see on the MT4 chart clock.

### Example 1 — GMT+2 broker, summer vs winter (EU DST)

**Setup:** broker server is GMT+2 in winter and GMT+3 in summer (EU rule). Correct inputs: `InpBrokerGMTOffset` = 2.0, `InpDSTMode` = `FBPI_DST_EU`, `InpDSTShiftHours` = 1.0.

| Item | Winter (e.g. 15 January) | Summer (e.g. 15 July) |
|---|---|---|
| Effective offset | 2.0 + 0 = **GMT+2** | 2.0 + 1.0 = **GMT+3** |
| Trading day starts (00:00 UTC) | 02:00 broker | 03:00 broker |
| Asian session (00:00–09:00 UTC) | 02:00–11:00 broker | 03:00–12:00 broker |
| London session (07:00–16:00 UTC) | 09:00–18:00 broker | 10:00–19:00 broker |
| New York session (12:00–21:00 UTC) | 14:00–23:00 broker | 15:00–00:00 broker |
| London–NY overlap (12:00–16:00 UTC) | 14:00–18:00 broker | 15:00–19:00 broker |
| Cutoff (21:00 UTC) | 23:00 broker | 00:00 broker (next day) |
| Overnight window (21:00–07:00 UTC) | 23:00–09:00 broker | 00:00–10:00 broker |
| New York opening range, 30 min (12:00–12:30 UTC) | 14:00–14:30 broker | 15:00–15:30 broker |

**The mistake to avoid:** setting `InpBrokerGMTOffset` = 3.0 in summer and forgetting to change it back in winter (or setting it to 2.0 and `InpDSTMode` = Off, which leaves the summer sessions an hour early). With the EU mode set correctly, you set the offset **once** (2.0) and the indicator shifts it for you on the last Sunday in March and the last Sunday in October.

**Check it yourself:** on a summer day, open an H1 chart and look at the session high/low lines. The London high/low should span the bars from 10:00 to 19:00 broker time. If they span 09:00–18:00 in July, the DST shift is not being applied — check `InpDSTMode` and the Experts tab.

### Example 2 — GMT−5 broker with US DST (EST/EDT)

**Setup:** broker server is GMT−5 in winter (EST) and GMT−4 in summer (EDT). Correct inputs: `InpBrokerGMTOffset` = −5.0, `InpDSTMode` = `FBPI_DST_US`, `InpDSTShiftHours` = 1.0.

| Item | Winter (e.g. 15 January) | Summer (e.g. 15 July) |
|---|---|---|
| Effective offset | −5.0 + 0 = **GMT−5** | −5.0 + 1.0 = **GMT−4** |
| Trading day starts (00:00 UTC) | 19:00 broker (previous day) | 20:00 broker (previous day) |
| Asian session (00:00–09:00 UTC) | 19:00–04:00 broker | 20:00–05:00 broker |
| London session (07:00–16:00 UTC) | 02:00–11:00 broker | 03:00–12:00 broker |
| New York session (12:00–21:00 UTC) | 07:00–16:00 broker | 08:00–17:00 broker |
| Cutoff (21:00 UTC) | 16:00 broker | 17:00 broker |
| New York opening range, 30 min (12:00–12:30 UTC) | 07:00–07:30 broker | 08:00–08:30 broker |

Note the day start: with a negative offset, the UTC trading day starts on the **previous** broker calendar day (19:00/20:00). That is correct — the trading day is a UTC concept, and the broker date is not the trading date. The dashboard's "today" is the UTC day, and the scoreboard's `trading_day` is the UTC date. Do not be surprised when the day rolls over at 19:00 or 20:00 on your chart clock.

### Example 3 — GMT+5:30 broker (half-hour offset, no DST)

**Setup:** broker server is GMT+5:30 all year (e.g. an India-based server). Correct inputs: `InpBrokerGMTOffset` = 5.5, `InpDSTMode` = `FBPI_DST_OFF`.

| Item | All year |
|---|---|
| Effective offset | **GMT+5:30** |
| Trading day starts (00:00 UTC) | 05:30 broker |
| Asian session (00:00–09:00 UTC) | 05:30–14:30 broker |
| London session (07:00–16:00 UTC) | 12:30–21:30 broker |
| New York session (12:00–21:00 UTC) | 17:30–02:30 broker (next day) |
| Cutoff (21:00 UTC) | 02:30 broker (next day) |
| New York opening range, 30 min | 17:30–18:00 broker |

This is the case the `double` offset exists for: an integer offset could only express +5 or +6, either of which would shift every session by 30 minutes. If your broker is on a half-hour (or 45-minute, e.g. +5.75) offset, the double is not a nicety — it is the difference between correct and wrong sessions.

### Example 4 — a custom session

You want to watch the hour before the New York open as its own window, named "NY pre-open":

- `InpCustomSession1` = `"11:00-12:00|NY pre-open"`
- Result in Section C: `Custom (NY pre-open): H … L … | … pts | …` — and between 11:00 and 12:00 UTC the "current session" reads as the custom window, not Asian or London, because custom windows are checked first. The London session's own high/low are still computed over 07:00–16:00 UTC; the custom window does not carve anything out of them.

---

## 8. Configuration checklist (do this once, then leave it alone)

1. **Find your broker's standard offset** (chart clock vs UTC) and set `InpBrokerGMTOffset`. Double-check the sign: east of Greenwich is positive, west is negative.
2. **Find your broker's DST rule** and set `InpDSTMode` (US / EU / Manual / Off). When in doubt, ask the broker. "I think it's GMT+2" is not a DST policy.
3. **Leave the session times at their defaults** unless you have a specific reason to change them. The defaults (Asian 00:00–09:00, London 07:00–16:00, New York 12:00–21:00 UTC) are the spec defaults and the ones the probability engine's evaluation windows assume.
4. **Leave the day start at `"00:00"` and the cutoff at 21** unless you are deliberately redefining the trading day (and accept that the scoreboard restarts).
5. **Leave the opening range at 30 minutes anchored to New York** for your first weeks. Change one thing at a time afterwards, and only after you have scoreboard history under the current setting.
6. **Verify on the chart:** pick a known day, read the session high/low off the H1 bars by hand for one session, and compare with the dashboard. If they match, your offset and DST are right. If they are off by exactly one hour, DST is the culprit. If they are off by a different amount, the base offset is wrong.
7. **Re-check after every broker server change.** If your broker migrates servers or changes its timezone (brokers do this, usually with little notice), the offset and DST settings must be re-verified. A silent server migration is the most common cause of "the sessions suddenly look wrong".

---

## 9. Troubleshooting sessions

| Symptom | Likely cause | Fix |
|---|---|---|
| Sessions are all shifted by exactly 1 hour | DST shift applied when it should not be, or not applied when it should be | Check `InpDSTMode` against your broker's actual DST rule (§3). Check the date: are you inside or outside the DST window? Remember the US and EU windows differ by weeks in March and October. |
| Sessions are shifted by 30 minutes (or another non-hour amount) | `InpBrokerGMTOffset` is a whole hour but your broker is on a half-hour (or 45-minute) offset | Set the offset as a double (e.g. 5.5). See Example 3. |
| Sessions are shifted by several hours | `InpBrokerGMTOffset` has the wrong sign or the wrong value | Re-measure: chart clock minus UTC. East = positive. |
| A session shows "not started — no bars yet" all day | The window, converted to broker time, falls outside available history — or the offset is so wrong the window is in the future | Check the offset first. Then check H1 history for that symbol. |
| Current session says a session name on Saturday | The recency test should prevent this | Check that the chart is actually receiving bars (a frozen feed can leave a "current" bar that is recent in the terminal's view). If the market is closed and the label persists, note the exact time and symbol — it is a defect. |
| Custom session does not appear | Malformed string, or the name part is wrong | Check the Experts tab for the malformed-session message. Format is `"HH:MM-HH:MM"` with an optional `\|Name`. No spaces around the hyphen. |
| Opening range is `DATA UNAVAILABLE` after the session opened | No M15 bars in the range window (missing M15 history) | Scroll the M15 chart left to download history. The range needs M15 bars; H1 history alone is not enough. |
| Opening range looks like the day-start range (00:00–00:30) | `InpOpeningRangeSession` is set to Day start | Set it back to `FBPI_OR_NEWYORK` (or London) unless you deliberately want the day-start range. |
| Everything was right, then wrong after a broker DST change | The broker changed its DST rule or server timezone | Re-run the checklist in §8. Do not "fix" it by editing the session times — the session times are UTC and did not change; the offset did. |

*End of Session Configuration Guide — FBPI-MT4-001 v1.0.*
