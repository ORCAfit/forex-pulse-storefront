# Forex Bigger Picture Intelligence System — Technical Architecture

| Field | Value |
|---|---|
| Project ID | FBPI-MT4-001 |
| Product | Forex Bigger Picture Intelligence System v1.0 |
| Platform | MetaTrader 4 (MT4), MQL4 build 600+, `#property strict` |
| Spec | `FBPI-MT4-001-spec.md` v1.0 (source of truth; this document is the Phase 1 design authority under it) |
| Phase | Phase 1 — Technical specification and architecture (spec §18, §21) |
| Date | 2026-11-27 |
| Companion documents | `docs/Data_Source_Register.md` (every datum classified), `include/FBPI_Common.mqh` (the code contract), `PHASE1_HANDOFF.md` (module build order + signatures) |
| Reference implementation | FLR-MT4-001 (`~/workspace/projects/forex-level-radar-pro/`): `Forex_Level_Radar_Pro.mq4` (1,774 lines), `docs/Technical_Architecture.md`, `docs/Test_Report.md` |

> **Authority note.** Where this document and the spec disagree, the disagreement is listed in §8 as a divergence with a reason — it is never silently resolved in favour of the code. Where this document and FLR differ, the difference is deliberate and is listed in §8 with the FLR lesson that motivated it. The finished indicator must satisfy spec §20 (final acceptance standard); this document is the plan for getting there, not a claim that it is already built.

> **What Phase 1 does NOT do.** No dashboard is built in this phase (spec §21: calculations before dashboard). No module `.mqh` is written except the shared header. No `.ex4` is produced — there is no MetaEditor compiler in this environment, and none is claimed.

---

## 1. Overview

FBPI is a **multi-file indicator with 13 included modules** (`FBPI_Main.mq4` + `FBPI_Common.mqh` + 13 module headers, spec §13). It is an **analytical indicator only**: it never places, modifies, or closes trades. No `OrderSend`, `OrderModify`, `OrderClose`, `OrderDelete`, `OrderSelect` (for trading), `#import`, `WebRequest`, DLL, or paid external service exists anywhere in the system.

The system is a descending analytical funnel in five stages, covering 23 layers:

```
GLOBAL CONTEXT            L1  Global Economy          (manual / unavailable by default)
                          L2  Monetary Policy         (manual / unavailable by default)
                          L3  Financial Conditions    (manual / unavailable by default)
                          L4  Global Markets          (broker symbols: Gold, Oil, indices)
                          L5  Asset Class             (calculated ranking from L4)
                          L6  Market Index            (broker symbols)
                          L7  Futures Contract        (DATA UNAVAILABLE by default)
        │
        ▼
MARKET STRUCTURE          L8  Quarterly Structure     (native, H1 bars)
                          L9  Monthly Structure       (native)
                          L10 Weekly Context          (native)
                          L11 Daily Context           (native: PDH/PDL/PDC/PDO/DO/ADR)
        │
        ▼
SESSION INTELLIGENCE      L12 Trading Session         (native, UTC + broker offset + DST)
                          L13 Opening Range           (native, session-anchored)
                          L14 Intraday Auction        (native, measurable behaviour only)
        │
        ▼
VOLUME & LIQUIDITY        L15 Volume Profile          (native tick volume, labelled)
                          L16 Value Area              (native, 70% default)
                          L17 Key Levels + probability (native, Wilson interval)
                          L18 Order Book              (ORDER BOOK UNAVAILABLE by default)
                          L19 Order Flow              (ESTIMATED TICK ACTIVITY by default)
                          L20 Footprint Candle        (ESTIMATED TICK ACTIVITY by default)
        │
        ▼
CONFIRMATION → RISK → EXECUTION
                          L21 Confirmation            (native score 0-100, missing data = 0)
                          L22 Risk Plan               ($5,000 / 0.5% / 2% / min 1:2)
                          L23 Execution Readiness     (6 statuses, human approval only)
```

### 1.1 Design principles

1. **Closed bars are the only source of truth for history.** Every aggregation scans `PERIOD_H1` bars (FLR-proven: an H1 bar's high/low are the true extremes of that hour, and the scan stays cheap). Daily/session/quarterly/monthly/weekly extremes are therefore exact. Live (still-forming) bars are used only for *live status* labels, never for a frozen forecast, a finalised scoreboard row, or a classified liquidity event.
2. **Provisional vs final is a property of the window, not of the data.** A level is final when its source window has closed; until then it is the running extreme. Scans are capped at `min(windowEnd, now)`.
3. **Probabilities are computed from the past only.** For a forecast day D, the level is reconstructed from days before D and evaluated only inside D. Today (day 0) is excluded from every lookback loop. No look-ahead, by construction of the loop bounds — not by convention.
4. **Finalised records are append-only and never revised.** Scoreboard rows are written once, deduplicated by `symbol|trading_day|level`, and never edited. Open (unfinalised) forecasts are persisted to a `Forecasts_<Symbol>.csv` file at capture time, so a terminal restart across a day boundary does not lose them (FLR limitation L6a fixed).
5. **The display never writes market data.** The dashboard (Phase 10) reads globals and creates chart objects; it never modifies a level, a probability, a scoreboard row, or a risk plan.
6. **Missing data is a first-class state, not a zero.** Every datum carries an `ENUM_FBPI_AVAIL` flag (`FBPI_Common.mqh` §2). Unavailable data is displayed as `DATA UNAVAILABLE` / `ORDER BOOK UNAVAILABLE` / `INSUFFICIENT DATA (N=…)` in grey — never as 0, never as a substitute value, never hidden without a trace.
7. **Calculations before dashboard.** Modules are built and tested in funnel order (Phases 2–9) before the dashboard (Phase 10) reads them. A dashboard panel may only display a value a calculation module has already produced and flagged.
8. **One recalculation path.** `FBPI_Main_RecalcAll()` (in the main file) runs the modules in dependency order on a new bar, on first calculation, on input change, and on timer expiry — never on a bare tick. Ticks between recalculations refresh only live price labels. Probabilities are recomputed only on a new bar / forecast time / input change, never on a timer tick (FLR inefficiency A13 fixed).

### 1.2 What FLR proved, and what FBPI reuses

| FLR pattern (proven) | FBPI reuse | Where |
|---|---|---|
| UTC session handling with broker offset + DST | Reused, but fixed: offset is `double` (half-hours), session times are `"HH:MM"` strings, DST is rule-based (US/EU/Manual/Off), not a month heuristic | §4.4, §8 D-3/D-4/D-5 |
| Historical touch-probability engine (lookback loop, forecast-from-earlier-days, eval window to cutoff) | Reused, with the touch test fixed (see §4.6) and Wilson interval added | §4.6 |
| File-based scoreboard persistence (CSV, dedup keys, aggregates rebuilt on load) | Reused, with the 21-column format, header validation, open-forecast persistence, and failed-breakout recording | §6 |
| Parallel-global state + `RecalcAll()` ordering + timer gating | Reused as the event model, but FBPI state is held in the structs defined in `FBPI_Common.mqh` (`LevelInfo`, `SessionInfo`, `ProfileResult`, `RiskPlan`, `TradeSetup`) rather than FLR's parallel arrays | §2, §3 |
| Dark theme, gold accent, `FLR_` object prefix, `ObjectsDeleteAll` cleanup | Reused as `FBPI_` prefix and the colour constants in `FBPI_Common.mqh` §5 | §7 |

---

## 2. Module dependency map

Thirteen modules plus the main file and the shared header. An arrow `A → B` means **A depends on B** (B must be built and tested first). The build order is the topological order of this map; it is also the order in `PHASE1_HANDOFF.md` §1.

```
FBPI_Common.mqh  (contract: enums, structs, globals, helpers — no dependencies)
        │
        ▼
FBPI_Storage ──────────────┐  (file I/O primitives; no market logic)
        │                  │
        ▼                  ▼
FBPI_Macro                 │  (L1-L3 manual data; L4-L7 cross-market quotes)
        │                  │
        ▼                  ▼
FBPI_MarketStructure ──────┤  (L8-L11; needs Storage for nothing, Macro for nothing)
        │                  │   — pure H1 calculation
        ▼                  ▼
FBPI_Sessions ─────────────┤  (L12; needs MarketStructure's day-start)
        │                  │
        ▼                  ▼
FBPI_OpeningRange ─────────┤  (L13; needs Sessions for the anchor open)
        │                  │
        ▼                  ▼
FBPI_Auction ──────────────┤  (L14; needs MarketStructure + Sessions + OpeningRange)
        │                  │
        ▼                  ▼
FBPI_VolumeProfile ────────┤  (L15-L16; needs Sessions for session/weekly scopes)
        │                  │
        ▼                  ▼
FBPI_Liquidity ────────────┤  (L17; needs MarketStructure + Sessions + OpeningRange
        │                  │   + VolumeProfile for POC/VAH/VAL levels)
        ▼                  ▼
FBPI_OrderFlow ────────────┤  (L18-L20; needs VolumeProfile; mostly unavailable
        │                  │   by default — interface + ESTIMATED TICK ACTIVITY mode)
        ▼                  ▼
FBPI_Confirmation ─────────┤  (L21; needs MarketStructure + Sessions + Auction
        │                  │   + Liquidity + OrderFlow + VolumeProfile)
        ▼                  ▼
FBPI_Risk ─────────────────┤  (L22; needs Confirmation's setup + MarketInfo)
        │                  │
        ▼                  ▼
FBPI_Statistics ───────────┤  (L12 scoreboard; needs Liquidity + Storage +
        │                  │   Confirmation; runs at day rollover)
        ▼                  ▼
FBPI_Dashboard ────────────┘  (L8 + §8; needs EVERYTHING above — built LAST, Phase 10)
        │
        ▼
FBPI_Main.mq4  (event handlers, input declarations, RecalcAll ordering,
                validation, alerts dispatch — includes all of the above)
```

**Dependency rules (binding):**

- A module may only read globals owned by a module earlier in the build order, or its own globals. It may only write its own globals (declared in `FBPI_Common.mqh` §6).
- No module includes another module's `.mqh` directly. All cross-module communication goes through the shared globals in `FBPI_Common.mqh` and the function signatures in `PHASE1_HANDOFF.md` §2. The main file is the only file that includes module headers.
- `FBPI_Storage` has no market logic and no dependency on any other module; it is built first (with `FBPI_Common.mqh`) so every later module can persist through it.
- `FBPI_Dashboard` is built last (Phase 10). It must not contain any calculation: if a value is not already in a global, the dashboard shows `DATA UNAVAILABLE` and the missing calculation is a Phase 2–9 defect, not a dashboard feature.
- Circular dependencies are forbidden. If a later module seems to need an earlier module to read its output, the design is wrong: split the shared computation into the earlier module.

## 3. Shared data structures

All structures are defined in `include/FBPI_Common.mqh` §3. This section states their *meaning and invariants*; the header is authoritative for field names and types.

| Struct | Owner module | Key invariants |
|---|---|---|
| `LevelInfo` (29 kinds, `ENUM_FBPI_LEVEL`) | MarketStructure / Sessions / OpeningRange / VolumeProfile / Liquidity | `price == FBPI_INVALID_DOUBLE` iff `valid == false`. `isFinal` is true only after the source window closed. `touchDir` is `NEUTRAL` only for PDC. `stats.valid` is true only when `stats.eligible >= InpMinSample`; a probability is never displayed without `stats.eligible`. |
| `TouchStats` | Liquidity (probability engine) | `probPct` is touches/eligible×100 over completed days only. `wilsonLow/High` are always computed when `valid`. `brier` is the mean `(f−o)²` over finalised days, or −1 when no finalised day exists. Per-day-of-week counts are kept but only displayed with their own N. |
| `SessionInfo` (3 + 3 custom) | Sessions | All times are **broker datetimes**. `active` is true only inside `[start, end)`. `valid` is false before the first bar in the window. Weekend: all sessions `active == false`, status `Closed`. |
| `ProfileResult` (daily / session / weekly) | VolumeProfile | `flowMode` is `FBPI_FLOW_ESTIMATED_TICK` unless a genuine external volume feed is configured. `binVolume[]` sums to `totalVolume`. `pricePos` is derived from Bid vs VAH/VAL at calculation time. |
| `ConfirmationFactor` (6) | Confirmation | `score == 0` whenever `hasData == false`. `score <= weight` always. `evidence` is a one-line, checkable reason — never a bare number. |
| `RiskPlan` | Risk | `pipValue` comes from `MarketInfo`, never assumed. `positionSize` is rounded **down** to the broker lot step; if it rounds to below the broker minimum, `violatesLotStep == true` and the plan is rejected. `rewardRisk` is −1 when there is no valid stop. No field in this struct can cause an order: there is no order function in the system. |
| `TradeSetup` | Confirmation + Risk (assembled) | `hasSetup == false` until a setup is identified. `status` is exactly one `ENUM_FBPI_EXEC_STATUS`. `identifiedAt` is the first identification time and never moves. |
| `MacroObservation` (8 banks + 12 cross-market) | Macro | `avail == UNAVAILABLE` until a value is supplied with a source and timestamp. A value older than the configured max age is `STALE`, not current. |
| `SweepEvent` (ring buffer, 100) | Liquidity | `excursionBarTime` and `confirmBarTime` are **bar open times**, not tick times (FLR limitation L6c fixed). Failed breakouts are recorded as events, not silently dropped (FLR gap D7 fixed). |
| `MTFRow` (9 timeframes) | MarketStructure | `valid == false` when that timeframe has too few bars; the row shows `—`, not a guessed direction. |
| `ScoreboardRow` (21 columns) | Statistics | One row per (symbol, trading day, level). `lateIssued` marks a forecast computed after its nominal time. `outcome == -1` until finalised. Rows are never edited after being written. |
| `AlertState` | Main (dispatch) | One throttle timestamp per (alert type, key). A fired alert is never re-fired inside `InpAlertCooldownMinutes`. |

**Global-state pattern** (`FBPI_Common.mqh` §6): all shared state is global, defined once in the common header, named `g_fbpi*`. No module declares its own global without adding it to that section and documenting it here. Daily state (`g_fbpiSweepCount`, `g_fbpiBreakoutCount`, per-level `touchedToday`) resets in `CheckNewDay()` in the main file; forecast state is frozen once per day and never overwritten; scoreboard aggregates are rebuilt from the CSV on load and are a cache of the file, not the record itself.

---

## 4. Calculation specifications per layer

### 4.1 Reference frame (applies to Layers 8–14, 17)

- **Trading day starts at `InpDayStartUTC` (default 00:00 UTC).** All daily windows are computed in UTC and converted to broker time for bar lookup. This is a deliberate correction of FLR divergence D-3 (broker-midnight day start): the reference frame is UTC, the broker offset only shifts the lookup.
- **Broker offset is a `double` in hours** (`InpBrokerGMTOffset`, range −12…+14, step 0.5 — half-hour offsets such as +5.5 are representable; FLR used `int` and could not represent them).
- **Session times are `"HH:MM"` strings** (`InpAsianStartUTC = "00:00"`, etc.), parsed by `FBPI_ParseHHMM()` in the common header. Integer-hour sessions (FLR) could not express 07:30.
- **DST is rule-based** (`ENUM_FBPI_DST`: Off / US / EU / Manual). US: second Sunday in March to first Sunday in November. EU: last Sunday in March to last Sunday in October. Manual: `InpDSTShiftHours` applied unconditionally. FLR's month heuristic (April–October) is not used.
- **Cutoff is 21:00 UTC** (`InpCutoffHourUTC` = 21), applied in the UTC frame. FLR applied it as 21:00 broker time.
- **Aggregation primitive:** `FBPI_ScanHighLow(symbol, startBroker, endBroker, &hi, &lo, &open, &close)` — H1 bars whose open time lies in `[start, end)`, via `iBarShift()`. Returns `false` when no bar exists; the caller leaves the level invalid rather than inventing a price. This is the FLR `ScanHighLow()` pattern, re-expressed as a shared helper in the MarketStructure module (not in the common header, because it needs the scan logic, not just the contract).

### 4.2 Layers 1–3 — Global Economy, Monetary Policy, Financial Conditions (FBPI_Macro)

No native calculation exists for any of these layers. The module's job is **record-keeping with provenance**: it holds the `MacroObservation` arrays, validates manual inputs (a rate must be −5…+25 %, a date must parse as `yyyy.mm.dd`), applies the staleness rule, and computes the **one** native derivation in these layers — the interest-rate differential (base rate − quote rate, in percentage points) — only when both rates are present. The dashboard (Phase 10) reads `g_fbpiMacro[]` and displays source + timestamp per observation. Default display for the whole of Section A of the dashboard is `DATA UNAVAILABLE` until the user enters values.

### 4.3 Layer 4–7 — Global Markets, Asset Class, Market Index, Futures (FBPI_Macro)

- **Quotes:** for each configured broker symbol, current price (`MarketInfo MODE_BID`), daily change % (vs prior trading-day close, H1/D1 bars), daily high/low. A symbol the broker does not offer yields `avail == UNAVAILABLE` for that row — the symbol is never guessed from a similar name.
- **Gold** (`InpGoldSymbol`, default `XAUUSD`) is the priority general market indicator; **Oil** (`InpOilSymbol`, default `XTIUSD`) is the CAD-related indicator (spec §3 L4).
- **Correlation:** Pearson correlation of daily closes over `InpCorrLookback` (default 20) days between two series, computed only when both series have the full lookback. Displayed with the lookback and the warning "correlation is not permanent and not causal".
- **Asset class (L5):** ranking of daily % change across the class proxies (see Data Source Register L5). No class is given a value without a proxy.
- **Futures (L7):** the module exposes a futures row per configured symbol, but with no configured external feed the row is `DATA UNAVAILABLE`. A broker futures CFD, if the user configures one, is shown in a separate row labelled **broker CFD — not exchange futures**. Spot, CFD, and futures prices are never merged.

### 4.4 Layers 8–11 — Higher-timeframe structure (FBPI_MarketStructure)

| Layer | Calculation (all from H1 bars unless stated) |
|---|---|
| L8 Quarterly | Quarter window from calendar quarter of the trading day. High/low = extremes of H1 bars in the window; open = first bar's open; close = last closed bar's close. Range, position % = (Bid−low)/(high−low). Trend from quarterly closes (current vs prior quarter close + HH/HL sequence). Classification: position ≥ 66.7% → upper, ≤ 33.3% → lower, else midrange; range vs prior-quarter range > 110% → expanding, < 90% → contracting. |
| L9 Monthly | As quarterly, on calendar months. Structure from the last 3 monthly closes: HH+HL → bullish, LL+LH → bearish, else consolidation; a close beyond the prior month's high/low → breakout (confirmed only on the monthly close). Fewer than 3 monthly closes → `INSUFFICIENT DATA`. |
| L10 Weekly | Week = Monday 00:00 UTC to Sunday 21:00 UTC cutoff (trading week). Previous week high/low/close from the prior completed week; current week open/high/low from the current week. Expansion/contraction vs prior week and vs the 12-week average range. |
| L11 Daily | PDH/PDL/PDC/PDO from the previous completed trading day; DO from the current day's first bar open. ADR = mean daily range over `InpADRPeriod` (default 14) completed days. Current range as % of ADR; distance to PDH/PDL in pips (symbol-aware, `FBPI_PointsPerPip()`). Daily structure from daily closes. |
| Multi-timeframe table (spec §9) | One `MTFRow` per timeframe M1/M5/M15/M30/H1/H4/D1/W1/MN1: direction from the last two completed closes on that timeframe plus HH/HL or LL/LH structure; `valid == false` when fewer than 20 bars exist on that timeframe. Never hardcoded. |

### 4.5 Layers 12–14 — Sessions, Opening Range, Auction (FBPI_Sessions, FBPI_OpeningRange, FBPI_Auction)

**L12 Sessions.** `FBPI_Session_WindowForDay(dayStartUTC, startHHMM, endHHMM)` converts a UTC window to broker datetimes: UTC midnight + minutes + broker offset (offset in minutes, DST-adjusted per the rule in §4.1). That offset is the single configured regime (`FBPI_ConfiguredBrokerOffsetMinutes()`: `InpBrokerGMTOffset` + rule-based DST shift) — the same offset the trading-day anchors use, so session windows and structure/liquidity windows can no longer drift apart (QA N-6). `OnInit` compares it against the live-clock offset (`TimeCurrent() − TimeGMT()`) and `Print`s a warning if they differ by more than 15 minutes, telling the user to check `InpBrokerGMTOffset` / `InpDSTMode`. Windows crossing midnight (`end <= start`) get +24 h. Current session is derived from the UTC time: New York takes priority over London, London over Asian (overlaps are intentional); the overlap window (12:00–16:00 UTC default) is reported as `FBPI_SESS_OVERLAP` with both sessions named. Up to 3 custom windows (`InpCustomSession1..3`, `"HH:MM-HH:MM"` + name) may replace or supplement the standard three; a custom window is checked first. Market status is `Active` inside any session, `Closed` otherwise (including weekends — the UTC-hour test alone would return a session name on a Saturday, so the status also requires a current bar within the last 10 minutes). Session levels (ASH/ASL, LONH/LONL, NYH/NYL, opens) are H1 scans of each window capped at `min(windowEnd, now)`; a session that has not started is invalid, not zero. London breakout = London close vs ASH/ASL; NY continuation/reversal = NY close vs LONH/LONL.

**L13 Opening Range.** The range is the first `InpOpeningRangeMinutes` (15/30/60) after the open of `InpOpeningRangeSession` (default New York — FLR started the range at the trading-day start, which computed a 00:00–00:30 range; that is corrected here). Independent London and New York ranges are computed when `InpShowLondonOR` / `InpShowNewYorkOR` are true. ORH/ORL/midpoint from M15 bars (finer than H1: a 15-minute range needs M15 granularity) inside the window. Breakout above/below, failed breakout, retest, rejection are classified on **closed bars only**, using the same state machine as §4.7.

**L14 Auction.** Classification from measurable behaviour on closed bars (`ENUM_FBPI_AUCTION`): candle range vs ATR(14) on the chart timeframe; HH/HL vs LH/LL sequences over the last 10 closed bars; closing-price location within the bar's range; range expansion (current range > 1.5 × 20-bar mean range); breakout persistence (closes beyond a level for `InpBreakoutBars` bars). Decision table (documented in the Auction module header when built): trend requires a directional HH/HL or LH/LL sequence **and** closes beyond the prior extreme; balance requires closes inside the value area for 5+ bars; consolidation requires contracting ranges; expansion requires range > 1.5 × mean; reversal requires a structure shift (break of the last swing) **and** a close beyond the prior extreme; failed breakout and range rejection follow §4.7. Fewer than `InpAuctionMinBars` (10) closed bars → `FBPI_AUCTION_UNKNOWN`. The dashboard shows the measurements behind the classification, never a claim about institutional intent.

### 4.6 Layers 15–17 — Volume Profile, Value Area, Key Levels (FBPI_VolumeProfile, FBPI_Liquidity)

**L15 Volume Profile.** Price-binned profile from **broker tick volume** (`iVolume` on H1 bars), `InpProfileBins` (default 24) equal-width bins across the scope's high–low. POC = the bin with the greatest tick volume. High-volume nodes = bins ≥ 150% of mean bin volume; low-volume nodes = bins ≤ 50% of mean. Scopes: daily (current trading day), session (current session window), weekly (current trading week). The profile heading always carries the source label: `Tick volume` by default. If an external futures-volume feed is ever configured, its profile is a separate `ProfileResult` with `flowMode == FBPI_FLOW_TRUE_BIDASK` and the feed's name as `sourceLabel` — the two are never mixed in one profile. Fewer than 10 bars in scope → invalid.

**L16 Value Area.** From the profile, the smallest contiguous price range around the POC containing `InpValueAreaPct` (default 70%) of total tick volume → VAH (top) / VAL (bottom). Price vs value: above VAH / inside / below VAL. Acceptance = 3 consecutive closed bars (`InpVAConfirmBars`) inside the value area after being outside; rejection = a wick beyond VAH/VAL with a close back inside; migration = POC moved by more than one bin vs the prior scope's POC. The method is documented in `docs/Volume_Profile_Methodology.md` (Phase 5 deliverable).

**L17 Key Levels + probability engine.** The 28 level kinds (`ENUM_FBPI_LEVEL`) are assembled from Layers 8–13 and 15–16 into `g_fbpiLevels[]`. For the 7 probability levels (PDH, PDL, PDC, ONH, ONL, ORH, ORL — the FLR set, kept for continuity), the engine is the FLR loop with three fixes:

1. **Touch test (the FLR tautology fix).** `FBPI_BarTouchesLevel()` in the common header: upward → `High >= level`; downward → `Low <= level`; **neutral (PDC) → `High >= level AND Low <= level`** (the bar's range contains the level). The OR form is a tautology — true for every bar — and made FLR's PDC probability always 100%. It is forbidden in FBPI. The same direction-aware test is used for the live status, the alert path, and the probability loop — one helper, four call sites (Sessions `CountTouches`, MarketStructure `UpdateTouchedToday`, Liquidity `TouchInWindow`, Statistics finalisation), no divergent copies (FLR had three different touch tests).
2. **Overnight levels are genuine.** ONH/ONL use the overnight window `[21:00 UTC previous day, 07:00 UTC current day)`, which crosses the trading-day boundary. They are **not** the Asian session high/low (FLR divergence D-1). The overnight window is computed by a dedicated scan that spans the boundary.
3. **Spread adjustment narrows.** `FBPI_TOUCH_SPREAD_ADJ` moves the level *against* the touch (up: `level + spread`; down: `level − spread`). FLR widened the zone (`level − adj`), making touches easier — the opposite of the spec. Default method is `FBPI_TOUCH_HIGH_LOW` with adjustment 0, so the default behaviour is identical to FLR's at defaults.

Probability formula (unchanged from FLR, which was correct): for each past day D in 1…`InpProbLookback`, reconstruct D's forecast level from days before D only, evaluate the touch inside D's window (day start → 21:00 UTC cutoff; ONH/ONL from the Asian session end → cutoff; ORH/ORL from the end of the opening range → cutoff), count eligible days and touches, `prob = touches / eligible × 100`. **Wilson 95% interval** (`FBPI_WilsonInterval()`, z = 1.96) is computed for every probability and displayed with it (FLR omitted it entirely). The shared UTC helpers in `FBPI_Common.mqh` are `FBPI_ConfiguredBrokerOffsetMinutes(t)` (the single broker-offset regime: configured `InpBrokerGMTOffset` + rule-based DST shift — QA N-6), `FBPI_DSTShiftMinutes(t)` (the DST rules), `FBPI_BrokerOffsetMinutes()` (live-clock broker offset in minutes, kept only as the comparator for the `OnInit` startup validation), `FBPI_UTCMidnight()` (00:00 UTC of a UTC day), `FBPI_TradingDayLengthSec()` (length of [day start, cutoff) in seconds — 21 h / 75,600 s at defaults), `FBPI_TradingDayAnchors()` (broker-time dayStart/utcMid/dayStartMin for the current trading day), and `FBPI_UTCDayCount()` (UTC day number of a broker-time UTC-midnight anchor). Liquidity, Statistics, VolumeProfile, MarketStructure and Sessions build their day anchors and windows from the configured regime, so the forecast, finalisation, profile and session windows share one trading-day definition and one offset. No probability is displayed without N; `N < InpMinSample` (20) → `INSUFFICIENT DATA (N=…)`, and no scoreboard row is written for that level that day. A window partly outside available history is handled as FLR limitation A21 was not: the day is excluded from N. There is no `historyShort` flag field in any struct — short history is signalled only through `eligible < lookback` (a day whose source window starts before the earliest H1 bar is excluded), so the dashboard cannot show a distinct "history too short" state.

### 4.7 Liquidity classification (FBPI_Liquidity — sweep vs breakout vs failed breakout)

State machine per monitored level (PDH, PDL, ASH, ASL, LONH, LONL, ORH, ORL), on **closed bars only** — FLR triggered the excursion on the live Bid (a tick) and classified on the wrong bar's close; FBPI detects the excursion on a closed bar's High/Low and classifies on later closed bars:

1. **Not exceeded.** A closed bar whose High (buy-side) / Low (sell-side) is beyond the level opens an excursion: record `excursionBarTime` (that bar's open time), `excursionMax`, `barsToConfirm = 0`, `closedBeyond = false`.
2. **Exceeded.** On each subsequent closed bar: update `excursionMax`; if the bar's Close is beyond the level, set `closedBeyond = true`; increment `barsToConfirm`.
   - **Close back inside** within `InpConfirmBars` bars **and** `closedBeyond == false` → **sweep** (`FBPI_LIQ_SWEEP_UP/DOWN`): record a `SweepEvent`, draw the marker, fire the sweep alert (throttled).
   - **Close back inside after a close beyond** (`closedBeyond == true`) → **failed breakout** (`FBPI_LIQ_FAILED_BREAKOUT_UP/DOWN`): record a `SweepEvent` of that kind (FLR detected this shape but did not record it), clear state, no sweep counted.
   - **Still beyond** after `InpBreakoutBars` bars → **sustained breakout** (`FBPI_LIQ_BREAKOUT_UP/DOWN`): count it, clear state.
   - **Close back inside too late** (after `InpConfirmBars` but before `InpBreakoutBars`, no close beyond) → state dropped silently, no event.
3. State resets at the day rollover. Daily counters (`g_fbpiSweepCount`, `g_fbpiBreakoutCount`) reset in `CheckNewDay()` (FLR bug A6: they never reset).

### 4.8 Layers 18–20 — Order Book, Order Flow, Footprint (FBPI_OrderFlow)

This module is an **interface plus honest fallback**, not a data source. It defines the `ENUM_FBPI_FLOW_MODE` states and the record shapes a future feed would fill, and it implements the two things that exist today:

- **Order book (L18):** no genuine depth source is configured in v1. The module returns `avail == UNAVAILABLE` and the dashboard shows `ORDER BOOK UNAVAILABLE`. The module must contain a single, clearly-marked integration point (`FBPI_OrderFlow_SetDepthSource()`) for a future feed — but no feed is written in v1, and no depth value is ever synthesised.
- **Order flow / footprint (L19–L20):** the **estimated** mode. Delta proxy per bar = tick volume × sign(close − open); cumulative delta is the running sum; imbalance = (up-tick-volume − down-tick-volume) / total tick volume per price bin. Every value produced in this mode carries `flowMode == FBPI_FLOW_ESTIMATED_TICK` and the dashboard labels the panel **ESTIMATED TICK ACTIVITY — not true bid/ask footprint**. True bid/ask mode (`FBPI_FLOW_TRUE_BIDASK`) is implemented only as the record shape; it activates only when `InpOrderFlowSource` names a configured feed, which v1 does not provide.

### 4.9 Layer 21 — Confirmation (FBPI_Confirmation)

Six factors, weights as inputs defaulting to 20/20/20/20/10/10 = 100 (`InpWeightHTF`, `InpWeightLevel`, `InpWeightLiquidity`, `InpWeightStructure`, `InpWeightCandle`, `InpWeightSession`). Each factor is scored 0…weight by a documented rule (the module header states the rule per factor when built; the rules below are the Phase 1 specification):

| Factor | Full points when | Zero when |
|---|---|---|
| HTF Alignment (20) | MN1, W1, D1 directions agree (from `g_fbpiMTF`) | Any of MN1/W1/D1 invalid, or directions conflict (partial credit 10 when 2 of 3 agree — documented in the module) |
| Key-Level Location (20) | Price is at/near a key level (within `InpApproachPips`, 5.0 pips) with the level's historical probability ≥ 65% | No level within proximity, or the level's probability is insufficient data |
| Liquidity Event (20) | A sweep in the setup direction occurred within `FBPI_CONF_LIQ_LOOKBACK_BARS` (20) bars | No sweep/failed-breakout event in the direction (a failed breakout in the opposite direction scores 0, not negative) |
| Market Structure (20) | Structure shift (break of swing + close beyond) in the setup direction on H1/H4 | No shift, or shift against the direction |
| Candle Confirmation (10) | Last closed candle closes beyond the level / engulfing in the direction (closed candle only when `InpRequireClosedCandle` is true) | No confirming close |
| Session Alignment (10) | Current session is London or New York (or the overlap) and the setup direction matches the session direction so far | Session is Asian with no London/NY confirmation, or no session active |

**Missing data scores ZERO, never positive, by default** (spec §7 L21). Each factor row shows its evidence string. Bands: Strong 80–100, Moderate 65–79, Weak 50–64, Insufficient < 50 (thresholds are inputs). The score is an analytical score, not an empirically established probability — the dashboard carries the footnote "Confirmation scores are analytical, not probabilities."

### 4.10 Layer 22 — Risk Plan (FBPI_Risk)

Inputs: `InpPaperCapital` = 5000, `InpRiskPct` = 0.5, `InpMaxDailyLossPct` = 2.0, `InpMinRR` = 2.0, `InpPrefRR` = 3.0, `InpAccountCurrency` = `"USD"`, `InpCommissionPerLot` = 0. Calculations, per setup (or per manual plan inputs `InpPlanEntry`/`InpPlanStop`/`InpPlanTarget`, 0 = use the setup):

- `riskAmount = capital × riskPct / 100` (= $25.00 at defaults).
- `stopDistancePips = |entry − stop| / (point × pointsPerPip)` — symbol-aware via `FBPI_PointsPerPip()`; never a universal pip value.
- `pipValue` (per 1.0 lot) from `MarketInfo(symbol, MODE_TICKVALUE)` adjusted by `MODE_TICKSIZE`/`MODE_POINT`; if `MarketInfo` returns 0, pip value is `DATA UNAVAILABLE` and the plan is rejected (no assumed value).
- `positionSize = riskAmount / (stopDistancePips × pipValue)`, rounded **down** to `MODE_LOTSTEP`, clamped to `MODE_MINLOT`…`MODE_MAXLOT`; rounding below the minimum → `violatesLotStep`, plan rejected.
- `spreadCost = spread (points) × pip value at positionSize`; `commission = InpCommissionPerLot × positionSize`.
- `potentialProfit = |target − entry| in pips × pipValue × positionSize`; `rewardRisk = potentialProfit / riskAmount`.
- Violations (any one rejects the plan): `rewardRisk < InpMinRR` → `violatesMinRR`; `InpDailyLossSoFar + riskAmount > maxDailyLoss` → `violatesDailyLoss` (daily loss is a manual input — the indicator never reads a broker account); position size rounding below `MODE_MINLOT` → `violatesLotStep` (see above); **spread in pips ≥ stop distance in pips** → rejected with the warning `Spread (X pips) is at least as large as the stop distance (Y pips)` (one decimal each, from `FBPI_Risk_Plan()` in `FBPI_Risk.mqh`; unlike the other three violations it has no dedicated flag — it is recorded only in the plan's `violationText`). Any violation → `riskValid == false`, status `REJECTED — RISK RULE VIOLATION`, and the dashboard shows the reason. The indicator never recommends increasing risk to recover losses.
- `InpDailyLossSoFar` defaults to 0 with the note "daily loss not entered — enter it to enforce the daily limit".

### 4.11 Layer 23 — Execution Readiness (FBPI_Risk + FBPI_Confirmation → FBPI_Dashboard)

The execution panel is an assembly, not a calculation: it reads the `TradeSetup` (direction, entry, SL, TP, size, risk %, R:R, confirmation score, session, key level, liquidity event, rationale) and the `RiskPlan`, and derives the status by this state machine (evaluated in order):

1. No setup identified → `ANALYSIS INCOMPLETE`.
2. Setup identified, confirmation < `InpMinConfScore` (default 50) → `WAITING FOR CONFIRMATION`.
3. Confirmation ≥ minimum → `SETUP IDENTIFIED`.
4. Risk plan valid → `RISK VALIDATED`.
5. Risk valid **and** confirmation ≥ `InpMinConfScore` **and** all required data present → `READY FOR HUMAN REVIEW`.
6. Any risk violation → `REJECTED — RISK RULE VIOLATION` (overrides all other states).

The panel displays the full checklist from spec L23. It contains no button, no order function, and no link that could place a trade. "READY FOR HUMAN REVIEW" means a human must now decide, outside the indicator.

---

## 5. Input specification (summary — full list in PHASE1_HANDOFF.md §4)

Inputs live **only** in `FBPI_Main.mq4`, named `Inp*`, grouped with `input group` (FLR pattern). Defaults locked in Phase 1 (changing a default later requires amending this document):

| Group | Key inputs (defaults) |
|---|---|
| General | `InpShowDashboard=true`, `InpDashCorner=CORNER_LEFT_UPPER`, `InpDashX=10`, `InpDashY=15`, `InpTheme=FBPI_THEME_DARK`, `InpRefreshSeconds=5` (1–300; 0 = no timer is **not** supported — FLR D-19 noted the same gap; FBPI keeps 1–300 and documents it), `InpHistoryDays=200` |
| Symbols | `InpWatchlist` = the 15 spec pairs (see §5.1), `InpSymbolPrefix=""`, `InpSymbolSuffix=""`, `InpGoldSymbol="XAUUSD"`, `InpOilSymbol="XTIUSD"`, `InpIndexSymbols="US30,SPX500,NAS100"` |
| Macro | `InpGlobalCondition`, `InpRate_<CCY>` × 8, `InpMacroMaxAgeHours=168`, `InpRateMaxAgeHours=2160` (see Data Source Register) |
| Structure | `InpADRPeriod=14`, `InpWeeklyLookback=12`, `InpShowQuarterly/Monthly/Weekly/Daily=true` |
| Sessions | `InpUseUTCReference=true`, `InpBrokerGMTOffset=0.0` (**double**), `InpDSTMode=FBPI_DST_US`, `InpDSTShiftHours=1.0`, session times as `"HH:MM"` strings (Asian `"00:00"–"09:00"`, London `"07:00"–"16:00"`, NY `"12:00"–"21:00"`), `InpDayStartUTC="00:00"`, `InpCutoffHourUTC=21`, `InpOpeningRangeMinutes=30`, `InpOpeningRangeSession=FBPI_OR_NEWYORK` |
| Volume | `InpValueAreaPct=70.0`, `InpProfileBins=24`, `InpProfileScope` |
| Liquidity | `InpProbLookback=100`, `InpMinSample=20`, `InpTouchMethod=FBPI_TOUCH_HIGH_LOW`, `InpSpreadAdjPoints=0.0`, `InpConfirmBars=3`, `InpBreakoutBars=3`, `InpSweepTolerancePts=0` |
| Confirmation | Weights 20/20/20/20/10/10, `InpMinConfScore=50`, `InpConfStrong=80`, `InpConfModerate=65`, `InpConfWeak=50`, `InpRequireClosedCandle=true` |
| Risk | `InpPaperCapital=5000.0`, `InpRiskPct=0.5`, `InpMaxDailyLossPct=2.0`, `InpMinRR=2.0`, `InpPrefRR=3.0`, `InpAccountCurrency="USD"`, `InpCommissionPerLot=0.0`, `InpDailyLossSoFar=0.0` |
| Alerts | One bool per `ENUM_FBPI_ALERT` (approach/touch/sweep/OR-breakout default **false** except touch and sweep = true, matching FLR's locked defaults), `InpAlertSound=true`, `InpAlertPopup=true`, `InpAlertPush=false`, `InpAlertCooldownMinutes=15`, `InpApproachPips=5.0` (**pips**, not points — FLR used points) |
| Statistics | `InpEnableScoreboard=true`, `InpPersistentStorage=true`, `InpExportCSV=true` |

### 5.1 Watchlist (spec §10)

`EURUSD, GBPUSD, USDJPY, USDCHF, USDCAD, AUDUSD, NZDUSD, EURGBP, EURJPY, GBPJPY, AUDJPY, CADJPY, CHFJPY, EURAUD, GBPAUD` — the same 15 pairs as FLR (verified identical). Broker prefix/suffix mapping via `FBPI_MapSymbol()` in the common header. Custom additions are appended to `InpWatchlist` (capacity 30). No pair is assumed to have the same liquidity, spread, volatility, or session behaviour as another: per-symbol point size, pip value, and spread are always resolved per symbol.

### 5.2 Input validation (OnInit)

`OnInit()` returns `INIT_PARAMETERS_INCORRECT` for: lookback outside 5–500; min sample outside 5–100 or > lookback; opening-range minutes outside {15, 30, 60}; value-area % outside 50–90; confirmation weights not summing to 100; thresholds not strictly decreasing (Strong > Moderate > Weak); broker offset outside −12…+14; DST shift outside 0–2; risk % outside 0.1–5; max daily loss outside 0.5–10 or < risk %; min R:R outside 1.0–5.0 or > preferred R:R; any session `"HH:MM"` string that fails `FBPI_ParseHHMM()`; any watchlist symbol that maps to nothing on the broker (warning only — a missing symbol is `DATA UNAVAILABLE`, not a fatal error, because the user may attach to a symbol the broker lists under a different name). Validation failures are `Print`ed with the offending input name and value.

---

## 6. File persistence format

All files live in `MQL4\Files\`, prefixed `FBPI_`. All writes go through `FBPI_Storage` (built first). Files are the permanent record; in-memory aggregates are a cache rebuilt on load.

### 6.1 Scoreboard — `FBPI_Scoreboard_<SYMBOL>.csv` (21 columns, spec §12)

```
symbol,trading_day,level,session,day_of_week,forecast_time,cutoff_time,forecast_pct,observations,touches_at_forecast,forecast_prob,outcome,touch_time,brier_contribution,wilson_lower_pct,wilson_upper_pct,price_basis,touch_method,lookback_days,day_start_hour_utc,finalised_at
EURUSD,2026.11.26,PDH,London,4,2026.11.26 00:00,2026.11.26 21:00,72.00,100,0,0.72,1,2026.11.26 14:00,0.0784,62.51,79.86,Bid,HIGH_LOW,100,0,2026.11.27 00:05
```

- **Header validation on load** (FLR gap D6 fixed): if the header does not match the 21-column header exactly, the file is not loaded; a new file `<name>_v2.csv` is started and the mismatch is `Print`ed. The old file is never overwritten or silently reinterpreted.
- **Settings in the header comment:** the first line of the file is a comment line `# FBPI-MT4-001 day_start_utc=0 cutoff_utc=21 lookback=100 touch=HIGH_LOW` recording the settings the rows were computed under. A settings change does NOT start a new file: the code performs no settings comparison anywhere, so the same file continues and its comment then records the settings in force when the file was created, not necessarily the current ones (Statistics divergence D-4). A new `<name>_v2.csv` is started only when the 21-column header itself mismatches. On a first run the file is pre-created by `OnInit` with the configured settings (QA N-4), so the comment is exact until the settings are changed after the file exists.
- **Late-issued forecasts:** a forecast captured after its nominal time (terminal was off at the day start) is computed only from bars available at the original forecast time and written with its nominal `forecast_time`; `touches_at_forecast` is the historical touch count and encodes nothing about lateness. The late issue is recorded only in the terminal log at write time (`FBPI_Storage_WriteForecast` `Print`s the row key, nominal forecast time and capture time); the CSV has no `lateIssued` column. *Design note: if a dedicated column is needed, add `late_issued` as column 22 and bump the header version — do not overload an existing column.*
- **Aggregates:** total observations/touches, mean forecast, actual touch rate, Brier score, Brier skill vs climatology (climatology = overall actual touch rate; skill = 1 − Brier/Brier_climatology), per-level, per-day-of-week, per-session, per-pair, and calibration bins (10 decile bins: 0–10%, 10–20%, …, 90–100%) with per-bin mean forecast and actual rate.
- **Open forecasts — `FBPI_Forecasts_<SYMBOL>.csv`:** today's frozen forecast (7 levels + N + forecast time) is written at capture time and deleted on finalisation. A restart reloads it; a restart across a day boundary finalises from it instead of losing the day (FLR L6a fixed).
- **Sweeps — `FBPI_Sweeps_<SYMBOL>.csv`:** one row per `SweepEvent` (including failed breakouts): `symbol,event_time,excursion_bar_time,confirm_bar_time,kind,level,level_price,excursion_pts,bars_to_confirm`.

### 6.2 Sample data

A shipped `Sample_Scoreboard.csv` (Phase 11 deliverable) shows the exact 21-column shape with example values labelled EXAMPLE — invented numbers, never presented as results.

---

## 7. Event model (FBPI_Main.mq4)

| MQL4 entry point | Responsibility |
|---|---|
| `OnInit()` | Validate inputs (§5.2); delete stale `FBPI_` objects; initialise globals; parse the watchlist; set `g_fbpiDayStart`; load the scoreboard + open forecasts via Storage; start the timer `EventSetTimer(InpRefreshSeconds)`. Returns `INIT_SUCCEEDED`, `INIT_PARAMETERS_INCORRECT`, or `INIT_FAILED`. |
| `OnCalculate()` | Detect a new bar (last bar open time vs `g_fbpiLastBarTime`). Call `FBPI_Main_RecalcAll(isNewBar)` on a new bar, on first calculation, or when the refresh interval elapsed since the last recalculation. Otherwise, on ticks, only refresh live price labels. Returns `rates_total`. |
| `OnTimer()` | Same gating as `OnCalculate()` (shared gate, so the two paths cannot double-recalculate in the same interval — FLR pattern). |
| `OnChartEvent()` | Object clicks only (dashboard minimise/expand/close, scoreboard toggle/export, panel hide). Must never alter market data. Drag handling: dashboard panels are movable by their title bar (FLR gap D-11 — implement via `OnChartEvent` drag on `FBPI_DASH_TITLE`). |
| `OnDeinit(reason)` | `EventKillTimer()`, `FBPI_DeleteAllObjects()`, log line. No CSV flush is needed: rows are appended at finalisation, not held in a buffer. |

### 7.1 Master recalculation — `FBPI_Main_RecalcAll(bool isNewBar)`

Runs in dependency order (never reordered without amending this document):

1. `FBPI_Main_CheckNewDay()` — day rollover: finalise yesterday (Statistics), reset daily state.
2. `FBPI_Macro_Calculate()` — macro/cross-market (cheap; mostly reads inputs).
3. `FBPI_MarketStructure_Calculate()` — quarterly/monthly/weekly/daily + MTF table.
4. `FBPI_Sessions_Calculate()` — session windows, current session, session levels.
5. `FBPI_OpeningRange_Calculate()` — ORH/ORL (+ London/NY ranges).
6. `FBPI_Auction_Calculate()` — auction state.
7. `FBPI_VolumeProfile_Calculate()` — profiles + VAH/VAL/POC.
8. `FBPI_Liquidity_Calculate(isNewBar)` — level assembly, probabilities (only on new bar / forecast time / input change — **not** on every timer tick), sweep/breakout classification (closed bars only).
9. `FBPI_OrderFlow_Calculate()` — order-book availability, estimated tick activity.
10. `FBPI_Confirmation_Calculate()` — six factors, score, band, setup identification.
11. `FBPI_Risk_Calculate()` — risk plan for the identified setup (or manual plan).
12. `FBPI_Statistics_Calculate()` — in-memory aggregates refresh (file writes happen only at finalisation).
13. `FBPI_Dashboard_Draw()` (Phase 10; if enabled and not hidden).
14. `ChartRedraw()`.

**Performance budget:** every H1 scan is bounded by `iBarShift()` to the bars inside its window. A full probability recomputation touches at most lookback (100) days × ~48 H1 bars × 7 levels ≈ 34,000 bar visits; it runs only on a new bar, not per timer tick. The multi-pair scan (Phase 10, optional, off by default) is PDH-only per symbol with lookback capped at 50 days (FLR pattern). Object count is bounded: ~29 level lines/labels + 100 sweep markers max + dashboard labels ≈ 250 objects.

---

## 8. Divergences and design decisions

### 8.1 Divergences from the spec (deliberate, with reasons)

| # | Area | Spec | FBPI decision | Reason |
|---|---|---|---|---|
| D-1 | Refresh interval | Spec §15 implies 0 = no timer (FLR spec said 0–60) | `InpRefreshSeconds` 1–300, 0 not supported | A 0 (no-timer) mode leaves the dashboard frozen between bars on a quiet chart; the timer is the live-price refresh path. Documented, not hidden. |
| D-2 | Scoreboard CSV | Spec §12 lists 21 columns but does not define a `lateIssued` column | 21 columns as listed; `lateIssued` is recorded via the forecast/capture-time log, with a reserved column 22 if the Statistics author needs it | Keeps the spec's 21-column format exact; avoids overloading a column's meaning. |
| D-3 | Futures feed | Spec §14 "optional integration with external futures data" | No futures feed is implemented in v1 (no WebRequest/DLL); the row is `DATA UNAVAILABLE` | There is no approved external-data mechanism in MQL4 without WebRequest/DLL, both forbidden. A feed can only arrive as a file the user drops in `MQL4\Files\` — that integration point is specified in `FBPI_OrderFlow` for a later phase, not built now. |
| D-4 | Economic calendar feed | Spec §14 lists an economic calendar as a potential integration | Same as D-3: manual input only in v1 | Same reason. |
| D-5 | Dashboard drag/resize | Spec §8 "hide, reposition, or resize panels" | Reposition by dragging the title bar (implemented in Phase 10); resize is content-driven only (panels grow/shrink with their rows), no free resize | Free resize of a label-based dashboard in MQL4 is fragile; content-driven sizing is the FLR-proven approach. |
| D-6 | Custom sessions | Spec L12 "up to three custom windows replacing the three sessions" | Up to 3 custom windows that supplement the standard three (checked first); a custom window does not delete the standard sessions | Replacing the standard sessions would remove the Asian/London/NY levels the rest of the system depends on. The user can hide the standard panels in the dashboard instead. |

### 8.2 FLR divergences fixed in FBPI (lessons applied)

| # | FLR behaviour | FBPI fix |
|---|---|---|
| F-1 | ONH/ONL identical to Asian high/low | Genuine overnight window 21:00–07:00 UTC spanning the day boundary (§4.6) |
| F-2 | Opening range from the trading-day start (00:00–00:30) | Range anchored to the `InpOpeningRangeSession` open (default New York) (§4.5) |
| F-3 | Day start and cutoff in broker time | UTC reference frame; broker offset only shifts bar lookup (§4.1) |
| F-4 | Touch methods High/Low or Close; spread adjustment widened the zone | Spread adjustment narrows the zone; direction-aware test in one helper (§4.6) |
| F-5 | Neutral (PDC) touch test was an OR tautology → PDC probability always 100% | Neutral test is AND (range contains the level) in `FBPI_BarTouchesLevel()`; the OR form is forbidden |
| F-6 | No Wilson interval | Wilson 95% interval computed for every probability (§4.6) |
| F-7 | 6-column scoreboard CSV, no header validation, no settings record | 21-column CSV, header validation with `_v2` file, settings comment line, open-forecast file (§6) |
| F-8 | Failed breakout detected but not recorded | Recorded as `FBPI_LIQ_FAILED_BREAKOUT_UP/DOWN` with a `SweepEvent` and a CSV row (§4.7) |
| F-9 | Sweep excursion triggered on the live Bid (tick); classification used the wrong bar's close | Excursion and classification on closed bars only, with bar open times recorded (§4.7) |
| F-10 | Daily sweep/breakout counters never reset | Reset in `CheckNewDay()` (§4.7) |
| F-11 | Open forecasts memory-only; lost on restart across a day boundary | Persisted to `FBPI_Forecasts_<SYMBOL>.csv` at capture (§6.1) |
| F-12 | DST AUTO was a month heuristic (April–October) | Rule-based US/EU DST (§4.1) |
| F-13 | Broker offset `int` (no half-hours); sessions integer hours | Offset `double`; session times `"HH:MM"` strings (§4.1) |
| F-14 | Probabilities recomputed on every refresh tick | Recomputed only on new bar / forecast time / input change (§1.1.8) |
| F-15 | Scoreboard dedup keys capped at 5,000 with silent failure beyond | Cap retained (5,000) but documented: when reached, the oldest keys are evicted FIFO and a `Print` warning is issued once per session — silent failure is not acceptable |
| F-16 | Approach distance in points | Approach distance in pips (`InpApproachPips`, default 5.0) |
| F-17 | Alert cooldown hardcoded to 3600 s | `InpAlertCooldownMinutes` (default 15) per alert type |
| F-18 | Parallel global arrays instead of the specified structs | FBPI state is held in the structs defined in `FBPI_Common.mqh` (§3) |

### 8.3 Known limitations (Phase 1 — to be addressed in later phases, not hidden)

- L-1 No live MT4 terminal or MetaEditor compiler exists in this environment; **no module can be marked tested until it is compiled and run in a terminal** (see §9).
- L-2 Layers 1–3, 7, 18, and true bid/ask flow are unavailable by default. This is a property of MT4, not a defect — but the dashboard must never present them as if they were live.
- L-3 Tick volume is a broker-specific proxy for volume. Profiles, value areas, and estimated flow derived from it are broker-relative; the same symbol on another broker can give a different POC.
- L-4 The probability engine needs ~100 days of H1 history (~2,400 bars). Short history shrinks N and is flagged, not hidden (§4.6).
- L-5 DST-transition days: the broker day is 23 or 25 hours. Day windows are computed from UTC anchors, so the UTC frame is correct, but a session window that straddles the transition is computed from the offset in force at the window start — the Sessions author must test this explicitly (Test 2).
- L-6 The multi-pair scan is PDH-only with lookback capped at 50 (FLR pattern). Per-symbol full scoreboards are out of scope for v1.

---

## 9. Testing plan — Tests 1–17 (spec §17) mapped to phases

No test is marked PASS on static analysis alone. Every test needs a live terminal; the verdict scale is **PASS / PARTIAL / CANNOT-VERIFY-WITHOUT-TERMINAL**, as in the FLR Test Report.

| Test | Spec §17 | Phase | What is checked (acceptance) |
|---|---|---|---|
| T1 | Quarterly/monthly/weekly/daily calculations | 2 | Hand-check Q/M/W/D highs, lows, opens, closes, ADR vs H1 bars on EURUSD; position % and structure classification vs manual calculation |
| T2 | Session boundaries and DST changes | 3 | Session at known UTC times (13:00 UTC → NY, overlapping London); windows on a DST-transition weekend (US Mar + Nov, EU Mar + Oct); half-hour offset (+5.5) |
| T3 | Opening range calculations | 3 | ORH/ORL for 15/30/60 min from the NY open (and London when enabled); midpoint; range vs M15 bars |
| T4 | Market structure classification | 2, 4 | HH/HL, LH/LL, consolidation, breakout on monthly/weekly/daily closes; auction state vs the decision table (§4.5) on 20 known bars |
| T5 | Tick-volume profile calculations | 5 | POC/VAH/VAL hand-checked on one day's H1 tick volume; bin sums equal total tick volume; label says "tick volume" |
| T6 | POC, VAH, VAL calculations | 5 | Value area contains 70% of volume (±1 bin tolerance); price-vs-value classification; migration detection |
| T7 | Liquidity sweep classification | 6 | One historical wick-beyond-then-close-inside case → sweep; one close-beyond-then-close-back case → failed breakout, **not** a sweep; no classification before the excursion bar closes |
| T8 | Probability calculation and sample size | 6, 11 | One level hand-checked over 20 days vs displayed % and N; **PDC is not 100%** (regression for the FLR tautology); Wilson interval contains the point estimate; `INSUFFICIENT DATA` on short history |
| T9 | Confirmation scoring | 8 | Each factor scored by hand on a known setup; missing-data factor scores 0; weights sum to 100; band thresholds respected |
| T10 | Risk and position sizing | 9 | Hand-computed lot size, pip value, R:R for 3 symbols (incl. a JPY pair and a 3-digit broker); rounding down to lot step; violation warnings fire for R:R < 2 and for daily-loss breach |
| T11 | Dashboard functionality | 10 | All five sections render; hide/reposition works; unavailable data shows grey `DATA UNAVAILABLE`; no calculation happens in the dashboard module |
| T12 | Historical replay and look-ahead prevention | 11 | Replay vs live equivalence on 30 days; a past day's PDH and a finalised scoreboard row are identical when re-read 30 days later (no repainting) |
| T13 | Data persistence after MT4 restart | 11 | Restart the terminal: scoreboard CSV loads, totals unchanged, no duplicate rows, open forecast survives a restart across a day boundary |
| T14 | Multi-symbol compatibility | 10, 11 | All 15 watchlist pairs show a PDH probability or an explicit "no data" row; a JPY pair's probability and pip value are sane |
| T15 | Performance and resource utilisation | 12 | Terminal CPU with the indicator on a 5 s refresh and the scan enabled; no visible lag; object count ≤ ~250 |
| T16 | Missing and stale external data | 7, 11 | With no feed configured: order book shows `ORDER BOOK UNAVAILABLE`; footprint shows `ESTIMATED TICK ACTIVITY`; a manually entered rate older than its max age shows `STALE DATA` |
| T17 | No automatic trade execution | **Every phase** | `grep` for `OrderSend|OrderModify|OrderClose|OrderDelete|OrderSelect|#import|WebRequest` returns matches only in comments stating the prohibition; no trade-execution code exists in any file |

**Acceptance (spec §20):** zero compilation errors, warnings documented and resolved where possible; all 23 layers represented; missing data never fabricated; no automatic orders placed; the complete indicator compiles and operates correctly. **The `.ex4` is only produced after successful compilation in MetaEditor** — no earlier phase may claim it.

---

## 10. File map (Phase 1 deliverables + later phases)

```
~/workspace/projects/forex-bigger-picture-intelligence/
  FBPI-MT4-001-spec.md               (spec — source of truth, do not edit)
  PHASE1_HANDOFF.md                  (this phase's handoff to module authors)
  include/
    FBPI_Common.mqh                  (Phase 1 — the contract)
  docs/
    Technical_Architecture.md        (Phase 1 — this file)
    Data_Source_Register.md          (Phase 1)
    Market_Structure_Methodology.md  (Phase 2)
    Session_Configuration_Guide.md   (Phase 3)
    Volume_Profile_Methodology.md    (Phase 5)
    Probability_and_Statistical_Methodology.md (Phase 6/11)
    Risk_Management_Guide.md         (Phase 9)
    Historical_Testing_Protocol.md   (Phase 11)
    Installation_Guide.md            (Phase 12)
    User_Operating_Manual.md         (Phase 12)
    Quality_Assurance_Report.md      (Phase 12)
  presets/
    FBPI_Standard.set                (Phase 12)
    FBPI_Conservative.set            (Phase 12)
    FBPI_Aggressive.set              (Phase 12)
  FBPI_Main.mq4                      (Phases 2-10, assembled progressively)
  include/FBPI_Macro.mqh             (Phase 2-3, Layers 1-7)
  include/FBPI_MarketStructure.mqh   (Phase 2)
  include/FBPI_Sessions.mqh          (Phase 3)
  include/FBPI_OpeningRange.mqh      (Phase 3)
  include/FBPI_Auction.mqh           (Phase 4)
  include/FBPI_VolumeProfile.mqh     (Phase 5)
  include/FBPI_Liquidity.mqh         (Phase 6)
  include/FBPI_OrderFlow.mqh         (Phase 7)
  include/FBPI_Confirmation.mqh      (Phase 8)
  include/FBPI_Risk.mqh              (Phase 9)
  include/FBPI_Dashboard.mqh         (Phase 10)
  include/FBPI_Statistics.mqh        (Phase 11)
  include/FBPI_Storage.mqh           (built FIRST, with Common)
```

*End of Technical Architecture — FBPI-MT4-001 Phase 1.*
