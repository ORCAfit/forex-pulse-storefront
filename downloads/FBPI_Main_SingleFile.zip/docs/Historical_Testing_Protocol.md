# Historical Testing Protocol — FBPI-MT4-001

| Field | Value |
|---|---|
| Project | Forex Bigger Picture Intelligence System, FBPI-MT4-001 |
| Spec | `FBPI-MT4-001-spec.md` v1.0, §12, §17, §18 Phase 11, §20 (source of truth) |
| Design authority | `docs/Technical_Architecture.md` §6, §7, §9 |
| Code | `include/FBPI_Statistics.mqh` (Phase 11), `include/FBPI_Storage.mqh`, `FBPI_Main.mq4` (`RecalcAll`, `CheckNewDay`) |
| Date | 2026-11-27 |
| Status | **All 17 tests are CANNOT-VERIFY-WITHOUT-TERMINAL.** No test in this protocol has been run. There is no MetaEditor compiler and no live MT4 terminal in this environment, so no module can be marked tested until the indicator is compiled and run on the user's laptop. This document is the procedure for doing that — not a record of results. |

## 1. Principles — the rules no test may break

These rules come from spec §12 and Architecture §1.1. A test that breaks one is invalid, even if its numbers look good.

1. **Out-of-sample discipline.** A forecast is judged only on days after the days that built it. The probability engine's loop (§3 of the Probability Methodology) enforces this by construction; the tester must not "improve" a forecast by rebuilding it with later data.
2. **No look-ahead.** Only closed bars are historical observations. The forming bar is never tested as a touch, never counted as a close, and never used to finalise a row. A forecast level is reconstructed only from days before the forecast day (ORH/ORL excepted: from the forecast day's own opening range, which completes before the evaluation window opens).
3. **No revision of finalised rows.** A scoreboard row, once written to `FBPI_Scoreboard_<SYMBOL>.csv`, is append-only. It is never edited, re-scored, or re-written. If a row is wrong, the defect is recorded in the QA report and fixed in code going forward — the file is not patched.
4. **Incomplete candles never counted.** A day with no completed bar in its evaluation window is not finalised as "not touched". The row stays open and is retried on later rollovers.
5. **Missing data is a result, not a failure to hide.** `DATA UNAVAILABLE`, `INSUFFICIENT DATA (N=…)`, and `ORDER BOOK UNAVAILABLE` are legitimate outputs. A test passes when the indicator reports them correctly, and fails when it substitutes a zero, a guess, or a value from an unrelated source.
6. **Forecast accuracy is not trading profitability.** Every number in the scoreboard measures whether a frozen level-touch forecast came true. It says nothing about entry, spread, slippage, position size, or whether a trade at that level would have made money. No test in this protocol measures profitability, and none may be reported as if it did.

**Verdict scale** (Architecture §9, as in the FLR Test Report): **PASS** / **PARTIAL** / **CANNOT-VERIFY-WITHOUT-TERMINAL**. No test is marked PASS on static analysis alone. A test that could not be run for lack of a terminal is CANNOT-VERIFY, not PASS and not FAIL.

## 2. Environment setup (do this once, before Test 1)

1. Compile `FBPI_Main.mq4` in MetaEditor (F7). Acceptance requires **zero compilation errors**; warnings must be documented and resolved where possible. Record the MetaEditor/MT4 build numbers and the compile log.
2. Attach the compiled indicator to a chart. Recommended: **EURUSD, H1**, with at least 100 days of H1 history loaded (the probability engine's default lookback is 100 days ≈ 2,400 H1 bars; short history shrinks N and is flagged, not hidden). Confirm history depth in the terminal: the earliest H1 bar should be at least 100 trading days back.
3. Use the default inputs for the first full pass (`InpProbLookback` = 100, `InpMinSample` = 20, `InpADRPeriod` = 14, `InpValueAreaPct` = 70, `InpProfileBins` = 24, `InpConfirmBars` = 3, `InpBreakoutBars` = 3, `InpTouchMethod` = HIGH_LOW, `InpSpreadAdjPoints` = 0.0, `InpCutoffHourUTC` = 21, `InpDayStartUTC` = "00:00"). Record any input that differs from default, because the scoreboard file's settings comment records the settings the rows were computed under.
4. Locate the files folder: MT4 → File → Open Data Folder → `MQL4\Files\`. The indicator writes `FBPI_Scoreboard_<SYMBOL>.csv`, `FBPI_Forecasts_<SYMBOL>.csv`, and `FBPI_Sweeps_<SYMBOL>.csv` there. Keep a copy of each file before every test session so a test can be re-run from the same starting state.
5. Open the Experts and Journal tabs. The indicator logs every finalisation, capture, header mismatch, and skipped row with `Print()` — the log is evidence, not noise. Save the log at the end of each test session.

## 3. The daily cycle — finalise yesterday, then capture today

The scoreboard runs on a strict daily cycle. The exact call sequence is fixed in `FBPI_Main.mq4` and `FBPI_Statistics.mqh`; the tester must understand it before judging any row.

### 3.1 Rollover (RecalcAll step 1, before Liquidity recalculates)

`FBPI_Main_CheckNewDay()` detects the trading-day change (UTC reference frame), resets the daily counters (`g_fbpiSweepCount`, `g_fbpiBreakoutCount`, alert edge state, per-level `touchedToday`), and — if the scoreboard is enabled — calls `FBPI_Statistics_FinaliseYesterday()`. Finalisation is **idempotent**: calling it again the same day is harmless, because finalised rows are gone from the open file.

`FinaliseYesterday()` processes every still-open forecast whose trading day is before today:

1. Rows for today or later are kept open, untouched.
2. The forecast level is reconstructed **only from days before the forecast day** (`FBPI_Liquidity_ForecastLevel()`). If it cannot be built (no bars in the source window), the row is kept open — "unavailable, never invented".
3. The evaluation window must lie entirely inside available H1 history (`FBPI_Statistics_HistoryCovers()`); otherwise the row is kept open.
4. The window is **capped at the last closed H1 bar** (`iTime(symbol, PERIOD_H1, 1) + 3600`). The forming bar is never tested; future data is never used. If the capped window has no completed bar yet, the row is kept open.
5. The touch is tested with the **frozen touch method from the row** (the method recorded at capture). The first touch time is recorded (`FBPI_Statistics_FirstTouchTime()`); outcome is 1 (touched) or 0 (not touched); `brier = (forecastProb − outcome)²` via `FBPI_Brier()`; `finalisedAt = TimeCurrent()`.
6. The row is appended to the scoreboard CSV (`FBPI_Statistics_AppendRow()`, dedup by `symbol|trading_day|level`) and removed from the open-forecast file. The open file is then rewritten with only the still-open rows (or deleted when empty).

A row that cannot be finalised stays open and is retried on later rollovers. It is never finalised as a guess.

### 3.2 Capture (RecalcAll step 11, after Liquidity)

Once per trading day, after Liquidity has recomputed the probabilities, `FBPI_Statistics_CaptureForecast()` freezes today's forecast:

- Only levels whose stats are **valid** (`N ≥ InpMinSample`) get a row. Any other level is skipped with a log line `no forecast row for <abbr> — INSUFFICIENT DATA (N=…)`.
- `forecast_time` is the **nominal** time (the trading-day start), even if the terminal was off at the day start. `lateIssued` is true when capture happens more than 1 hour (`FBPI_STAT_LATE_SECONDS` = 3600) after the day start; it is recorded **only in the terminal log** at write time — the CSV has no `late_issued` column (Architecture divergence D-2).
- `touches_at_forecast` is the historical touch count from the probability loop (the `touches` in `touches / eligible`), not touches seen so far today. `forecast_prob` is the frozen probability as a proportion (e.g. 0.72); `forecast_pct` is the same number as a percent (72.00).
- A level already frozen for today is **never overwritten** (RowExists check on the forecast file; missing levels are merged in). A second capture call the same day is harmless. Main tracks the last capture day (`g_mainLastCaptureDay`) and calls capture only when the trading day has changed.
- If the open-forecast file exists but cannot be read (header mismatch or corruption), capture is **refused** — the unreadable open forecasts are never overwritten blindly.

### 3.3 Aggregates

`FBPI_Statistics_Calculate()` (RecalcAll step 12) refreshes the in-memory aggregates from the scoreboard file. The file is the permanent record; the in-memory aggregates are a cache rebuilt on load (`FBPI_Statistics_LoadScoreboard()` on Init). File writes happen **only** at finalisation — never on a timer tick, never on a dashboard refresh.

## 4. The 21-column scoreboard format

`FBPI_Scoreboard_<SYMBOL>.csv` has exactly 21 columns, in this exact order (`FBPI_Storage_ScoreboardHeader()`). The first line of the file is a settings comment, e.g. `# FBPI-MT4-001 day_start_utc=0 cutoff_utc=21 lookback=100 touch=HIGH_LOW`.

| # | Column | Meaning | Example |
|---|---|---|---|
| 1 | `symbol` | Broker symbol | `EURUSD` |
| 2 | `trading_day` | Day start (broker time) | `2026.11.26` |
| 3 | `level` | Level abbreviation | `PDH` |
| 4 | `session` | Session name at forecast time | `London` |
| 5 | `day_of_week` | 0 = Sunday … 6 = Saturday | `4` |
| 6 | `forecast_time` | Nominal forecast time (day start) | `2026.11.26 00:00` |
| 7 | `cutoff_time` | Evaluation cutoff | `2026.11.26 21:00` |
| 8 | `forecast_pct` | Frozen probability, % | `72.00` |
| 9 | `observations` | Eligible N at capture | `100` |
| 10 | `touches_at_forecast` | Historical touches in the loop | `72` |
| 11 | `forecast_prob` | Frozen probability, proportion | `0.72` |
| 12 | `outcome` | 1 touched, 0 not touched, −1 not finalised | `1` |
| 13 | `touch_time` | First touch time, empty if never touched | `2026.11.26 14:00` |
| 14 | `brier_contribution` | (f − o)², empty until finalised | `0.0784` |
| 15 | `wilson_lower_pct` | Wilson 95% lower bound, % | `62.51` |
| 16 | `wilson_upper_pct` | Wilson 95% upper bound, % | `79.86` |
| 17 | `price_basis` | Always `Bid` | `Bid` |
| 18 | `touch_method` | `HIGH_LOW`, `CLOSE`, or `SPREAD_ADJ` | `HIGH_LOW` |
| 19 | `lookback_days` | Lookback actually used | `100` |
| 20 | `day_start_hour_utc` | Configured day-start hour, UTC | `0` |
| 21 | `finalised_at` | Finalisation time, empty until finalised | `2026.11.27 00:05` |

**Header validation.** On load, if the header does not match the 21-column header exactly, the file is **not** loaded; a new file `<name>_v2.csv` (then `_v3`, …) is started and the mismatch is printed. The old file is never overwritten or silently reinterpreted. Empty fields are preserved positionally on parse (the CSV splitter preserves empty fields — a forecast row legitimately has empty `touch_time`, `brier_contribution`, and Wilson fields before finalisation).

**Dedup.** Rows are deduplicated by `symbol|trading_day|level`. The in-memory key cache holds 5,000 keys (`FBPI_MAX_SB_KEYS`); at capacity the **oldest key is evicted FIFO** and a warning is printed once per session (Architecture F-15 — silent failure beyond the cap is not acceptable).

**Sweeps file.** `FBPI_Sweeps_<SYMBOL>.csv` has 9 columns: `symbol,event_time,excursion_bar_time,confirm_bar_time,kind,level,level_price,excursion_pts,bars_to_confirm`. It records sweeps, sustained breakouts, failed breakouts, and retests — failed breakouts are recorded as events, never silently dropped.

**Known deviations from the Architecture document** (Statistics module header, D-1…D-5 — record these in the QA report, do not "fix" them during testing): calibration uses 10 decile bins, not the five bins in Architecture §6.1; the summary file is `FBPI_Summary_<SYMBOL>.csv`, not `FBPI_Scoreboard_Summary_<SYMBOL>.csv`; a settings change that keeps the same 21-column header continues the same file; the spread-adjustment points at finalisation are the *current* input value (the CSV records the method, not the points); late-issued status is log-only.

## 5. Tests 1–17 — step by step

For each test: set up as stated, run the steps, and judge against the stated pass/fail criteria. Record the date, symbol, inputs, terminal build, and the exact evidence (screenshot, file excerpt, or log line) for every verdict.

### Test 1 — Quarterly, monthly, weekly, daily calculations

- **Setup:** EURUSD H1, defaults. Pick a known date with full history.
- **Steps:** (a) Read QH/QL, MH/ML, PMH/PML, WH/WL, PWH/PWL, PDH/PDL/PDC/PDO, DO from the dashboard or `g_fbpiLevels[]`. (b) By hand, from the H1 bars in each window ([00:00, 21:00) UTC for the daily window; calendar month/quarter; Monday 00:00 UTC to Sunday 21:00 UTC for the week), compute the same highs, lows, opens, and closes. (c) Compute ADR by hand over the last 14 completed days and compare with the displayed ADR **and** with the reported sample-day count (`ADRSampleDays()`). (d) Check position % = (Bid − low)/(high − low) and the range-position band (§9 of the Market Structure Methodology) against the displayed values.
- **Pass:** Every hand-computed high/low/open/close matches to the pip; ADR matches to 0.1 pip with the sample-day count explained (14, or fewer with short history and the count shown); position % and band match. **Fail:** Any level differs by more than one pip; ADR disagrees without a sample-day explanation; a level shows a price when its window has no bars (must be `DATA UNAVAILABLE` instead).

### Test 2 — Session boundaries and daylight-saving changes

- **Setup:** Defaults (Asian 00:00–09:00, London 07:00–16:00, New York 12:00–21:00 UTC). Check at known UTC times.
- **Steps:** (a) At 13:00 UTC on a weekday, confirm the current session is New York (overlap 12:00–16:00 UTC reported as `FBPI_SESS_OVERLAP` with both sessions named; New York takes priority over London, London over Asian). (b) At 03:00 UTC confirm Asian; at 08:00 UTC confirm London; at 22:00 UTC confirm no session active (`Closed`). (c) On a Saturday, confirm all sessions inactive and status `Closed` — the UTC-hour test alone would name a session, so the market-open check must also require a bar within the last 10 minutes. (d) On a US DST-transition weekend (second Sunday in March; first Sunday in November) and an EU transition weekend (last Sunday in March; last Sunday in October), confirm the session windows shift by the rule-based DST (US/EU/Manual/Off), not by a month heuristic. (e) Set `InpBrokerGMTOffset` = 5.5 and confirm the windows still align (half-hour offset representable; broker offset is a double).
- **Pass:** Session names correct at every checked time; weekend shows `Closed`; DST-transition windows match the rule; +5.5 offset works. **Fail:** Any session misidentified; a Saturday shows a session as active; DST handled by month rather than by rule; half-hour offset rejected or misaligned.

### Test 3 — Opening range calculations

- **Setup:** Defaults: `InpOpeningRangeMinutes` = 30, `InpOpeningRangeSession` = New York.
- **Steps:** (a) By hand from M15 bars, compute ORH/ORL as the extremes of the first 30 minutes after the New York open (12:00 UTC), and the midpoint (ORH + ORL) / 2. Compare with the displayed ORH/ORL/midpoint. (b) Repeat with 15 and 60 minutes (input change, re-attach or re-init required — the value is read at Init). (c) Enable the independent London range (`InpShowLondonOR`) and check its ORH/ORL against the first 30 minutes after the London open (07:00 UTC). (d) Confirm the range is **not** computed from the trading-day start (00:00–00:30) — that was the FLR error.
- **Pass:** ORH/ORL/midpoint match the hand computation from M15 bars for 15, 30, and 60 minutes, for New York and (when enabled) London. **Fail:** Any mismatch beyond one pip; the range anchored at 00:00; midpoint not the arithmetic mean of ORH/ORL.

### Test 4 — Market structure classification

- **Setup:** EURUSD H1, defaults.
- **Steps:** (a) Take the last 3 completed monthly closes, weekly closes, and daily closes; classify each by hand under the rules in §8 of the Market Structure Methodology (HH/HL requires highs *and* lows rising; breakout requires a close beyond the prior period's extreme) and compare with the displayed structure. (b) Find or construct cases of each class — HH/HL, LL/LH, consolidation, breakout up, breakout down — across the three timeframes. (c) Check the auction state against the decision table on 20 known closed bars (trend requires a directional HH/HL or LH/LL sequence *and* closes beyond the prior extreme; balance requires closes inside the value area for 5+ bars; expansion requires range > 1.5× the 20-bar mean range; reversal requires a structure shift *and* a close beyond the prior extreme). Fewer than 10 closed bars must show `FBPI_AUCTION_UNKNOWN`.
- **Pass:** Every hand classification matches; all five structure classes observed correctly at least once; auction state matches the decision table on the 20-bar sample; insufficient bars show UNKNOWN. **Fail:** Any classification contradicts the hand computation; a breakout claimed on an uncompleted period's close (quarterly trend excepted — see Methodology §8.3).

### Test 5 — Tick-volume profile calculations

- **Setup:** EURUSD H1, one full trading day, defaults (24 bins, 70% value area).
- **Steps:** (a) Export the day's H1 bars (open, high, low, tick volume). (b) By hand, build the 24-bin profile: bin size = (day high − day low) / 24; distribute each bar's volume pro-rata to overlap width (§2.4 of the Volume Profile Methodology). (c) Compare every bin volume, the POC bin, and the total. (d) Confirm **bin volumes sum exactly to total tick volume**. (e) Confirm the profile heading says "Tick volume" and never "consolidated volume".
- **Pass:** All 24 bin volumes match to rounding; the sum equals the total; POC matches; the label says tick volume. **Fail:** Any bin off by more than rounding error; the sum differs from the total; the label claims consolidated volume; a profile is shown for a scope with fewer than 10 bars or zero volume (must be invalid instead).

### Test 6 — POC, VAH, VAL calculations

- **Setup:** Same day as Test 5.
- **Steps:** (a) From the hand-built profile, expand from the POC bin adding the larger adjacent bin (ties go up) until 70% of volume is inside; compare VAH/VAL with the displayed values. (b) Confirm the value area contains **at least** 70% of volume (whole bins overshoot — see Methodology §7; tolerance is +1 bin, never below 70%). (c) Check price-vs-value classification (Bid vs VAH/VAL) at three moments: above, inside, below. (d) Check migration: compare today's POC with the prior scope's POC; a move of more than one bin must flag migration, a move of exactly one bin must not.
- **Pass:** VAH/VAL match the hand expansion; contained volume ≥ 70%; price-vs-value correct at all three moments; migration flag correct in both directions. **Fail:** Value area below 70%; VAH/VAL off by a bin; migration flagged for a one-bin move or missed for a two-bin move.

### Test 7 — Liquidity sweep classification

- **Setup:** EURUSD H1, defaults (`InpConfirmBars` = 3, `InpBreakoutBars` = 3, `InpSweepTolerancePts` = 0).
- **Steps:** (a) Find a historical case of a closed H1 bar wicking beyond PDH and a later closed bar closing back below it with **no** close above PDH → must be recorded as a sweep (`FBPI_LIQ_SWEEP_UP`), with the excursion bar time and confirming bar time as bar open times. (b) Find a case of a close above PDH followed by a close back below → must be a **failed breakout**, recorded as an event, **not** a sweep. (c) Find a case of closes staying above PDH for 3 bars → sustained breakout (`FBPI_LIQ_BREAKOUT_UP`). (d) Confirm **no** classification exists before the excursion bar closes — the excursion must be detected on a closed bar, never on the live Bid. (e) Confirm the event is in `FBPI_Sweeps_<SYMBOL>.csv` with the 9-column format (§4).
- **Pass:** All three cases classified correctly; no classification before the excursion bar closed; all events in the CSV with correct bar times. **Fail:** A failed breakout counted as a sweep; any classification triggered by a live tick; an event missing from the CSV; bar times recorded as tick times instead of bar open times.

### Test 8 — Probability calculation and sample size

- **Setup:** EURUSD H1, ≥ 100 days history, defaults.
- **Steps:** (a) Pick one level (PDH). By hand, over 20 days: reconstruct each day's forecast PDH from the previous day, test the touch inside [00:00, 21:00) UTC on H1 bars, count touches and eligible days, and compare the percentage and N with the displayed values. (b) **Regression check: PDC must not be 100%.** If PDC shows 100% with a real sample size, stop — the engine has the FLR OR-tautology bug (§2.2 of the Probability Methodology). (c) Verify the Wilson interval contains the point estimate and matches a hand computation (§6 of the Probability Methodology). (d) Attach to a symbol (or truncate history) with fewer than 20 eligible days and confirm the display is `INSUFFICIENT DATA (N=…)` and **no** scoreboard row is written for that level.
- **Pass:** Hand count matches displayed % and N; PDC is not 100%; Wilson interval hand-verified; short history shows INSUFFICIENT DATA with no row written. **Fail:** Any mismatch in % or N; PDC at 100%; Wilson interval not containing the point estimate; a probability shown without N; a row written for N < 20.

### Test 9 — Confirmation scoring

- **Setup:** Defaults (weights 20/20/20/20/10/10 = 100; bands Strong 80–100, Moderate 65–79, Weak 50–64, Insufficient < 50).
- **Steps:** On a known setup, score each factor by hand from the code rules: HTF Alignment — full points when MN1+W1+D1 agree, half when 2 of 3 agree, 0 on conflict, 0 when any of the three is invalid; Key-Level Location — full when price is within `InpApproachPips` (5.0 pips) of a level whose touch probability is ≥ 65%, half when ≥ 50%, 0 below 50% or when the level's probability is insufficient data; Liquidity Event — full when a sweep in the setup direction occurred within the last 20 bars; Market Structure — full on an H1/H4 structure shift (breakout or HH/HL in the direction), half when only the auction trend agrees; Candle Confirmation — full on a closed candle closing beyond the level or an engulfing candle in the direction (closed candle only when `InpRequireClosedCandle` is true); Session Alignment — full when London/New York (or the overlap) direction matches, half when the session direction is neutral, 0 in Asian or when the session opposes. Then: (a) confirm the total equals the sum of the six factors; (b) confirm the band matches the thresholds; (c) remove the data for one factor (e.g. attach where no level is near) and confirm that factor scores **0**, never positive.
- **Pass:** Every factor hand-verified; total and band correct; weights sum to 100; missing data scores 0. **Fail:** Any factor mis-scored; weights not summing to 100 (Init must reject this); a missing-data factor scoring above 0; band not matching the thresholds.

### Test 10 — Risk and position sizing

- **Setup:** Defaults: paper capital $5,000, risk 0.5% ($25.00), max daily loss 2%, min R:R 2.0, preferred 3.0.
- **Steps:** For three symbols — EURUSD, a JPY pair (e.g. USDJPY), and a 3-digit broker symbol if available — hand-compute: `riskAmount = 5000 × 0.5 / 100 = $25.00`; `stopDistancePips = |entry − stop| / (point × pointsPerPip)`; `pipValue` per 1.0 lot from `MarketInfo` (tick value adjusted by tick size/point — never assumed); `positionSize = 25 / (stopPips × pipValue)`, **rounded down** to the broker lot step; `spreadCost = spread (pips) × pipValue × size`; `commission = InpCommissionPerLot × size`; `potentialProfit = |target − entry| pips × pipValue × size`; `rewardRisk = potentialProfit / 25`. Compare each with the displayed plan. Then: (a) set a target giving R:R < 2.0 and confirm the `violatesMinRR` warning and `REJECTED — RISK RULE VIOLATION` status; (b) set `InpDailyLossSoFar` so that daily loss + $25 exceeds the 2% limit and confirm the daily-loss violation fires; (c) use a stop so tight the size rounds below the broker minimum lot and confirm `violatesLotStep` rejects the plan.
- **Pass:** All three symbols hand-verified to the lot step; rounding is always down, never up; all three violation warnings fire with the correct status. **Fail:** Any size, pip value, or R:R mismatch; rounding up; a violation not flagged; a pip value assumed when `MarketInfo` returns 0 (must be `DATA UNAVAILABLE` and the plan rejected).

### Test 11 — Dashboard functionality

- **Setup:** Defaults, all five sections enabled.
- **Steps:** (a) Confirm all five sections render: A Global Context, B Market Structure, C Session Intelligence, D Liquidity and Volume, E Execution Readiness. (b) Hide the dashboard and re-show it; drag it by the title bar to reposition it. (c) With no manual macro data entered, confirm Section A shows grey `DATA UNAVAILABLE`, not zeros or invented values. (d) Confirm the dashboard never changes a market value: change nothing on the chart, detach and re-attach, and confirm every displayed value is identical (the dashboard reads globals; it must not contain any calculation — verify by code inspection that `FBPI_Dashboard.mqh` contains no level, probability, scoreboard, or risk computation).
- **Pass:** All sections render; hide/reposition work; unavailable data is grey `DATA UNAVAILABLE`; values identical across re-attach; no calculation in the dashboard module. **Fail:** Any section missing or wrong; a hidden panel that cannot be restored; unavailable data shown as a number; any value changing across a re-attach without new bars.

### Test 12 — Historical replay and look-ahead prevention

- **Setup:** EURUSD H1, at least 30 finalised scoreboard rows.
- **Steps:** (a) Record the PDH for 30 past days and the finalised rows for those days (copy the scoreboard CSV). (b) Restart the terminal (or detach and re-attach the indicator) and re-read the same 30 days' PDH values and the same rows. (c) Confirm a past day's PDH and a finalised scoreboard row are **identical** when re-read 30 days later — no repainting. (d) Confirm no finalised row changed: compare the copied CSV with the live file (append-only; new rows may exist, old rows must be byte-identical). (e) Confirm the replay path and the live path agree: the probability computed from the loop over the same 30 days matches the stored forecast for those days.
- **Pass:** All 30 PDH values identical; all finalised rows byte-identical; replay and live probabilities agree. **Fail:** Any past value changed on re-read; any finalised row edited; replay and live disagree (look-ahead or repainting).

### Test 13 — Data persistence after MT4 restart

- **Setup:** At least one finalised row and one open forecast (capture today's forecast, then restart before the day ends).
- **Steps:** (a) Before restart, record: the scoreboard row count, the totals (observations, touches, mean forecast, Brier), and the open-forecast file contents. (b) Close MT4 completely and reopen it with the indicator attached. (c) Confirm the scoreboard CSV loads, the totals are unchanged, and **no duplicate rows** exist (check the dedup: same `symbol|trading_day|level` appearing twice). (d) Confirm the open forecast survived the restart and is still the frozen forecast (same `forecast_pct`, `forecast_time`, `observations`) — not recomputed. (e) Leave the terminal off across a day boundary, restart, and confirm yesterday's row finalises from the persisted open forecast instead of being lost (the FLR limitation this fixes).
- **Pass:** Totals unchanged; no duplicates; open forecast intact across a restart; cross-boundary restart finalises from the persisted forecast. **Fail:** Any total changed; any duplicate row; any open forecast lost or overwritten; a day finalised from recomputed rather than frozen values.

### Test 14 — Multi-symbol compatibility

- **Setup:** All 15 watchlist pairs: EURUSD, GBPUSD, USDJPY, USDCHF, USDCAD, AUDUSD, NZDUSD, EURGBP, EURJPY, GBPJPY, AUDJPY, CADJPY, CHFJPY, EURAUD, GBPAUD.
- **Steps:** (a) Enable the watchlist scan (`InpEnableWatchlistScan` = true, `InpScanMaxPairs` = 15 — off by default) and confirm all 15 pairs show a PDH position line or an explicit "no data" row; a pair the broker does not offer must show "symbol not offered by broker", never a guessed symbol. (b) Attach the indicator in turn to a JPY pair and confirm its PDH probability and pip value are sane (JPY pairs are 2/3-digit: points-per-pip is 1 on 2-digit, 10 on 3-digit — a JPY pip value 100× out confirms a pip/point confusion). (c) Confirm the scan is bounded: at most `InpScanMaxPairs` (1…30) symbols, one prev-day H/L scan each, reporting only the Bid's position vs the previous day's range.
- **Pass:** All 15 pairs accounted for (value or explicit no-data); JPY pip value and probability sane; scan bounded. **Fail:** Any pair silently missing; a JPY pip value off by 10× or 100×; the scan doing more than its bounded PDH check per symbol.
  - *Note on the scan's bound.* The scan as coded (`FBPI_Main_ScanWatchlist()`) does one prev-day H/L scan per symbol and reports the Bid as "N.N pips above PDH", "N.N pips below PDL", or "inside prev-day range" — it computes **no** probability per symbol. The Architecture document (§8, L-6) describes the multi-pair scan as "PDH-only with lookback capped at 50"; the code as written is narrower than that description (no lookback at all), which is a divergence to record, not a test failure — the test checks the scan that exists.

### Test 15 — Performance and resource utilisation

- **Setup:** EURUSD H1, defaults, 5-second refresh (`InpRefreshSeconds` = 5), watchlist scan enabled for the stress case.
- **What to measure.** There is **no in-indicator timer** — the code contains no `GetTickCount` instrumentation — so all measurements are external:
  - **Recalculation time on a new bar:** watch the Experts/Journal timestamps around the new-bar recalculation, and observe the terminal for visible lag (chart redraw delay, missed clicks) during the recalculation. A full probability recomputation touches at most lookback (100) days × ~48 H1 bars × 7 levels ≈ 34,000 bar visits, and runs only on a new bar, on first calculation, or on input change — never per timer tick. Ticks between recalculations refresh only live price labels.
  - **Object count:** count chart objects (`ObjectsTotal()` via a script, or count `FBPI_`-prefixed objects in the Objects List, Ctrl+B). Budget: ~29 level lines/labels + 100 sweep markers maximum + dashboard labels ≈ **250 objects**. Fail if the count grows without bound across days.
  - **Memory:** Windows Task Manager → `terminal.exe` memory before attaching, after 1 hour, and after 24 hours. Fail on steady growth (a leak) rather than on any absolute number — the absolute figure depends on the terminal's history depth.
  - **CPU:** Task Manager CPU for `terminal.exe` with the indicator on a 5-second refresh and the scan enabled; the terminal must stay responsive (no visible lag).
- **Pass:** No visible lag on new-bar recalculation; object count ≤ ~250 and stable across days; memory stable across 24 hours; terminal responsive with the scan enabled. **Fail:** Visible lag or freezing on new bars; object count growing daily; memory growing steadily; probabilities recomputing on every timer tick (check the Experts log — recomputation must appear only on new bars).

### Test 16 — Missing and stale external data

- **Setup:** No external feed configured (the default state).
- **Steps:** (a) Confirm the order-book panel shows `ORDER BOOK UNAVAILABLE` in grey. (b) Confirm the order-flow/footprint panel shows `ESTIMATED TICK ACTIVITY` — never true bid/ask footprint — with the delta proxy labelled as a tick-volume estimate. (c) Confirm the futures row shows `DATA UNAVAILABLE` (or a broker CFD labelled "broker CFD — not exchange futures" if one is configured). (d) Enter a manual central-bank rate, then set its date older than its max age (rates: `InpRateMaxAgeHours` = 2160 h = 90 days; all other manual values: `InpMacroMaxAgeHours` = 168 h = 7 days) and confirm the display shows `STALE DATA` — stale never silently becomes current. (e) Remove a configured cross-market symbol (e.g. set a wrong gold symbol) and confirm that row shows `DATA UNAVAILABLE`, never a guessed symbol.
- **Pass:** Every missing datum shows its exact unavailable string; stale data is flagged, never shown as current; no invented depth, flow, or futures value anywhere. **Fail:** Any fabricated value; a stale value shown as current; a wrong symbol silently matched to a similar one.

### Test 17 — No automatic trade execution

- **Setup:** All source files, as delivered.
- **Steps:** Run this exact search over the project directory (PowerShell on the laptop, or `grep -rn` in the shell):
  ```
  grep -rn "OrderSend\|OrderModify\|OrderClose\|OrderDelete\|OrderSelect\|#import\|WebRequest" --include="*.mq4" --include="*.mqh" .
  ```
  (a) Confirm the only matches are in **comments** stating the prohibition (e.g. the headers of `FBPI_Common.mqh`, each module, and `FBPI_Main.mq4`). (b) Confirm no trade-execution code exists in any file: no order function, no DLL import, no WebRequest, no paid external service. (c) Confirm the execution panel contains no button, order function, or link that could place a trade, and that `READY FOR HUMAN REVIEW` is the most actionable status the indicator ever shows — with the human decision happening outside the indicator.
- **Pass:** Grep returns matches only in prohibition comments; no executable trade code; no order-placing control. **Fail:** Any executable match, in any file, for any reason. This test is re-run after **every** phase (Architecture §9) — a single failure blocks acceptance regardless of the other sixteen tests.

## 6. Recording results

Record each test in the Quality Assurance Report (Phase 12 deliverable) with: test number and name, date, symbol(s), terminal/MetaEditor build, inputs (or "defaults"), verdict (PASS / PARTIAL / CANNOT-VERIFY-WITHOUT-TERMINAL), the evidence (file excerpt, log line, or screenshot reference), and, for PARTIAL, exactly which check failed and what remains. A PARTIAL verdict must name the failing check — "mostly works" is not a result.

Current status at the time of writing (2026-11-27): **all 17 tests are CANNOT-VERIFY-WITHOUT-TERMINAL**. The static audit that produced this protocol found no executable trade code (Test 17's grep pattern was checked against the delivered sources during documentation, but the verdict stays CANNOT-VERIFY until the grep is run on the compiled delivery on the user's laptop) and identified the divergences listed in §7, which the tester must keep in mind — they are not test failures, they are known differences between the code and the Architecture document.

## 7. Known divergences the tester must know about

1. **Forecast PDH window is 24 hours; live PDH is 21.** The probability engine reconstructs the previous day's PDH/PDL/PDC from a full 24-hour window, while MarketStructure builds the live PDH from [00:00, 21:00) UTC. Test 8's hand count must use the engine's 24-hour reconstruction, not the live PDH — and the divergence should be reconciled before Test 8 is treated as final.
2. **Day anchors differ between modules.** MarketStructure uses true UTC epoch arithmetic; Liquidity and Statistics compute "UTC midnight" from `TimeCurrent()` (broker time). At broker offset 0 they agree; otherwise they differ by the offset. Run Tests 1, 8, 12, and 13 with the broker offset in force and record it.
3. **Late-issued forecasts are log-only.** The CSV cannot distinguish a late-issued row from an on-time one. Test 13's cross-boundary check must use the Experts log, not the CSV alone.
4. **Calibration uses 10 decile bins**, not the Architecture document's five. Test the deciles as coded; the five-bin scheme is recoverable by merging.
5. **A settings change that keeps the 21-column header continues the same file.** Only a header mismatch forks to `_v2`. When testing with changed settings, start from a fresh files folder or expect the rows to share a file.
6. **The Architecture §6.1 example row's Wilson bounds (62.40–80.60) do not reproduce** from 72 touches in 100 days (recomputed: 62.51–79.86). Use the code's formula for Test 8's hand check, not the Architecture example row.
7. **No in-indicator performance timer exists.** Test 15 is measured externally (§5, Test 15) — do not report a recalculation time the indicator never measured.
