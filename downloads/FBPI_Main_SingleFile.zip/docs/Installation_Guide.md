# Forex Bigger Picture Intelligence System — Installation Guide

| Field | Value |
|---|---|
| Project ID | FBPI-MT4-001 |
| Product | Forex Bigger Picture Intelligence System v1.0 |
| Platform | MetaTrader 4 (MT4), MQL4 build 600+, `#property strict` |
| File | `FBPI_Main.mq4` + 14 include files (`include/FBPI_*.mqh`) |
| Date | 2026-11-27 |
| Companion documents | `User_Manual.md`, `Session_Configuration_Guide.md`, `Risk_Management_Guide.md`, `Technical_Architecture.md`, `Data_Source_Register.md` |
| Spec | `FBPI-MT4-001-spec.md` v1.0 (source of truth) |

> **Read this first — the single most important fact in this guide.**
> **No compiled `.ex4` file is shipped with this indicator.** This environment has no MetaEditor compiler (MetaEditor is a 32-bit Windows program and cannot run here), so the indicator could not be compiled during development. Only the source files (`.mq4` + `.mqh`) are delivered. **You must compile the indicator yourself in MetaEditor on your laptop** (Step 4 below). Until you do that, nothing in this guide can be tested live: every behaviour described in these documents comes from a static audit of the source code only. Compilation and live behaviour in MT4 are **unverified** until you run them on your laptop.

> **Analytical only.** This indicator never places, modifies, or closes trades. There is no `OrderSend`, `OrderModify`, `OrderClose`, `OrderDelete`, `#import`, `WebRequest`, or DLL anywhere in the code. Human approval is mandatory for every trade, outside the indicator.

---

## 1. Prerequisites

Check each item before you start. If any item is missing, stop and fix it first — the later steps will fail without it.

| # | Requirement | Why it matters |
|---|---|---|
| 1 | **MetaTrader 4, build 600 or higher** (terminal + MetaEditor) | The code uses `#property strict` and `input group`, which require build 600+. Older builds will not compile it. Check your build in MT4: **Help → About**. |
| 2 | **MetaEditor** (installed with MT4) | This is the only supported compiler. There is no other way to produce the `.ex4`. |
| 3 | **A chart with at least 50 bars** (`Bars >= 50`) | `OnInit()` refuses to attach (`INIT_FAILED`) if the chart has fewer than 50 bars, and prints "not enough bars on chart (need 50+)". |
| 4 | **Enough H1 history: ~100 days of H1 bars (about 2,400 bars)** | The probability engine looks back `InpProbLookback` = 100 days by default. With shorter history, days outside available history are excluded from the sample size (N shrinks) and levels show `INSUFFICIENT DATA (N=…)` until enough history exists. |
| 5 | **M15 history** for the opening range | The opening range is calculated from M15 bars. If your broker has no M15 history for the symbol, the opening-range levels are `DATA UNAVAILABLE`. |
| 6 | **A Windows laptop/PC** (or a Windows environment that runs MetaEditor) | MetaEditor cannot run in this delivery environment. Compilation must happen on your machine. |
| 7 | **The 16 source files listed in §2** | One missing include file is a compile error (see §7). |

**Recommended first chart:** EURUSD, H1 timeframe. H1 is the timeframe the indicator's aggregations are built from (all daily/session/quarterly/monthly/weekly extremes are scanned from H1 bars), and EURUSD is the first pair in the default watchlist. You can attach it to any chart and any timeframe afterwards — the calculations do not depend on the chart timeframe except for the auction classification, which uses the chart timeframe — but EURUSD H1 is the simplest first test.

**History tip.** Before attaching, maximise the history MT4 holds: **Tools → Options → Charts → Max bars in history** (set it high, e.g. 500,000) and then scroll the H1 chart fully to the left so MT4 downloads the missing history. Do the same on M15. If you skip this, the first days will show small sample sizes (small N) and several `INSUFFICIENT DATA` rows. That is the indicator working correctly, not a fault.

---

## 2. What you received — exact folder layout

The delivery is 16 source files (15 after the 2026-11-27 compile fix added FBPI_Types.mqh). They must be placed in exactly this layout inside your MT4 data folder. The layout matters because `FBPI_Main.mq4` includes its modules with relative paths (`#include "include/FBPI_Common.mqh"`), so the `include` folder must sit **next to** `FBPI_Main.mq4`, not somewhere else.

```
<MT4 data folder>\MQL4\Indicators\FBPI\
│
├── FBPI_Main.mq4                  ← the indicator itself (inputs, event handlers)
│
└── include\
    ├── FBPI_Types.mqh            ← shared types ONLY: constants + enums (must load before the inputs)
    ├── FBPI_Common.mqh           ← shared contract: structs, globals, helpers (includes FBPI_Types.mqh)
    ├── FBPI_Storage.mqh          ← file I/O (scoreboard / forecast / sweep CSVs)
    ├── FBPI_Macro.mqh            ← Layers 1–7: global context, monetary policy, cross-market
    ├── FBPI_MarketStructure.mqh  ← Layers 8–11: quarterly / monthly / weekly / daily + MTF table
    ├── FBPI_Sessions.mqh         ← Layer 12: sessions, UTC frame, broker offset, DST
    ├── FBPI_OpeningRange.mqh     ← Layer 13: opening range (M15 bars)
    ├── FBPI_Auction.mqh          ← Layer 14: intraday auction classification
    ├── FBPI_VolumeProfile.mqh    ← Layers 15–16: tick-volume profile, POC, VAH, VAL
    ├── FBPI_Liquidity.mqh        ← Layer 17: key levels, probabilities, sweep/breakout logic
    ├── FBPI_OrderFlow.mqh        ← Layers 18–20: order book / order flow (honest fallback)
    ├── FBPI_Confirmation.mqh     ← Layer 21: confirmation score + setup identification
    ├── FBPI_Risk.mqh             ← Layers 22–23: risk plan + execution status
    ├── FBPI_Statistics.mqh       ← Spec §12: scoreboard, Brier score, calibration
    └── FBPI_Dashboard.mqh        ← Spec §8: dashboard Sections A–E + scoreboard panel
```

**File count check:** 1 × `.mq4` + 15 × `.mqh` = 16 files. If you have fewer, stop — a file is missing and compilation will fail.

**Do not rename any file.** The `#include` lines use these exact names. Do not move the `.mqh` files out of the `include` folder, and do not place `FBPI_Main.mq4` directly in `MQL4\Indicators\` without its `include` folder beside it.

**Files the indicator creates itself (you do not need to create them):** when it runs, it writes CSV files into `<MT4 data folder>\MQL4\Files\`, all prefixed `FBPI_`:

- `FBPI_Scoreboard_<SYMBOL>.csv` — finalised forecast rows (21 columns).
- `FBPI_Forecasts_<SYMBOL>.csv` — today's open (unfinalised) forecast, deleted on finalisation.
- `FBPI_Sweeps_<SYMBOL>.csv` — one row per sweep / failed-breakout event.

Do not edit these files by hand. If a scoreboard file's header ever stops matching the expected 21 columns, the indicator starts a new `<name>_v2.csv` file and prints a message; the old file is never overwritten or silently reinterpreted.

---

## 3. Step-by-step installation

### Step 1 — Find your MT4 data folder

1. Open MetaTrader 4.
2. Click **File → Open Data Folder**.
3. Windows Explorer opens at your data folder (typically something like `C:\Users\<you>\AppData\Roaming\MetaQuotes\Terminal\<long ID>\`). **Use this folder, not the folder where MT4 was installed** — MT4 reads indicators from the data folder.

### Step 2 — Copy the files

1. In the data folder, open `MQL4`, then `Indicators`.
2. Create a new folder named exactly `FBPI`.
3. Copy `FBPI_Main.mq4` into `MQL4\Indicators\FBPI\`.
4. Inside `FBPI`, create a folder named exactly `include` (lowercase).
5. Copy all 14 `FBPI_*.mqh` files into `MQL4\Indicators\FBPI\include\`.
6. Re-check the layout against §2. The most common installation mistake is putting the `.mqh` files directly in `FBPI\` instead of `FBPI\include\` — that will not compile.

### Step 3 — Refresh the Navigator

1. In MT4, open the **Navigator** panel (Ctrl+N if it is hidden).
2. Right-click **Indicators** and choose **Refresh**.
3. Expand Indicators: you should now see a folder/group entry for **FBPI** containing **FBPI_Main**. If it does not appear, the files are in the wrong folder — go back to Step 2.

### Step 4 — Compile in MetaEditor (on your laptop — required)

1. In MT4, click **Tools → MetaQuotes Language Editor** (or press F4). MetaEditor opens.
2. In MetaEditor, click **File → Open** and open `<data folder>\MQL4\Indicators\FBPI\FBPI_Main.mq4`.
3. Click **Compile** (or press **F7**).
4. Look at the bottom of MetaEditor:
   - **Success looks like:** `0 errors, 0 warnings` (or a small number of warnings only) and a new file `FBPI_Main.ex4` appears next to `FBPI_Main.mq4` in the `FBPI` folder.
   - **Failure looks like:** one or more errors listed in the Errors tab. See §7 for what each kind of error means.
5. **If compilation succeeds, you have just produced the only `.ex4` that exists.** Keep it beside the `.mq4`. MT4 runs the `.ex4`; the `.mq4` is the human-readable source.

> **Why there is no `.ex4` in the delivery (repeated because it matters):** this indicator was written and statically audited in an environment with no MetaEditor compiler. No `.ex4` was ever produced, and none is claimed. The first successful F7 compile on your laptop is the first time the code has ever been compiled. If it does not compile, that is new information — record the exact error text from MetaEditor and treat it as a defect to fix, not as a step to skip.

### Step 5 — Attach to a chart

1. Open a chart for the symbol you want to analyse (EURUSD, H1, is the recommended first chart).
2. Make sure the chart has at least 50 bars and, ideally, 100+ days of H1 history (see §1).
3. In the **Navigator**, drag **FBPI_Main** onto the chart — or double-click it.
4. The indicator's properties window opens, with tabs **Common** and **Inputs**.
   - **Common tab:** leave "Allow DLL imports" **unchecked**. The indicator needs no DLLs and must never be given DLL permission. "Allow live trading" is irrelevant (the indicator never trades) — leave it unchecked as well.
   - **Inputs tab:** every setting is listed here, grouped (General, Symbols, Macro, Market Structure, Sessions, Volume, Liquidity, Confirmation, Risk, Alerts, Statistics). Defaults are the values documented in the User Manual. For a first run, **change nothing** — accept the defaults and click OK.
5. The dashboard should appear in the top-left corner of the chart (default: `InpDashCorner` = top-left, `InpDashX` = 10, `InpDashY` = 15), titled **FOREX BIGGER PICTURE INTELLIGENCE**, with Sections A–E and a scoreboard panel below it. Horizontal lines for the key levels should appear on the chart.

### Step 6 — Load a preset (`.set`) — optional

A preset (`.set`) file is a saved copy of the Inputs tab, so you can reuse a configuration across charts or after an MT4 reinstall.

1. With the indicator attached, right-click the chart → **Indicators List** → select **FBPI_Main** → **Edit**.
2. On the **Inputs** tab, click **Load**, pick a `.set` file, and click OK. Or click **Save** to save your current inputs as a `.set` file for later.
3. The same Load/Save buttons are available in the properties window at attach time (Step 5.4).

**Note on shipped presets:** no `.set` preset files are shipped with this delivery — the project's `presets/` folder is empty at the time of writing. There is no "default", "conservative", or "aggressive" preset to load yet. Start from the built-in defaults (which are the documented defaults in the User Manual), adjust them to your broker and preferences, and use **Save** to create your own presets. If a preset is added later, it will be a `.set` file you load exactly as above.

---

## 4. First-run checklist

Work through this list on your first attach, in order. Tick each item only when you have actually seen it on your chart.

- [ ] **1. The dashboard appears.** Title "FOREX BIGGER PICTURE INTELLIGENCE", Sections A–E visible, dark background, gold accents. If the chart is blank, see §7 "Dashboard not showing".
- [ ] **2. Section A shows `DATA UNAVAILABLE` for the central banks.** This is correct on a first run. No policy rates have been entered yet (they are manual inputs, default `-999.0` = not entered). The rate differential line should read `DATA UNAVAILABLE (enter both policy rates)`. See the User Manual for how to enter rates.
- [ ] **3. Section B shows quarterly / monthly / weekly / daily rows with real prices.** PDH / PDL / PDC and the day open should be numbers, not `DATA UNAVAILABLE`. If they are unavailable, you probably lack H1 history — scroll the chart left to download more.
- [ ] **4. Section C shows the current session.** It should name one of Asian / London / New York / London–New York overlap, or say the market is closed (weekend or between sessions). Session high/low rows for sessions that have not started yet today correctly say "not started — no bars yet".
- [ ] **5. Section D shows POC / VAH / VAL.** If it says `DATA UNAVAILABLE (fewer than 10 bars in scope)`, the current trading day has fewer than 10 H1 bars so far — wait for the day to progress, or check later in the day.
- [ ] **6. Section D shows `ORDER BOOK UNAVAILABLE`.** This is correct and expected. MT4 has no consolidated Forex order book; the indicator never invents one. Order flow should read `ESTIMATED TICK ACTIVITY`.
- [ ] **7. Section E shows a confirmation score and an execution status.** On a first run with no setup identified, the status is normally `ANALYSIS INCOMPLETE`. That is a valid state, not an error. The six factor rows should all be visible, with missing-data factors showing `0 pts` and `No data`.
- [ ] **8. Level lines are drawn on the chart.** Horizontal lines labelled PDH, PDL, PDC, and others. PDH / PDL / POC lines are drawn thicker (width 2); the rest width 1.
- [ ] **9. The Experts tab shows the startup line.** Open **Terminal → Experts** (Ctrl+T, then the Experts tab). You should see: `FBPI: Forex Bigger Picture Intelligence v1.00 initialised on <SYMBOL> <timeframe> | refresh=5s | watchlist=15 pair(s)`. On a very first run you will also see `FBPI: no scoreboard file for <SYMBOL> yet (first run - nothing to load)` — that is normal.
- [ ] **10. No trade was placed.** Check the **Trade** tab: nothing. The indicator cannot trade, but confirming this on your first run is worth the ten seconds.

**What "normal" looks like on day one:** several `DATA UNAVAILABLE` rows (macro, futures, order book), `INSUFFICIENT DATA` probabilities until 20+ days of history are evaluated, an empty scoreboard panel saying "No finalised scoreboard rows yet", and possibly `ANALYSIS INCOMPLETE`. All of these are the indicator telling the truth about what it does not yet know. They are not faults.

---

## 5. Removing the indicator

1. Right-click the chart → **Indicators List** → select **FBPI_Main** → **Delete**, then click Close.
   - Or: right-click the chart → **Indicators List** → **Delete All** (removes every indicator on that chart).
2. `OnDeinit()` runs automatically: it stops the refresh timer and deletes **all** chart objects whose names start with `FBPI_` — the dashboard, the scoreboard panel, the level lines and labels, and the sweep arrows. Nothing `FBPI_` should be left on the chart afterwards.
3. The CSV files in `MQL4\Files\` are **not** deleted on removal. That is deliberate: they are your historical record. Delete them by hand only if you want to erase the scoreboard history (see §7, "Starting the scoreboard over").
4. To remove the indicator from MT4 entirely, delete the `MQL4\Indicators\FBPI\` folder (after removing it from all charts) and refresh the Navigator.

---

## 6. Updating to a new version

1. Remove the indicator from every chart it is attached to (see §5, steps 1–2).
2. Close MetaEditor if `FBPI_Main.mq4` is open in it.
3. Overwrite the 16 source files with the new versions, keeping the exact layout in §2.
4. Recompile in MetaEditor (F7) — a new `.ex4` replaces the old one.
5. Re-attach to your charts. Your saved `.set` presets from §3 Step 6 still load, but check them: if a new version added or renamed an input, a stale preset may silently leave the new input at its default. Re-save your presets after an update.
6. **Scoreboard files:** if a new version changes the 21-column scoreboard format, the indicator will detect the header mismatch on load and start a `<name>_v2.csv` file. Your old file is kept, not overwritten. Do not merge the files by hand.

---

## 7. Troubleshooting

Read the **Experts** tab first for every problem below (Terminal → Experts, Ctrl+T). The indicator prints a line starting with `FBPI:` for every validation failure and most runtime problems, including the offending input name and value. Quote that exact line if you report a problem.

### Compile errors in MetaEditor

| Symptom | Likely cause | Fix |
|---|---|---|
| `Cannot open file 'include/FBPI_*.mqh'` or `file not found` | The `.mqh` files are not in `FBPI\include\` next to `FBPI_Main.mq4` | Re-do §3 Step 2 exactly. Do not move the include folder. |
| `'FBPI_...' - undeclared identifier` | A module file is missing or an old version of one file is mixed with new versions of the others | Check the file count in §2 (16 files). Replace the whole set from the delivery, not single files. |
| `'Inp...' - undeclared identifier` | A module was compiled on its own, or `FBPI_Main.mq4` was edited | Only ever compile `FBPI_Main.mq4`. Never compile a `.mqh` file directly — they are includes, not standalone programs. |
| Any other error on first compile | The code has never been compiled before (see the box at the top of this guide) | Record the exact error text (file, line, message) from MetaEditor. Do not guess a fix by editing the code — an incorrect edit can silently change a calculation. |
| Warnings only, `0 errors` | Warnings are not fatal | Note them, but the `.ex4` is still produced and usable. Acceptance requires zero errors; warnings should be documented, not ignored. |

### The indicator will not attach / attaches and immediately disappears

| Symptom | Likely cause | Fix |
|---|---|---|
| Nothing appears; Experts tab shows `FBPI: invalid Inp...` | An input is outside its allowed range (e.g. confirmation weights do not sum to 100, `InpOpeningRangeMinutes` is not 15/30/60, `InpValueAreaPct` is outside 50–90, `InpRiskPct` outside 0.1–5.0, a session time is not `"HH:MM"`) | The Experts line names the input. Open the Inputs tab, correct that input, and re-attach. The full validation list is in the User Manual, §9. |
| Experts tab shows `FBPI: not enough bars on chart (need 50+)` | The chart has fewer than 50 bars | Attach to a chart with more history, or scroll left to download history, then re-attach. |
| Experts tab shows `FBPI: <Module> init failed` | A module rejected its inputs or found no data | Read the module's own `Print` line just above it in the Experts tab — it names the problem. |
| Indicator attaches, then vanishes when you change timeframe | This is normal MT4 behaviour: changing timeframe re-initialises indicators | Re-attach if it does not come back on its own. |

### No data / dashboard not showing

| Symptom | Likely cause | Fix |
|---|---|---|
| Dashboard does not appear at all | `InpShowDashboard` = false, or the dashboard was closed with its [x] control | Set `InpShowDashboard` = true and re-attach. If you closed it with [x], re-attaching is the way to bring it back. |
| Dashboard appears but is in the wrong corner / off-screen | `InpDashCorner`, `InpDashX`, `InpDashY` | Change the corner/offset in Inputs, or drag the panel by its title bar to move it (dragging updates its position; the new position is not saved as an input — re-attach resets it to `InpDashX`/`InpDashY`). |
| Everything in Section A is `DATA UNAVAILABLE` | No manual macro values have been entered | Correct on a first run. Enter policy rates and macro values as described in the User Manual. MT4 cannot supply these natively. |
| PDH / PDL / POC show `DATA UNAVAILABLE` | Not enough H1 history, or the session/profile window has fewer than 10 bars | Download more history (scroll the H1 chart left). Intraday, early in the trading day, the daily profile legitimately has too few bars — wait. |
| Probabilities show `INSUFFICIENT DATA (N=…)` | Fewer than `InpMinSample` (default 20) eligible days in the lookback | Normal until ~20+ days of history have been evaluated. N grows as history accumulates; nothing to fix. |
| Scoreboard panel says "No finalised scoreboard rows yet" | No forecast has been finalised yet | Rows appear after the first day rollover (finalisation happens at the next trading-day start). On day one this message is expected. |
| Order book shows `ORDER BOOK UNAVAILABLE` | No depth feed is configured — and none exists in v1 | Expected. Never a fault. See the User Manual, §"Order book / order flow". |
| Watchlist scan rows say "symbol not offered by broker" | Your broker lists a pair under a different name (prefix/suffix) | Set `InpSymbolPrefix` / `InpSymbolSuffix` to match your broker (e.g. suffix `.pro` → `EURUSD.pro`). A symbol that maps to nothing is `DATA UNAVAILABLE`, not a fatal error. |

### Objects left over after removal

| Symptom | Likely cause | Fix |
|---|---|---|
| `FBPI_` lines/labels remain after deleting the indicator | MT4 was closed while the indicator was attached, or removal was interrupted | Delete them by hand: press Ctrl+B (Objects List), sort by name, select every object starting with `FBPI_`, and delete. Then re-attach and remove cleanly once to confirm `OnDeinit()` clears them. |
| Old dashboard reappears after re-attaching | Stale objects from a previous run were not deleted | `OnInit()` deletes stale `FBPI_` objects on attach, so re-attaching once should clear them. If they persist, use the Objects List method above. |

### Alerts

| Symptom | Likely cause | Fix |
|---|---|---|
| No alerts at all | All alert types default to **off** except Level Touch (`InpAlertLevelTouch` = true) and Sweep (`InpAlertSweep` = true) | Enable the types you want in the Alerts input group, and check `InpAlertPopup` / `InpAlertSound` / `InpAlertPush`. Push notifications also require MT4 push settings (Tools → Options → Notifications) with your MetaQuotes ID. |
| Same alert fires repeatedly | The cooldown has expired and the condition is still true | This is by design: the cooldown (`InpAlertCooldownMinutes`, default 15) suppresses repeats only inside the window. Set it higher (up to 1440) to space repeats out, or 0 for no throttle at all. Note the approach alert has no edge latch — it re-fires after each cooldown while price stays within `InpApproachPips`. |
| Alerts fire on the wrong pair | Alerts are per-chart: they describe the symbol the indicator is attached to | Attach the indicator to each chart you want alerts for; an alert message always includes the symbol. |

### Starting the scoreboard over

If you want to erase all recorded forecast history and start clean (for example after changing `InpProbLookback`, `InpMinSample`, or the touch method — the indicator itself starts a new `_v2` file in that case, so you normally do not need to do this by hand):

1. Remove the indicator from all charts.
2. Delete `FBPI_Scoreboard_<SYMBOL>.csv`, `FBPI_Forecasts_<SYMBOL>.csv`, and `FBPI_Sweeps_<SYMBOL>.csv` from `MQL4\Files\`.
3. Re-attach. The scoreboard panel will say "No finalised scoreboard rows yet" until the first finalisation.

**Warning:** deleting these files permanently erases the recorded history. There is no undo. Copy them elsewhere first if you want a backup.

---

## 8. What is NOT verified by this guide

Be explicit about the limits, so nothing here is mistaken for a test report:

1. **Compilation has never succeeded yet.** No `.ex4` exists. The first F7 compile on your laptop is the first compile ever attempted.
2. **No live MT4 test has been run.** Dashboard rendering, session windows, probability values, alert delivery, and the scoreboard cycle have been verified only by reading the source code (static audit). Live behaviour may differ from the code as written if the code contains a defect the audit did not catch.
3. **No performance test has been run.** The architecture budgets a full probability recomputation at roughly lookback (100) days × ~48 H1 bars × 7 levels ≈ 34,000 bar visits, run only on a new bar — but that budget has not been measured in a live terminal.
4. **Broker differences are real.** Pip value, lot step, symbol names, spreads, and tick volume are all read from your broker at run time. The same indicator on two brokers can legitimately show different POC levels and different position sizes.

If anything in live use contradicts this guide, the code as compiled on your laptop is the authority for what the indicator actually does — report the discrepancy with the exact Experts-tab text and the input values in force, so the code (not the guide) can be corrected.

---

## 9. Quick reference — files and folders

| Item | Location |
|---|---|
| Indicator source | `<data folder>\MQL4\Indicators\FBPI\FBPI_Main.mq4` |
| Module sources | `<data folder>\MQL4\Indicators\FBPI\include\FBPI_*.mqh` (14 files) |
| Compiled indicator (after F7) | `<data folder>\MQL4\Indicators\FBPI\FBPI_Main.ex4` |
| Scoreboard / forecast / sweep CSVs | `<data folder>\MQL4\Files\FBPI_*.csv` |
| Presets you save | Anywhere you choose; loaded via Inputs → Load (`.set`) |
| MT4 data folder | MT4 → **File → Open Data Folder** |
| Log to check first | Terminal → **Experts** tab (Ctrl+T) |
| Documentation (this set) | Project `docs/` folder: `Installation_Guide.md`, `User_Manual.md`, `Session_Configuration_Guide.md`, `Risk_Management_Guide.md` |

*End of Installation Guide — FBPI-MT4-001 v1.0.*
