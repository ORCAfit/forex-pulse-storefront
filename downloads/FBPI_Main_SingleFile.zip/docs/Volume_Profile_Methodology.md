# Volume Profile Methodology — FBPI-MT4-001

| Field | Value |
|---|---|
| Project | Forex Bigger Picture Intelligence System, FBPI-MT4-001 |
| Spec | `FBPI-MT4-001-spec.md` v1.0, Layers 15–16 (source of truth) |
| Design authority | `docs/Technical_Architecture.md` §4.6 |
| Code | `include/FBPI_VolumeProfile.mqh` (Phase 5), `include/FBPI_Common.mqh` (`ProfileResult`) |
| Date | 2026-11-27 |
| Status | **Live-terminal verification outstanding.** Tests 5 and 6 (spec §17) are CANNOT-VERIFY-WITHOUT-TERMINAL until the indicator is compiled in MetaEditor and run on the user's laptop. Nothing in this document is a claim that the terminal agrees. |

## 1. What a volume profile is, in this system

A volume profile is a histogram of *how much volume traded at each price* inside a time window (the "scope"). It answers: where did the most trading happen (POC), where was most of the volume concentrated (value area), and which prices saw unusually much or little volume (nodes). It does not say where price will go.

One fact governs everything else in this document: **the volume is broker tick volume, never consolidated volume.** Spot Forex has no single centralized volume feed. The profile is built from `iVolume()` on H1 bars — the broker's count of price changes per bar — and is always labelled "Tick volume". It is broker-relative: the same symbol on another broker can give a different POC. A profile built from tick volume must never be called consolidated market volume, and a footprint built from it is labelled ESTIMATED TICK ACTIVITY, not true bid/ask footprint.

## 2. Construction, step by step

`FBPI_VolumeProfile_Build(scope, startBroker, endBroker, result)` builds one profile. The steps, exactly as coded:

### 2.1 Collect the bars

`FBPI_VolumeProfile_CollectBars()` collects H1 bars whose open time lies in `[start, end)`, oldest first, up to `FBPI_VP_MAX_BARS` = **512** bars. For each bar it records open time, high, low, and tick volume (`iVolume()`; a negative volume is clamped to 0). It also records the scope high (maximum bar high) and scope low (minimum bar low). It returns false when no bar exists in the window.

### 2.2 Validity gates

The profile is **invalid** (`valid == false`, `avail == UNAVAILABLE`) when any of these hold:

- Fewer than `FBPI_VP_MIN_BARS` = **10** H1 bars in scope.
- Zero price range (scope high − scope low ≤ 0).
- Zero total tick volume.

Missing volume is reported as unavailable, never invented.

### 2.3 Equal-width bins

The scope's price range is divided into `InpProfileBins` (default **24**, clamped 1…100, hard cap `FBPI_MAX_PROFILE_BINS` = 100) **equal-width** bins:

```
binSize = (scope high − scope low) / bins
binLow  = scope low
bin b covers [binLow + b × binSize, binLow + (b + 1) × binSize)
```

There is no variable-width or volume-equalised binning. Every bin has the same price width; bins differ only in how much volume falls in them.

### 2.4 Distributing each bar's volume across overlapped bins

This is the step that makes the bin volumes sum exactly to the total. Each bar's tick volume is distributed across the bins its `[low, high]` range overlaps, **in proportion to the overlap width** — i.e. volume is assumed uniform within the bar:

```
for each bin b overlapped by the bar:
    overlap = min(barHigh, binTop) − max(barLow, binBottom)
    binVolume[b] += barVolume × overlap / (barHigh − barLow)
```

A bar whose high equals its low puts its whole volume in the single bin containing its price (the code handles this as a special case: the bin index is `(price − binLow) / binSize`, clamped to the first/last bin). A bar with zero volume contributes nothing but still counts toward the 10-bar minimum.

Because each bar's volume is split by fractions that sum to 1, **bin volumes sum exactly to total tick volume** (up to floating-point rounding). Test 5 checks this equality on a real day: it is the single most useful arithmetic check on the whole module.

### 2.5 POC — Point of Control

`FBPI_VolumeProfile_ValueArea()` finds the POC bin first:

```
POC = centre of the bin with the greatest tick volume
    = binLow + (pocBin + 0.5) × binSize
```

**Ties go to the lowest-price bin**: the scan keeps the first maximum found scanning low to high (`>` comparison, not `>=`), so an equal-volume higher bin never displaces a lower one. The POC is a bin centre, not a traded price — it is the middle of the busiest price slice.

### 2.6 Value area — expansion from the POC

The value area is the smallest contiguous price range around the POC containing `InpValueAreaPct` (default **70%**, clamped 50–90% in `ValueArea()` and validated 50–90 at Init) of total tick volume. The algorithm:

1. Start with the POC bin alone. `inside = binVolume[pocBin]`, `topBin = botBin = pocBin`.
2. Target = total volume × pct / 100.
3. While `inside < target` and bins remain on either side: compare the adjacent upper bin's volume with the adjacent lower bin's volume; **add the larger one**. **Ties go up** (`upVol >= downVol` adds the upper bin). A side with no bins left contributes −1.0, so it is never chosen while the other side has bins.
4. Stop as soon as `inside >= target`, or when all bins are included.

Then:

```
VAH = top edge of the highest included bin = binLow + (topBin + 1) × binSize
VAL = bottom edge of the lowest included bin = binLow + botBin × binSize
```

Note what this is and is not. It is *a* contiguous range around the POC holding at least the configured share — the expansion is greedy (largest adjacent bin first), which is the standard construction and the one the spec's "smallest contiguous range" means here. Because whole bins are added, the included share normally **overshoots** the configured percentage (§7 shows 78.3% for a 70% target). That overshoot is by design, not an error: a bin is either in or out, and the area stops at the first bin that reaches the target.

### 2.7 Price vs value

At calculation time, using the Bid (falling back to the last H1 close if no Bid):

| Condition | `pricePos` | Display text |
|---|---|---|
| Bid > VAH | `FBPI_RANGE_UPPER` | "Above value" |
| Bid < VAL | `FBPI_RANGE_LOWER` | "Below value" |
| Otherwise (inside [VAL, VAH]) | `FBPI_RANGE_MID` | "Inside value" |

A Bid exactly equal to VAH or VAL counts as inside. `pricePos` is derived at calculation time and goes stale as price moves; it is refreshed on the next recalculation, not on every tick.

## 3. Scopes

`FBPI_VolumeProfile_Calculate()` rebuilds three profiles; it returns true when the daily profile is valid (the session/weekly profiles may legitimately be invalid early in their windows).

| Scope | Window | Notes |
|---|---|---|
| Daily (`g_fbpiProfileDaily`) | Current trading day, day start → now | Day start from `FBPI_VolumeProfile_DayAnchor()` (§3.1 caveat) |
| Session (`g_fbpiProfileSession`) | Current session window, or the most recently ended session today when none is active | Taken from `g_fbpiSessions[]`; invalid when no session window exists yet; end capped at now |
| Weekly (`g_fbpiProfileWeekly`) | Monday 00:00 UTC → now | Monday computed from the day anchor (§3.1 caveat) |

### 3.1 A divergence to record: the day anchor is broker-midnight, not UTC

The header comment says the windows are "UTC-anchored epoch times". The code as written computes its anchor from `TimeCurrent()`:

```
utcMid  = (TimeCurrent() / 86400) × 86400
dayStart = utcMid + dayStartMin × 60   (minus 86400 if dayStart is still in the future)
```

But `TimeCurrent()` is **broker** time, so `utcMid` is broker midnight, not UTC midnight. At `InpBrokerGMTOffset` = 0 the two coincide and the comment is true; at any other offset the daily profile starts at broker midnight (00:00 broker = 22:00 UTC previous day for a GMT+2 broker) while the MarketStructure daily window starts at 00:00 UTC. The weekly scope inherits the same anchor (Monday is computed from that midnight). This is a real inconsistency with the Architecture document and with the MarketStructure module; it should be reconciled (anchor on `TimeGMT()`) before Test 5 results are treated as final. The session scope does not have this problem — it reads its window from `g_fbpiSessions[]`, which is UTC-anchored.

## 4. High-volume and low-volume nodes

Mean bin volume = total volume / bin count. The thresholds are constants, not inputs:

```
High-volume node:  bin volume >= 150% of mean bin volume   (FBPI_VP_HVN_MULT = 1.5)
Low-volume node:   bin volume <=  50% of mean bin volume   (FBPI_VP_LVN_MULT = 0.5)
```

`FBPI_VolumeProfile_HighVolumeNodes()` / `LowVolumeNodes()` return the **bin centres** of the qualifying bins. The comparisons are inclusive: a bin at exactly 150% of the mean *is* a high-volume node, and a bin at exactly 50% *is* a low-volume node (§7 shows both boundary cases). A node is a description of where volume concentrated, not a support/resistance claim: a high-volume node is a price where a lot traded, which can act as either acceptance or a magnet, and the code claims neither.

## 5. Acceptance, rejection, migration

All three are evaluated on **closed bars only**, on the chart timeframe (not H1 — `iClose(_Symbol, 0, shift)`), and all three use the constant `FBPI_VP_VA_CONFIRM_BARS` = **3**.

### 5.1 Acceptance — `FBPI_VolumeProfile_IsAccepted()`

Price is accepted into the value area when **3 consecutive closed bars close inside [VAL, VAH], immediately preceded by a closed bar outside it**:

- Scan closed bars from shift 1 upward, counting closes inside the value area. Stop at the first close outside.
- If the run reaches 3, look at the next earlier bar: it must exist (not enough bars → false) and its close must be outside [VAL, VAH].
- A run that cannot be shown to have come from outside — e.g. the profile starts mid-range and all available bars are inside — returns false. Acceptance requires a demonstrated entry, not just presence.

### 5.2 Rejection — `FBPI_VolumeProfile_IsRejected()`

The **latest closed bar** (shift 1) wicked beyond VAH or VAL and closed back inside:

```
close inside [VAL, VAH]  AND  (High > VAH  OR  Low < VAL)
```

If the close is outside the value area, it is not a rejection — it is a close outside value, which is a different fact. Only the latest closed bar is tested; earlier bars' rejections are not re-reported.

### 5.3 Migration — `FBPI_VolumeProfile_HasMigrated(result, prior)`

The POC has migrated when it moved by **more than one bin** versus the prior scope's POC:

```
|current POC − prior POC| > current binSize
```

False when either profile is invalid or the bin size is ≤ 0. A move of exactly one bin is not migration; a move of more than one bin is. Note the comparison is against the *current* profile's bin size, and the "prior scope" is whichever profile the caller passes in — the function itself does not decide what "prior" means.

### 5.4 Divergence: the 3-bar count is a constant, not an input

The Architecture document §4.6 and the Data Source Register describe acceptance as "over `InpVAConfirmBars` = 3". **No `InpVAConfirmBars` input exists in the code.** The count is the compile-time constant `FBPI_VP_VA_CONFIRM_BARS` = 3, and the VolumeProfile header states this explicitly ("`InpVAConfirmBars` is not in the Phase 1 input list, so no such input is referenced"). The behaviour is identical at the default value of 3; the difference is that the user cannot change it from the inputs tab. If configurability is wanted, an input must be added and this document amended.

## 6. External futures volume (optional)

An external feed may be configured with `FBPI_VolumeProfile_SetExternalSource(sourceName, fileName)`. The file lives in `MQL4\Files\` and holds one row per H1 bar:

```
bar_time,volume
2026.11.26 00:00,12345
2026.11.26 01:00,9876
```

`bar_time` is `"yyyy.mm.dd hh:mi"`, the bar open time; `volume` is the futures volume for that bar. An optional `"time,volume"` header line is skipped on load.

**Full-coverage requirement.** The file is used only when it matches **every** bar in the scope window. Coverage is checked *first*, into a temporary array; the external volumes are assigned to the profile only when every bar matched. This ordering matters: assigning as bars match would mix external and tick volume in one profile when a later bar fails to match, and the code deliberately avoids that. When no feed is configured, or the file is missing, unparsable, or does not cover the window, the profile falls back to broker tick volume and says so in `sourceLabel` (e.g. `"Tick volume (external feed file did not cover the window)"`).

**The two sources are never mixed in one profile.** An external profile has `flowMode = FBPI_FLOW_TRUE_BIDASK`, `avail = FBPI_AVAIL_EXTERNAL`, and `sourceLabel` = the feed name. A tick-volume profile has `flowMode = FBPI_FLOW_ESTIMATED_TICK`, `avail = FBPI_AVAIL_CALCULATED`, and `sourceLabel = "Tick volume"` (plus the fallback note when applicable). There is no WebRequest/DLL feed in v1 (Architecture divergence D-3): the only external route is a file the user drops in `MQL4\Files\`.

## 7. Worked numeric example

A small example, with **6 bins instead of the default 24**, so every number can be checked by hand. The method is identical; only the bin count differs. Scope: low 1.0800, high 1.0860, so `binSize = (1.0860 − 1.0800) / 6 = 0.0010`. Four H1 bars:

| Bar | Low | High | Tick volume |
|---|---|---|---|
| A | 1.0805 | 1.0825 | 1200 |
| B | 1.0820 | 1.0840 | 1800 |
| C | 1.0835 | 1.0855 | 900 |
| D | 1.0810 | 1.0830 | 600 |
| **Total** | | | **4500** |

Bin edges: bin 0 [1.0800, 1.0810), bin 1 [1.0810, 1.0820), bin 2 [1.0820, 1.0830), bin 3 [1.0830, 1.0840), bin 4 [1.0840, 1.0850), bin 5 [1.0850, 1.0860).

Each bar's volume is split pro-rata to overlap width (uniform within the bar). Bar A spans 0.0020, overlapping bin 0 by 0.0005, bin 1 by 0.0010, bin 2 by 0.0005 → 300 / 600 / 300. Bar B spans 0.0020, overlapping bins 2, 3 equally → 900 / 900. Bar C spans 0.0020, overlapping bin 3 by 0.0005, bin 4 by 0.0010, bin 5 by 0.0005 → 225 / 450 / 225. Bar D spans 0.0020, overlapping bins 1, 2 equally → 300 / 300.

| Bin | Centre | Volume | Calculation |
|---|---|---|---|
| 0 | 1.0805 | 300 | A 300 |
| 1 | 1.0815 | 900 | A 600 + D 300 |
| 2 | 1.0825 | 1500 | A 300 + B 900 + D 300 |
| 3 | 1.0835 | 1125 | B 900 + C 225 |
| 4 | 1.0845 | 450 | C 450 |
| 5 | 1.0855 | 225 | C 225 |
| **Sum** | | **4500** | Exactly the total tick volume ✓ |

**POC**: greatest bin volume is bin 2 (1500) → POC = centre of bin 2 = **1.0825**. (No tie here; had bins 2 and 3 tied, the lower bin 2 would still win.)

**Nodes**: mean bin volume = 4500 / 6 = 750. High-volume threshold 150% × 750 = 1125 → bins 2 (1500) and 3 (1125, exactly at the threshold — inclusive, so it counts). Low-volume threshold 50% × 750 = 375 → bins 0 (300) and 5 (225).

**Value area, 70%**: target = 4500 × 70 / 100 = 3150. Start at the POC bin 2: inside = 1500.

```
inside 1500 < 3150:  up bin 3 (1125) vs down bin 1 (900) → add up,   inside = 2625
inside 2625 < 3150:  up bin 4 (450)  vs down bin 1 (900) → add down, inside = 3525 ≥ 3150 → stop
VAH = top edge of bin 3 = 1.0840
VAL = bottom edge of bin 1 = 1.0810
Included share = 3525 / 4500 = 78.3%  (overshoots 70% because whole bins are added)
```

**Price vs value**: Bid 1.0830 → inside [1.0810, 1.0840] → "Inside value". Bid 1.0845 → above VAH → "Above value". Bid 1.0805 → below VAL → "Below value".

**Acceptance example**: closes of the last 4 closed bars (chart timeframe) 1.0805 (outside, below VAL), then 1.0820, 1.0830, 1.0825 (all inside) → 3 consecutive inside after an outside bar → accepted. **Rejection example**: latest closed bar High 1.0850 (above VAH 1.0840), Close 1.0830 (inside) → rejection. **Migration example**: prior POC 1.0825, current POC 1.0845, bin size 0.0010 → move 0.0020 > 0.0010 → migrated. A move to 1.0835 (one bin) would not be migration.

## 8. What the profile does not do

- It does not use consolidated volume, order-book depth, or bid/ask volume. Those need an external feed (§6) or are unavailable (Layers 18–20).
- It does not smooth, weight, or age the volume. Every bar in the scope counts equally, including the forming bar, whose tick volume is still accumulating — so the profile's edges move intrabar and settle only when the bar closes.
- It does not identify support or resistance. POC, VAH, VAL, and the nodes are where volume *was*; the Liquidity module, not this module, decides whether price's interaction with them was a sweep, a breakout, or a rejection.
- It does not persist across restarts by itself: profiles are rebuilt from bars on each recalculation. The scoreboard (finalised forecasts) is the persistent record, not the profile.

## 9. Divergences and known limitations (recorded honestly)

1. **Day anchor is broker-midnight, not UTC** (§3.1). The daily and weekly scopes start at broker midnight when the broker offset is not zero, while MarketStructure's daily window starts at 00:00 UTC. Reconcile before treating Test 5 results as final.
2. **Acceptance count is a constant, not an input** (§5.4). Behaviour matches the documented default of 3; it is not user-configurable.
3. **Session scope depends on the Sessions module.** The session profile reads `g_fbpiSessions[]`; if Sessions has not computed a window yet (early in the day, or a weekend), the session profile is invalid rather than approximated.
4. **Weekly scope is capped at 512 bars.** `FBPI_VP_MAX_BARS` = 512 collected bars per scope. A week holds at most ~120 H1 bars, so the cap does not bind in practice — but it is a hard cap, and a scope longer than 512 bars would silently truncate to the oldest 512.
5. **Tick volume is a broker-specific proxy.** Profiles, value areas, and estimated flow derived from it are broker-relative (Architecture limitation L-3). The same symbol on another broker can give a different POC, and therefore a different value area.
6. **Live-terminal verification outstanding.** No profile in this document has been checked against a live terminal. Tests 5 and 6 remain CANNOT-VERIFY-WITHOUT-TERMINAL until run on the user's laptop after MetaEditor compile — in particular the bin-sum equality (§2.4) and the value-area 70% containment (§2.6) must be hand-checked on a real day's H1 tick volume.
