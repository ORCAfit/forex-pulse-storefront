# Forex Bigger Picture Intelligence System — Risk Management Guide

| Field | Value |
|---|---|
| Project ID | FBPI-MT4-001 |
| Product | Forex Bigger Picture Intelligence System v1.0 |
| Platform | MetaTrader 4 (MT4), MQL4 build 600+ |
| Date | 2026-11-27 |
| Companion documents | `User_Manual.md` (§9–§10, §14), `Technical_Architecture.md` §4.10–§4.11, `Risk_Management_Guide.md` (this document) |
| Spec | `FBPI-MT4-001-spec.md` §3 Layer 22–23, §15 Risk |

> **Verification status.** The calculations in this guide are taken from the source code (`FBPI_Risk.mqh`, `FBPI_Confirmation.mqh`, `FBPI_Main.mq4`). They have been statically audited only — never compiled, never run in a live MT4 terminal. The worked examples in §6 use the code's own formulas with the arithmetic shown step by step; the pip values in them are the values the formulas produce at the stated prices on a typical broker, and your broker's `MarketInfo` values are what the indicator will actually use. Live position sizes may differ from the examples if your broker's contract specs differ.

> **The risk plan is paper risk on paper capital.** The indicator plans with `InpPaperCapital` (default $5,000) and a risk percentage you configure. It does not read your broker account, your equity, or your open positions. Nothing in this guide is advice to trade a particular size with real money. If you use the plan's size for a live order, you are translating a paper calculation into a real decision yourself — the indicator does not do that, and this guide does not recommend it.

---

## 1. The risk plan in full

### Defaults

| Setting (input) | Default | Allowed range | What it means |
|---|---|---|---|
| `InpPaperCapital` | $5,000.00 | > 0 | The capital the plan is calculated on. Paper capital, not your account balance. |
| `InpRiskPct` | 0.5% | 0.1–5.0% | The fraction of capital risked on one trade. |
| `InpMaxDailyLossPct` | 2.0% | 0.5–10%, and ≥ `InpRiskPct` | The maximum loss for the whole trading day, as a % of capital. |
| `InpMinRR` | 2.0 (1:2) | 1.0–5.0 | The minimum planned reward-to-risk. A plan below this is rejected. |
| `InpPrefRR` | 3.0 (1:3) | ≥ `InpMinRR` | The *preferred* reward-to-risk. **Not enforced** — a plan at 1:2.4 passes even though it is below the 1:3 preference. The preference is a target you judge against, not a rule the code applies. |
| `InpAccountCurrency` | `"USD"` | — | The currency money values are displayed in. It is a label for the plan's arithmetic, which is done in the broker's tick-value currency. |
| `InpCommissionPerLot` | 0.0 | ≥ 0 | Commission per lot, in account currency. 0 = no commission charged (the default). Set it to your broker's actual per-lot commission if you want commission included in the plan. |
| `InpDailyLossSoFar` | 0.0 | ≥ 0 | **Manual input.** How much you have already lost today, in account currency. The indicator never reads your account. 0 means "not entered" — the dashboard shows the note "daily loss not entered". |
| `InpPlanEntry` / `InpPlanStop` / `InpPlanTarget` | 0.0 | All three set, or all three 0 | A manual plan (see §4). A partial plan (one or two of the three set) fails `OnInit()` validation. Stop and target must differ from the entry. |

At the defaults, the headline numbers are:

- **Risk per trade:** $5,000 × 0.5% = **$25.00**.
- **Maximum daily loss:** $5,000 × 2.0% = **$100.00** — i.e. four consecutive $25 losing trades at the default risk, and the day is done.
- **Minimum reward-to-risk:** 1:2 — a $25 risk needs at least $50 of planned profit.
- **Preferred reward-to-risk:** 1:3 or higher — $75+ of planned profit on a $25 risk.

### How to change them

Right-click the chart → **Indicators List** → **FBPI_Main** → **Edit** → **Inputs** tab → change the value → OK. The plan recalculates on the next recalculation pass. Changes are validated in `OnInit()` (for attach-time values) and in the module `Init()` functions; an out-of-range value prevents the attach and names the input in the Experts tab. Note the validation relationships: `InpMaxDailyLossPct` must be ≥ `InpRiskPct` (a daily limit smaller than one trade's risk is incoherent), and `InpPrefRR` must be ≥ `InpMinRR`.

**Changing the defaults changes the scoreboard's meaning.** The scoreboard records forecasts, not risk settings, so a risk change does not restart the scoreboard file — but a plan computed under 0.5% risk is not comparable to one computed under 2% risk. If you change the risk settings, note the date, so that later reviews of your trading journal are not comparing different regimes as if they were one.

---

## 2. How position size is computed — step by step

The plan is computed in `FBPI_Risk_Plan()` for either the identified setup (entry/stop/target from the Confirmation module) or a manual plan (see §4). The steps, in the code's order:

### Step 1 — Risk amount

```
riskAmount = InpPaperCapital × InpRiskPct / 100
```

At defaults: $5,000 × 0.5 / 100 = **$25.00**. This is the *planned* risk — the amount the rest of the calculation is sized against.

### Step 2 — Stop distance in pips

```
stopDistancePips = |entry − stop| / (point × pointsPerPip)
```

- `point` is the symbol's `MODE_POINT` (the smallest price increment, e.g. 0.00001 for a 5-digit EURUSD, 0.001 for a 3-digit USDJPY).
- `pointsPerPip` is symbol-aware: **10 points per pip for 3- and 5-digit symbols, 1 point per pip otherwise** (`FBPI_PointsPerPip()`). There is no universal pip value anywhere in the system — a "pip" on USDJPY (0.01) and a "pip" on EURUSD (0.0001) are different price distances, and the code converts each symbol correctly.
- If the stop equals the entry, or the stop is on the wrong side (stop above entry for a bullish setup), there is no valid plan — the setup is not identified in the first place.

### Step 3 — Pip value per 1.0 lot, from the broker

```
pipValue (per 1.0 lot) = value of one point × pointsPerPip
```

where the value of one point comes from `MarketInfo(symbol, MODE_TICKVALUE)` adjusted by `MODE_TICKSIZE` / `MODE_POINT`. In plain terms: the indicator asks **your broker** what one lot of this symbol is worth per pip, in the account currency. It never assumes a value.

- **If `MarketInfo` returns 0, the pip value is `DATA UNAVAILABLE` and the plan is rejected.** No assumed value is substituted. This can happen on symbols with no live quote or with incomplete contract specs — check the quote and the symbol's contract specification in MT4 (right-click the symbol in Market Watch → Specification).
- **Pip value moves with price for cross pairs.** For USDJPY with a USD account, the pip value per lot is `100,000 × 0.01 / USDJPY rate` — at 155.00 that is $6.45, at 140.00 it is $7.14. The indicator reads the live value each time it calculates, so the same stop distance gives a different size at different prices. The worked examples in §6 show the arithmetic at a stated price; do not treat the $6.45 as a constant.

### Step 4 — Raw size, then round DOWN to the lot step

```
rawSize = riskAmount / (stopDistancePips × pipValue)
positionSize = rawSize rounded DOWN to MODE_LOTSTEP, clamped to MODE_MINLOT … MODE_MAXLOT
```

- **Rounded down, never up.** Rounding up would risk more than `riskAmount`; the code always rounds down, so the actual risk is always ≤ the planned risk (see the examples: $24.00 and $24.19 of actual risk against $25.00 planned).
- **Lot step comes from the broker** (`MODE_LOTSTEP`, commonly 0.01). A raw size of 0.125 lots becomes 0.12 lots on a 0.01-step broker, and 0.125 lots on a 0.001-step broker. Your broker's step is part of the answer.
- **Clamped to the broker's minimum and maximum lot** (`MODE_MINLOT` … `MODE_MAXLOT`).
- **If rounding down goes below the broker minimum, the plan is rejected** (`violatesLotStep` = true). Example: raw size 0.008 lots on a broker with minimum 0.01 lots → the rounded size would be 0.00, which is not a trade — the plan is rejected rather than silently rounded up to the minimum. The correct response is a wider stop (fewer pips of risk per lot is not the issue — a *narrower* stop needs a *larger* size; a raw size below the minimum means the stop is so wide, or the risk amount so small, that even the minimum lot risks more than planned) or a larger risk amount — never to force the minimum lot through.

### Step 5 — Spread cost and commission

```
spreadCost = spread in pips × pipValue × positionSize
commission = InpCommissionPerLot × positionSize
```

- The spread is the symbol's current spread, read live from the broker at calculation time, in points, converted to pips. It is a **cost of the plan as displayed** — it is shown on the dashboard (`Spread cost: $1.44`) so you can see what the spread takes out of the trade before it starts. It is not added to the risk amount and it does not change the position size; it is information, not a sizing input. (Whether you think the spread *should* be added to the risk is a trading decision the code leaves to you — it shows you the number and stops there.)
- Commission is `InpCommissionPerLot` × size. At the default 0.0 it is $0.00. If your broker charges, say, $7 per lot round-turn, set `InpCommissionPerLot` = 7.0 and the plan will show the commission for the computed size.

### Step 6 — Potential profit and reward-to-risk

```
potentialProfit = |target − entry| in pips × pipValue × positionSize
rewardRisk = potentialProfit / riskAmount
```

**Read this carefully — it is the subtlest formula in the system.** The reward-to-risk divides the potential profit by the **planned risk amount** (`riskAmount`, $25.00 at defaults), **not** by the actual risk after rounding down ($24.00 / $24.19 in the examples). Because rounding down shrinks both the actual risk *and* the potential profit, while the denominator stays at $25.00, the computed R:R is slightly **lower** than the simple price-distance ratio (target distance ÷ stop distance). In the EURUSD example in §6, the price distances give 50 ÷ 20 = 2.50, but the computed R:R is 2.40. That is the code working as written: it measures the profit against the risk you *planned* to take, not the risk you ended up taking after the lot-step rounding. Two consequences:

1. A plan whose price distances are exactly 1:2.0 can still be **rejected** for violating the minimum R:R, because the rounding pulled the computed R:R below 2.0 (e.g. 40 pips target / 20 pips stop at 0.12 lots = $48 profit / $25 planned risk = 1.92 → rejected). If your plans keep getting rejected at exactly 1:2, this is why: the target needs to be far enough that the *rounded* size still clears the minimum.
2. The displayed R:R is conservative relative to the price ratio. That is a defensible bias for a risk tool — it understates the reward rather than overstating it — but you should know which number you are looking at.

If `rewardRisk` cannot be computed (no valid stop), it is `DATA UNAVAILABLE` and the plan is rejected.

### Step 7 — Violations, and what happens

Three violations carry named flags, and a fourth rejection reason is recorded in the same warning text (it has no flag of its own, but it still rejects the plan — the code returns "not valid" whenever any violation text exists). Any one of them makes `riskValid` = false, shows a `WARNING:` line on the dashboard, and drives the execution status to `REJECTED — RISK RULE VIOLATION` (which overrides every other status):

| Violation | Condition | Dashboard warning (exact wording from the code) |
|---|---|---|
| `violatesMinRR` | `rewardRisk < InpMinRR` (or R:R cannot be computed) | `WARNING: Reward:risk 1.92 is below minimum 2.0` |
| `violatesDailyLoss` | `InpDailyLossSoFar + riskAmount > maxDailyLoss` | `WARNING: Daily loss limit breached: loss so far 80.00 USD + this trade risk 25.00 exceeds max daily loss 100.00 - do NOT increase risk to recover losses` |
| `violatesLotStep` | Rounding the size down goes below the broker minimum lot | `WARNING: Position size rounds below broker minimum lot (0.01) for this stop distance - risk amount too small for this symbol/stop` |
| (no flag) Spread ≥ stop | Spread in pips is at least as large as the stop distance in pips | `WARNING: Spread (1.5 pips) is at least as large as the stop distance (1.0 pips)` |

The fourth row deserves attention because it is easy to miss: **if the spread is as large as (or larger than) the stop distance, the plan is rejected.** A 1-pip stop on a 1.5-pip spread is not a trade — the spread alone would consume the whole stop. The rejection is the code refusing to plan a trade whose costs exceed its risk. Other rejection reasons, also recorded as violation text with no flag: pip value unavailable (`Pip value unavailable (MarketInfo returned 0 for <symbol>) - plan rejected, no value assumed`), stop distance zero, missing entry/stop/target, or a stop/target on the wrong side for the direction.

Note the boundary conditions, because they matter when you are exactly at a limit:

- **Daily loss:** the check is strictly greater-than (`>`). If `InpDailyLossSoFar` + `riskAmount` is **exactly** equal to the maximum daily loss, the plan passes. $75 already lost + $25 planned risk = $100.00 = the $100 maximum → allowed. $75.01 + $25 → rejected.
- **Minimum R:R:** the check is strictly less-than (`<`). A computed R:R of exactly 2.00 against a minimum of 2.0 passes.
- **The daily-loss check uses the planned risk amount ($25), not the actual rounded risk ($24).** Same conservatism as the R:R formula: the limit is tested against the larger number.

A rejected plan is still a computed plan: the dashboard shows the size, the R:R, and the reason. Nothing is hidden, and nothing is auto-adjusted to make it pass. The indicator will not shrink the size, widen the target, or raise the risk % to force a pass — those are your decisions, made outside the indicator.

---

## 3. Spread and commission impact — what they do and do not do

Worked into the plan's display, but easy to misread, so stated plainly:

- **Spread cost is shown, not charged to the risk.** A 1.2-pip spread on a 0.12-lot EURUSD plan costs $1.44 (see §6). That $1.44 is roughly 6% of the $25 planned risk, and it comes out of the trade before price moves at all. On a 20-pip stop, the spread is 6% of the stop distance; on a 5-pip stop, the same 1.2-pip spread is 24% of the stop distance. Short stops are spread-sensitive — the dashboard shows you the number so you can see that, but the code does not widen the stop or shrink the size to compensate.
- **Commission is shown when you configure it.** At the default `InpCommissionPerLot` = 0.0, commission is $0.00 and the field is decorative. If your broker charges commission, enter it — otherwise the plan understates your cost. Note that the commission input is per lot in account currency; if your broker quotes commission per lot per side, enter the round-turn total (both sides), since the plan charges it once per lot of size.
- **Neither spread nor commission changes the position size.** The size is a function of risk amount, stop distance, and pip value only. If you want costs reflected in the size, you must do that adjustment yourself, outside the indicator.
- **Spread is live.** The spread used is the spread at the moment of calculation. Spreads widen around news and at session boundaries; a plan computed in quiet conditions will show a different spread cost five minutes later. Re-check the plan (it recalculates every new bar and every refresh interval) before acting on it.

---

## 4. The manual plan — planning without a setup

When no setup is identified (status `ANALYSIS INCOMPLETE`), you can still get a risk plan by entering your own entry, stop, and target:

| Input | Default | Rule |
|---|---|---|
| `InpPlanEntry` | 0.0 | Manual entry price |
| `InpPlanStop` | 0.0 | Manual stop-loss price |
| `InpPlanTarget` | 0.0 | Manual take-profit price |

- **All three must be set, or all three 0.** A partial plan fails `OnInit()` validation and the indicator will not attach. Stop and target must differ from the entry.
- **Direction is inferred from the stop side:** stop below entry = bullish; stop above entry = bearish. There is no separate direction input — the stop tells the code which way the trade goes.
- **The manual plan is used only when there is no setup.** If a setup is identified, the setup's entry/stop/target take precedence and the manual plan is ignored for that calculation. (The manual plan is the fallback, not an override.)
- **The same risk calculation applies:** same risk amount, same rounding-down, same pip value, same violations, same `REJECTED — RISK RULE VIOLATION` outcome. A manual plan that violates the minimum R:R is rejected exactly like a setup plan.
- **The manual plan has no confirmation score.** The confirmation score belongs to a setup; a manual plan shows its risk numbers with no score and no factor rows. Its execution status is driven by the risk plan alone (and by the absence of a setup — see the User Manual §10 for how the status machine treats a manual plan).
- **Use it for "what-if" planning:** enter the entry/stop/target you are considering, read the size and R:R off Section E, then decide. Clear the three inputs back to 0 when you are done, so a stale manual plan is not sitting in the inputs next week.

---

## 5. The daily loss limit — and what happens on breach

### The rule

```
maxDailyLoss = InpPaperCapital × InpMaxDailyLossPct / 100     (= $100.00 at defaults)
breach if:  InpDailyLossSoFar + riskAmount > maxDailyLoss
```

### How to use it

1. **At the start of each trading day, set `InpDailyLossSoFar` = 0.** The input does not reset itself — yesterday's value stays in force until you change it. Forgetting this step means yesterday's losses count against today, and plans will be rejected for a breach that did not happen today.
2. **After each losing trade, update `InpDailyLossSoFar`** to your total loss for the day so far (in account currency). The indicator does not know your results — it cannot read your account, your closed trades, or your open positions. If you do not update it, the limit cannot bind, and the dashboard will keep showing "daily loss not entered".
3. **When a plan is rejected for `violatesDailyLoss`, stop for the day.** That is what the limit is for. The correct responses are: no more trades today, or (only if the day's accounting was wrong) correct `InpDailyLossSoFar` to the true figure. The incorrect responses are: raising `InpMaxDailyLossPct`, lowering `InpRiskPct` to squeeze one more trade under the limit, or deleting the loss from the input. All three defeat the purpose of a daily limit.

### Worked breach example (defaults: $5,000 capital, 0.5% risk = $25, 2% daily max = $100)

| Situation | Calculation | Result |
|---|---|---|
| Start of day, no losses | $0 + $25 = $25 ≤ $100 | Plan allowed |
| After 2 losing trades ($50 lost) | $50 + $25 = $75 ≤ $100 | Plan allowed |
| After 3 losing trades ($75 lost) | $75 + $25 = $100 ≤ $100 | Plan allowed (exactly at the limit — the check is `>`, not `>=`) |
| After 3 losing trades + $5 of spread/commission slippage ($80 lost) | $80 + $25 = $105 > $100 | **Plan rejected** — `REJECTED — RISK RULE VIOLATION`, daily-loss breach |
| After 4 losing trades ($100 lost) | $100 + $25 = $125 > $100 | **Plan rejected** — day is done |

Note that the limit counts **losses you enter**, not the indicator's hypothetical trades. If you take trades the indicator never saw, they still count — enter them. If you enter a loss figure that includes spread and commission, the limit binds sooner, which is the honest way to count it.

### What the limit does not do

- It does not close your positions or stop you trading. It rejects the *plan* in the dashboard. You can still place an order by hand in MT4. The limit is a rule you enforce on yourself, with the indicator as the scorekeeper — not a lock on your account.
- It does not track winning days, partial profits, or break-even trades. Only the loss figure you enter matters.
- It does not carry across days. Each trading day starts at $0 (once you reset the input) with a fresh $100 allowance.

---

## 6. Worked numeric examples

Both examples use the defaults ($5,000 capital, 0.5% risk, 2% daily max, min R:R 1:2, preferred 1:3, commission $0) and a broker lot step of 0.01 with minimum lot 0.01. Every step follows the formulas in §2. Pip values are the values the code's formula produces at the stated prices — the indicator reads them live from `MarketInfo`, so if your broker's values differ, your size will differ.

### Example A — EURUSD

**Setup:** bullish. Entry 1.0850, stop 1.0830, target 1.0900. EURUSD is a 5-digit symbol, so 1 pip = 10 points = 0.0001. Pip value per 1.0 lot is $10.00 (standard for EURUSD with a USD account; the indicator reads this from the broker, it is not hardcoded).

| Step | Calculation | Result |
|---|---|---|
| 1. Risk amount | $5,000 × 0.5 / 100 | **$25.00** |
| 2. Stop distance | \|1.0850 − 1.0830\| = 0.0020 = 20 pips | **20.0 pips** |
| 3. Pip value (1.0 lot) | From broker (`MODE_TICKVALUE` adjusted) | **$10.00 per pip** |
| 4. Raw size | $25.00 / (20 × $10.00) = 25 / 200 | **0.125 lots** |
| 5. Round DOWN to lot step 0.01 | 0.125 → 0.12 | **0.12 lots** |
| 6. Actual risk | 20 pips × $10.00 × 0.12 | **$24.00** (0.48% of capital — under the $25 planned, because of the rounding) |
| 7. Spread cost (spread 1.2 pips) | 1.2 × $10.00 × 0.12 | **$1.44** |
| 8. Commission | $0.00 × 0.12 | **$0.00** |
| 9. Potential profit | 50 pips (1.0900 − 1.0850) × $10.00 × 0.12 | **$60.00** |
| 10. Reward-to-risk | $60.00 / $25.00 (planned risk) | **2.40 → shown as 1:2.40** |
| 11. Violations? | 2.40 ≥ 2.0 min R:R ✓; $0 + $25 ≤ $100 daily ✓; 0.12 ≥ 0.01 min lot ✓ | **No violation — plan valid** |
| 12. Preferred R:R? | 2.40 < 3.0 preferred | Below preferred, but **not** a violation — the preference is not enforced |

**Dashboard lines for this plan:** `Size 0.12 lots | Risk 0.50% ($25.00 USD) | R:R 1:2.40` and `Stop distance: 20.0 pips | Spread cost: $1.44 USD | Commission: $0.00 USD`.

**Two things to notice:**

- The price-distance ratio is 50 ÷ 20 = **2.50**, but the displayed R:R is **2.40** — because the profit ($60) is divided by the planned $25, not by the actual $24 risk (§2 Step 6). If you check the indicator's R:R against the chart distances and they differ by a little, this rounding effect is the reason.
- **If the target had been 1.0890 (40 pips) instead of 1.0900:** potential profit would be 40 × $10 × 0.12 = $48.00, R:R = 48 / 25 = **1.92 < 2.0 → the plan would be REJECTED** for violating the minimum R:R — even though the price distances are exactly 1:2.0. That is the rounding effect again, and it is the most likely reason a "perfectly good 1:2" plan gets rejected. The fix is a target far enough that the rounded size still clears the minimum — not a complaint that the indicator is wrong.

### Example B — USDJPY

**Setup:** bullish. Entry 155.00, stop 154.75, target 155.60. USDJPY is a 3-digit symbol, so 1 pip = 10 points = 0.01. Pip value per 1.0 lot at 155.00 is **$6.45** (100,000 × 0.01 ÷ 155.00 = 6.4516…; the indicator reads this live from the broker, so it changes as the rate moves — at 140.00 it would be $7.14).

| Step | Calculation | Result |
|---|---|---|
| 1. Risk amount | $5,000 × 0.5 / 100 | **$25.00** |
| 2. Stop distance | \|155.00 − 154.75\| = 0.25 = 25 pips | **25.0 pips** |
| 3. Pip value (1.0 lot) | 100,000 × 0.01 / 155.00 | **$6.45 per pip** |
| 4. Raw size | $25.00 / (25 × $6.4516) = 25 / 161.29 | **0.155 lots** |
| 5. Round DOWN to lot step 0.01 | 0.155 → 0.15 | **0.15 lots** |
| 6. Actual risk | 25 pips × $6.4516 × 0.15 | **$24.19** |
| 7. Spread cost (spread 1.5 pips) | 1.5 × $6.4516 × 0.15 | **$1.45** |
| 8. Commission | $0.00 × 0.15 | **$0.00** |
| 9. Potential profit | 60 pips (155.60 − 155.00) × $6.4516 × 0.15 | **$58.06** |
| 10. Reward-to-risk | $58.06 / $25.00 (planned risk) | **2.32 → shown as 1:2.32** |
| 11. Violations? | 2.32 ≥ 2.0 ✓; $0 + $25 ≤ $100 ✓; 0.15 ≥ 0.01 ✓ | **No violation — plan valid** |
| 12. Preferred R:R? | 2.32 < 3.0 | Below preferred, not a violation |

**Two things to notice:**

- **The pip value is not $10.** A trader who sizes USDJPY with the EURUSD $10 pip value would compute 25 / (25 × 10) = 0.10 lots and risk only $16.13 — under-risking by a third. A trader who assumes $10 and trades 0.15 lots on a pair whose pip value is $10 would risk $37.50 — 50% over plan. The symbol-aware pip value is not a refinement; on JPY pairs it is the difference between the plan and a different trade. This is why the code never assumes a universal pip value.
- **The same rounding effect as Example A:** the price-distance ratio is 60 ÷ 25 = **2.40**, but the displayed R:R is **2.32**. And if the target had been 155.50 (50 pips), the profit would be 50 × $6.4516 × 0.15 = $48.39, R:R = 48.39 / 25 = **1.94 < 2.0 → rejected**, even though 50 ÷ 25 is exactly 1:2. The target must clear the minimum *after* rounding, not just on the chart.

### What changes if you change the inputs (quick reference)

| Change | Effect on the examples |
|---|---|
| `InpRiskPct` 0.5% → 1.0% | Risk amount $25 → $50. EURUSD raw size 0.25 lots → 0.25 lots (no rounding loss); USDJPY raw 0.31 lots → 0.31 lots. Actual risk doubles; daily allowance ($100) is now two trades, not four. |
| `InpPaperCapital` $5,000 → $10,000 | Risk amount $25 → $50; sizes double at the same stops. The daily max becomes $200. |
| Lot step 0.01 → 0.001 | EURUSD 0.125 stays 0.125 (actual risk $25.00, R:R 2.50); USDJPY 0.155 stays 0.155 (actual risk $25.00, R:R 2.40). Finer steps remove the rounding loss. |
| `InpMinRR` 2.0 → 3.0 | Both examples are **rejected** (2.40 and 2.32 < 3.0). Also note the 2R fallback target (see User Manual §10): a setup whose target is the automatic 2R projection gives R:R 2.0 by construction and can never pass a 3.0 minimum — only a level-derived target can. |
| `InpCommissionPerLot` 0 → $7.00 | EURUSD commission $0.84 (7 × 0.12); USDJPY $1.05 (7 × 0.15). Shown in the plan; size unchanged. |

---

## 7. The six execution statuses — what each one requires of you

(See also User Manual §10, which states the state machine in full. This section is the risk-side reading of the same six states.)

| Status | Risk-side meaning | Your action |
|---|---|---|
| `ANALYSIS INCOMPLETE` | No setup, so no plan. | Nothing to size. If you want a plan anyway, enter a manual plan (§4). |
| `WAITING FOR CONFIRMATION` | A setup exists but the score is below `InpMinConfScore`. The risk plan may already be computed and valid — the status is about confirmation, not risk. | Do not let a valid risk plan talk you into a weak setup. The score is the gate here. |
| `SETUP IDENTIFIED` | Score ≥ minimum, but no current risk plan has been computed for this setup yet. | Transient in normal running. If it persists, the risk calculation is failing — check the Experts tab. |
| `RISK VALIDATED` | The plan is valid, but at least one confirmation factor had missing data. | The numbers pass, but the analysis is incomplete. Decide whether the missing factor matters. A setup whose score rests on missing factors is `RISK VALIDATED` at best — never `READY`. |
| `READY FOR HUMAN REVIEW` | Plan valid, score ≥ minimum, **all six factors had data**. | Decide now, outside the indicator. Re-check the entry (it is a live market price and has moved since identification), the stop, the target, the size, and the rationale — then place the order yourself, or decline. |
| `REJECTED — RISK RULE VIOLATION` | A rule is violated (min R:R, daily loss, lot step, spread ≥ stop distance, or pip value unavailable). Overrides every other state, including a high confirmation score. | Do not trade this plan. The score does not rescue a violating plan — a 95-point setup with a 1:1.5 R:R is still rejected, and correctly so. |

**A note on `READY FOR HUMAN REVIEW`:** the word "ready" describes the *analysis*, not the trade. It means the checklist is complete and the numbers pass. It does not mean the trade will win, that the entry price is still available, or that you should take it. The final decision — including whether the market still looks the way it did when the setup was identified — is yours and happens outside the indicator.

---

## 8. What the indicator will NEVER do

Stated as a list, so there is no ambiguity:

- **Never place, modify, or close an order.** No order function exists in the code. There is nothing to enable, no "auto-trading" switch, and no setting that turns it on.
- **Never suggest increasing risk to recover losses.** There is no martingale, no anti-martingale, no "double up after a loss", and no "revenge-risk" suggestion anywhere in the code or in this guide. A daily-loss breach rejects the plan; the only compliant response is to stop or to reduce risk.
- **Never round a position size up.** Rounding is always down to the lot step. If rounding down breaks the plan (below the minimum lot), the plan is rejected — it is never rounded up to the minimum to force it through.
- **Never assume a pip value.** Every pip value comes from the broker's contract specs. If the broker returns 0, the plan is rejected rather than computed on an assumption.
- **Never use a universal lot size.** Size is computed per symbol, per stop distance, per broker lot step.
- **Never hide a violation.** A violating plan is displayed with its reason in the dashboard warning line, and the status is `REJECTED`. There is no "close enough" tolerance on the minimum R:R or the daily limit (beyond the exact-equality boundaries in §2 Step 7).
- **Never read your account.** Capital, daily loss, and commission are inputs you type. The indicator cannot see your balance, your equity, your margin, or your open trades, and it never pretends to.
- **Never recommend a trade.** The strongest statement the indicator makes is `READY FOR HUMAN REVIEW` — a statement that the checklist is complete, not that the trade is good.

---

## 9. Paper-trading discipline notes

This indicator was specified for a **$5,000 paper capital** baseline, and the discipline below is written for paper trading first. The same rules apply live — but paper is where they should be learned, because the cost of learning them there is zero.

1. **Trade the plan, not the P&L.** Before you enter a trade, write down the entry, stop, target, size, and R:R from Section E. After the trade, compare what happened with what the plan said. If you overrode the size, note why. A journal of overrides is how you find out whether your judgement adds value or just adds risk.
2. **One risk unit per trade, always.** At the defaults, one risk unit is $25 (0.5%). Do not trade 2 units because the setup "looks strong" — the confirmation score is not a position-sizing input, and the code does not scale size with the score. A 95-point setup and a 55-point setup get the same $25 of risk. If you want to scale with conviction, that is a strategy decision to design, backtest, and document — not something to improvise per trade.
3. **Respect the daily limit as a hard stop.** Four $25 losses = $100 = the day is over. The limit exists because losing days compound: the trader who stops at −2% can trade tomorrow; the trader who "takes one more to get it back" is the one who turns −2% into −6%. The indicator enforces the limit on the plan; you enforce it on yourself.
4. **Reset `InpDailyLossSoFar` every morning.** This is the single most-forgotten step in the system (§5). Put it on the same checklist as entering the central-bank rates.
5. **Do not judge the risk plan by one trade.** The plan's job is to make the *distribution* of outcomes survivable: bounded losses, defined targets, no single trade able to damage the account. A single winning trade does not validate the plan, and a single losing trade does not invalidate it. Judge it over 20+ trades: are losses clustering near $25? Are targets being reached at the planned R:R? Are rejections catching the trades you would have regretted?
6. **Reconcile the plan with the broker's reality.** Before placing an order from a plan, check in MT4: the symbol's minimum lot and lot step (Market Watch → Specification), the current spread, and whether the stop price is a valid distance from the current price for your broker (some brokers enforce a minimum stop distance). The indicator reads the lot step and spread from the broker, but it does not check your broker's freeze level or stop-distance rules — a plan can be valid in the indicator and unplaceable at the broker.
7. **Keep the paper capital honest.** If your paper capital is $5,000 but your real account is $500, the plan's sizes are not your sizes — scale the capital input to the account you actually trade, or keep the paper account as a separate exercise and do not copy its lot sizes across. The indicator cannot know which account you mean; `InpPaperCapital` is the only capital it has.
8. **A rejected plan is information, not an insult.** Most rejections will be minimum-R:R rejections on rounded-down sizes (§6). They are telling you the target is not far enough *for the size you can actually trade*. Widening the target on the chart to force a pass is not a fix unless the chart genuinely supports the wider target — a target moved to satisfy arithmetic is a target invented to satisfy arithmetic.

---

## 10. Quick reference — risk inputs and formulas

| Input | Default | Formula / rule it feeds |
|---|---|---|
| `InpPaperCapital` | 5000.0 | `riskAmount = capital × riskPct / 100`; `maxDailyLoss = capital × maxDailyLossPct / 100` |
| `InpRiskPct` | 0.5 | Same as above; allowed 0.1–5.0 |
| `InpMaxDailyLossPct` | 2.0 | Same as above; allowed 0.5–10, ≥ `InpRiskPct` |
| `InpMinRR` | 2.0 | Reject if `rewardRisk < InpMinRR`; allowed 1.0–5.0 |
| `InpPrefRR` | 3.0 | Preferred only — **not enforced**; must be ≥ `InpMinRR` |
| `InpAccountCurrency` | `"USD"` | Display currency |
| `InpCommissionPerLot` | 0.0 | `commission = commissionPerLot × positionSize` |
| `InpDailyLossSoFar` | 0.0 | Reject if `dailyLossSoFar + riskAmount > maxDailyLoss`; **manual — reset every morning** |
| `InpPlanEntry` / `InpPlanStop` / `InpPlanTarget` | 0.0 | Manual plan; all three or none; direction inferred from stop side |
| `InpSweepTolerancePts` | 0 | Offsets the setup stop beyond its protective level (points) |

**Formulas (all from `FBPI_Risk.mqh`):**

```
riskAmount        = capital × riskPct / 100
stopDistancePips  = |entry − stop| / (point × pointsPerPip)      [pointsPerPip: 10 for 3/5-digit symbols, else 1]
pipValue (1 lot)  = point value from MarketInfo × pointsPerPip   [DATA UNAVAILABLE if MarketInfo returns 0]
positionSize      = riskAmount / (stopDistancePips × pipValue), rounded DOWN to MODE_LOTSTEP,
                    clamped to MODE_MINLOT … MODE_MAXLOT        [below minimum → plan rejected]
spreadCost        = spread (pips) × pipValue × positionSize
commission        = InpCommissionPerLot × positionSize
potentialProfit   = |target − entry| (pips) × pipValue × positionSize
rewardRisk        = potentialProfit / riskAmount                 [planned risk, NOT actual rounded risk]
maxDailyLoss      = capital × maxDailyLossPct / 100
```

*End of Risk Management Guide — FBPI-MT4-001 v1.0.*
