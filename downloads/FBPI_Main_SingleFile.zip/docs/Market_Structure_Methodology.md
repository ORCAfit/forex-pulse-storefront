# Market Structure Methodology — FBPI-MT4-001

| Field | Value |
|---|---|
| Project | Forex Bigger Picture Intelligence System, FBPI-MT4-001 |
| Spec | `FBPI-MT4-001-spec.md` v1.0, Layers 8–11, §9 (source of truth) |
| Design authority | `docs/Technical_Architecture.md` §4.1, §4.4 |
| Code | `include/FBPI_MarketStructure.mqh` (Phase 2), `include/FBPI_Common.mqh` |
| Date | 2026-11-27 |
| Status | **Live-terminal verification outstanding.** Every rule below is taken from the code as written. Tests 1 and 4 (spec §17) are CANNOT-VERIFY-WITHOUT-TERMINAL until the indicator is compiled in MetaEditor and run on the user's laptop. Nothing in this document is a claim that the terminal agrees. |

This document states exactly how quarterly, monthly, weekly, and daily structure is calculated. Where the code differs from the spec or the Architecture document, the difference is listed in §8 — it is never silently resolved in favour of the code.

## 1. What this module owns

`FBPI_MarketStructure_Calculate()` fills the 15 level kinds it owns in `g_fbpiLevels[]` — QH, QL, MH, ML, PMH, PML, WH, WL, PWH, PWL, PDH, PDL, PDC, PDO, DO — and the 9-row multi-timeframe table `g_fbpiMTF[]`. It never touches the other level kinds (sessions, opening range, profile) and never touches a level's `TouchStats`: probabilities belong to the Liquidity module, and wiping them here would erase values Liquidity computed. Period detail (range, position, ADR, distances) lives in module-private state (`s_msQuarter`, `s_msMonth`, `s_msWeek`, `s_msDay`, struct `FBPI_MS_PeriodState`) and is exposed through the public getters `FBPI_MarketStructure_Quarterly()`, `FBPI_MarketStructure_Monthly()`, `FBPI_MarketStructure_Weekly()`, `FBPI_MarketStructure_Daily()`, plus `FBPI_MarketStructure_ADRSampleDays()`.

A level with no bars in its source window is left `valid == false` with price `FBPI_INVALID_DOUBLE` (−1.0). It is never given an invented price. A structure with fewer than 3 completed periods is `FBPI_STRUCT_NONE`. An ADR with no completed day is `FBPI_INVALID_DOUBLE`.

## 2. Reference frame: UTC epoch arithmetic

UTC is the reference frame; broker time is only a lookup shift. Every window is built in UTC, then shifted to broker time for the H1 bar scan.

- **Calendar maths** uses integer days-from-civil arithmetic on UTC epoch seconds (Hinnant's algorithm: `FBPI_MS_DaysFromCivil()` / `FBPI_MS_CivilFromDays()`). `StructToTime` / `TimeToStruct` are never used: they interpret components in broker/server time and would silently shift every window.
- **Broker offset** is derived each calculation from the live clocks, `TimeCurrent() − TimeGMT()`, rounded to the nearest 15 minutes, so half-hour offsets (+5.5) and quarter-hour offsets survive. The fallback is the configured `InpBrokerGMTOffset` (double, −12…+14, default 0.0) when either clock is unavailable. The offset is DST-aware by construction because it is the offset actually in force now. The module exposes it via `FBPI_MarketStructure_BrokerOffsetMinutes()`; it does not write `g_fbpiBrokerOffsetMin` (that global is owned by the Sessions/Main side).
- **UTC midnight** of a day is `utc − utc % 86400`. Day of week comes from days since 1970-01-01 (a Thursday): `(days + 4) % 7`, 0 = Sunday.

### 2.1 The trading day

The trading day is the half-open window **[day start, cutoff) in UTC**:

- Day start: `InpDayStartUTC`, a `"HH:MM"` string, default `"00:00"`.
- Cutoff: `InpCutoffHourUTC`, default **21** (21:00 UTC).
- At defaults the trading day is **[00:00, 21:00) UTC**, 21 hours long. The day length in seconds is `(cutoffHour × 60 − dayStartMin) × 60`; if that is ≤ 0 it wraps past midnight by adding 86,400 s (`FBPI_MS_DayParams()`).

The **21:00–24:00 UTC stretch is not part of the trading day**. It is the overnight window (Liquidity's ONH/ONL, [21:00 UTC previous day, 07:00 UTC current day)). PDH/PDL/PDC/PDO are scanned over [00:00, 21:00) UTC only, and the same window is used by the probability engine, so Liquidity and this module agree on what a "day" is — with one exception noted in §8.3.

### 2.2 Week, month, quarter

| Period | Window (UTC) |
|---|---|
| Week | Monday 00:00 UTC (+ day-start minutes) to Sunday 21:00 UTC cutoff. Week start = Monday midnight + `dayStartMin`; week end = week start + 6 days + day length. |
| Month | Calendar month: 1st of the month 00:00 UTC to 1st of the next month 00:00 UTC. |
| Quarter | Calendar quarter: 1st of the quarter's first month (`qm = ((m − 1) / 3) × 3 + 1`) 00:00 UTC to 1st of the next quarter's first month. |

## 3. The H1 aggregation primitive

All structure is aggregated from **H1 bars** (`FBPI_MarketStructure_ScanHighLow()`), the same primitive the Architecture document specifies in §4.1:

- Bars whose **open time lies in [start, end)** (broker datetimes) are scanned, via `iBarShift()`.
- **High / low / open** come from every bar in the window, *including the still-forming bar*, whose extremes are the running extremes — provisional, per Architecture §1.1.2.
- **Close is the last CLOSED bar's close**, or `FBPI_INVALID_DOUBLE` when the window holds only the forming bar.
- The function returns `false` when no H1 bar exists in the window (or the arguments are bad); the caller leaves the level invalid rather than inventing a price.

`FBPI_MS_ScanUTCWindow()` shifts a UTC window to broker time (UTC + offset minutes) and calls the primitive. `FBPI_MarketStructure_PeriodRange()` does the equivalent for one completed (or current) period on a native timeframe: `periodsAgo` 0 is the forming period, 1 is the last completed period, and so on.

### 3.1 Previous trading day

The previous trading day is the most recent UTC day before today whose [00:00, 21:00) window contains H1 bars (`FBPI_MS_FindNthPrevTradingDay()`). Weekends and broker holidays are skipped, searching up to **10 calendar days** back. On a Monday that is Friday, never Sunday. The same search, with `n = 2` and `n = 3`, supplies the second and third previous trading days used for daily structure classification.

## 4. Layer 8 — Quarterly structure

`FBPI_MS_CalcQuarterly()` scans the current quarter and the two previous quarters.

- **QH / QL**: high/low of H1 bars in the current quarter window; open = first bar's open; close = last closed bar's close.
- **Range** = high − low; **position %** = (Bid − low) / (high − low) × 100.
- **Direction**: current quarter's last closed close vs prior quarter's close (`FBPI_MS_DirectionFromCloses()` — bullish if newer > older, bearish if newer < older, neutral if equal, `FBPI_DIR_NONE` if either is invalid or ≤ 0).
- **Structure**: classified from the **[Q−2, Q−1, current]** close/high/low sequence (see §6). This is the documented exception to the completed-periods-only rule: the spec frames quarterly trend as current vs prior quarter, so the current (still open) quarter is included in the sequence.
- **Range position**: `FBPI_MarketStructure_RangePosition()` (§7).
- Returns `false` only when the current quarter has no H1 bar at all.

## 5. Layer 9 — Monthly structure

`FBPI_MS_CalcMonthly()` scans the current month and the three previous months.

- **MH / ML**: current month high/low; **PMH / PML**: previous month high/low (final, `isFinal = true`).
- **Direction**: current month's last closed close vs prior month's close.
- **Structure**: classified from the last three **COMPLETED** months [M−3, M−2, M−1] only, so a breakout counts only on a completed monthly close. Fewer than 3 completed monthly closes → `FBPI_STRUCT_NONE` ("Insufficient data").
- Returns `false` only when the current month has no bar.

## 6. Layer 10 — Weekly context

`FBPI_MS_CalcWeekly()` scans the current week and the three previous weeks.

- **WH / WL**: current week high/low; **PWH / PWL**: previous week high/low (final).
- **Direction**: current week's last closed close vs prior week's close.
- **Structure**: classified from the last three **COMPLETED** weeks [W−3, W−2, W−1].
- **Expansion / contraction vs average**: the mean range of the last `InpWeeklyLookback` (default **12**, clamped 2…52) completed weeks is computed (`avgRange`); `rangeVsAvgPct` = current range / avgRange × 100. The average is reported only when at least **3** completed weeks were found; otherwise `avgRange` is `FBPI_INVALID_DOUBLE`.
- Returns `false` only when the current week has no bar at all.

## 7. Layer 11 — Daily context

`FBPI_MS_CalcDaily()` is the most-used layer. It succeeds when the previous day or today has bars, and returns `false` only when neither does.

- **PDH / PDL / PDC / PDO**: high, low, close, open of the previous completed trading day (final). Touch directions: PDH up, PDL down, PDC and PDO neutral (see Probability Methodology — neutral means the bar's range must *contain* the level).
- **DO**: current day open — the open of the first H1 bar in today's [00:00, 21:00) window (neutral direction, not final).
- **Current day high / low**: extremes of today's window so far.
- **Direction**: today's last closed close vs PDC first; if today has no closed bar yet, D−1 close vs D−2 close.
- **Structure**: classified from the last three **COMPLETED** trading days [D−3, D−2, D−1].
- **Distance to PDH / PDL**: (Bid − level) / point / points-per-pip, in pips. Positive means Bid is above the level. Points-per-pip is symbol-aware: 10 points on 3/5-digit symbols, 1 point on 2/4-digit symbols (`FBPI_PointsPerPip()`). Never a universal pip value.

### 7.1 ADR — Average Daily Range

`FBPI_MarketStructure_ADR(symbol, periodDays)`:

```
ADR = mean daily range over InpADRPeriod (default 14) completed trading days
```

- Each completed day is one [day start, cutoff) UTC window. The scan walks back from **yesterday** (today is not complete) and skips days with no bars (weekends, holidays). It scans at most `need + (need / 5) × 3 + 14` calendar days, so a 14-day ADR scans at most 14 + 6 + 14 = 34 calendar days back.
- `periodDays ≤ 0` falls back to `InpADRPeriod`; the value is clamped to 1…500.
- **Sample-day reporting.** The ADR is the mean of the days that actually exist. The number of days averaged is kept in `s_msAdrSampleDays` and exposed by `FBPI_MarketStructure_ADRSampleDays()`. If only 9 completed days exist in history, ADR is the mean of those 9 and `adrDays` is 9 — the caller can see how many that was. It is never an invented value. ADR with no completed day is `FBPI_INVALID_DOUBLE`.
- **Current range as % of ADR** = today's range so far / ADR × 100 (`rangePctADR`).

## 8. Structure classification rules

Two classifiers exist. Both take arrays **oldest first** and return an `ENUM_FBPI_STRUCTURE`.

### 8.1 Close-sequence classifier — `FBPI_MarketStructure_Classify(closes, count)`

Applied to the last 3 closes (the newest is `closes[count−1]`):

1. Fewer than 3 closes, or any invalid (≤ 0 or `FBPI_INVALID_DOUBLE`) close → `FBPI_STRUCT_NONE`.
2. Last 3 closes **strictly rising** (`c2 > c1 > c0`) → `FBPI_STRUCT_HH_HL` (bullish).
3. Last 3 closes **strictly falling** (`c2 < c1 < c0`) → `FBPI_STRUCT_LL_LH` (bearish).
4. Otherwise, newest close **above every earlier close** → `FBPI_STRUCT_BREAKOUT_UP`.
5. Newest close **below every earlier close** → `FBPI_STRUCT_BREAKOUT_DOWN`.
6. Otherwise → `FBPI_STRUCT_CONSOLIDATION`.

Note step 4/5 compare the newest close against *all* earlier closes in the array, not just the previous period's extreme. Equal closes are not "strictly" rising or falling, so a flat sequence falls through to steps 4–6.

### 8.2 OHLC classifier — `FBPI_MS_ClassifyOHLC(highs, lows, closes, count)`

Used whenever true highs and lows are available (monthly, weekly, daily, quarterly, MTF). It tests the true pattern first:

1. Fewer than 3 periods, or any invalid high/low/close → `FBPI_STRUCT_NONE`.
2. **HH/HL**: highs *and* lows both strictly rising over the last 3 periods (`h2 > h1 > h0` and `l2 > l1 > l0`) → `FBPI_STRUCT_HH_HL`.
3. **LL/LH**: lows *and* highs both strictly falling (`l2 < l1 < l0` and `h2 < h1 < h0`) → `FBPI_STRUCT_LL_LH`.
4. Newest close **above the prior period's high** (`closes[2] > highs[1]`) → `FBPI_STRUCT_BREAKOUT_UP`.
5. Newest close **below the prior period's low** (`closes[2] < lows[1]`) → `FBPI_STRUCT_BREAKOUT_DOWN`.
6. Otherwise, falls back to the close-sequence classifier (§8.1).

The distinction matters: a sequence can have rising closes while its highs are falling (lower highs with higher closes). The OHLC classifier calls that neither HH/HL nor LL/LH, and only a close beyond the prior period's extreme earns the breakout label.

### 8.3 Completed periods only — except quarterly trend

Monthly, weekly, and daily structure are classified on the last three **completed** periods only. The current (still open) period supplies direction (current close vs prior close) but never the structure class. A breakout is therefore counted only on a completed period's close, as Architecture §4.4 requires ("confirmed only on the monthly close"). **Quarterly trend is the exception**: its 3-period sequence is [Q−2, Q−1, current], because the spec frames it as current vs prior quarter.

## 9. Range-position bands

`FBPI_MarketStructure_RangePosition(price, hi, lo, prevRange)` — and its position-only half, `FBPI_MS_PositionOnly(price, hi, lo)`:

| Test (in order) | Result |
|---|---|
| Invalid price, or `hi ≤ lo` | `FBPI_RANGE_UNKNOWN` |
| Current range > **110%** of previous range | `FBPI_RANGE_EXPANDING` |
| Current range < **90%** of previous range | `FBPI_RANGE_CONTRACTING` |
| Position `(price − lo) / (hi − lo)` ≥ **66.7%** | `FBPI_RANGE_UPPER` |
| Position ≤ **33.3%** | `FBPI_RANGE_LOWER` |
| Otherwise | `FBPI_RANGE_MID` |

Three points are easy to get wrong, so they are stated explicitly:

1. **Expansion/contraction is tested FIRST.** If the range is expanding, the function returns `EXPANDING` — not `UPPER`, even if price sits at 95% of the range. The position-only value is kept separately in the period state (`positionOnly`) because the dashboard needs both the position and the range regime.
2. `prevRange ≤ 0` disables the expansion test entirely (position only). This is the case when there is no previous period.
3. The bands are 66.7% / 33.3% (two-thirds / one-third), and the expansion thresholds are 110% / 90% — all as coded, not rounded to 2/3 in words only.

## 10. Multi-timeframe alignment table (spec §9)

`FBPI_MS_FillMTF()` fills one `MTFRow` per timeframe, in this fixed order:

| Row | Timeframe | Direction from | Structure from |
|---|---|---|---|
| 1 | M1 | Last 2 completed closes | Last 3 completed periods' OHLC |
| 2 | M5 | Last 2 completed closes | Last 3 completed periods' OHLC |
| 3 | M15 | Last 2 completed closes | Last 3 completed periods' OHLC |
| 4 | M30 | Last 2 completed closes | Last 3 completed periods' OHLC |
| 5 | H1 | Last 2 completed closes | Last 3 completed periods' OHLC |
| 6 | H4 | Last 2 completed closes | Last 3 completed periods' OHLC |
| 7 | D1 | Last 2 completed closes | Last 3 completed periods' OHLC |
| 8 | W1 | Last 2 completed closes | Last 3 completed periods' OHLC |
| 9 | MN1 | Last 2 completed closes | Last 3 completed periods' OHLC |

- **Direction** is from the last two **completed** closes on that timeframe (bar shifts 1 and 2 — the forming bar, shift 0, is never used): newer close above older → Bullish, below → Bearish, equal → Neutral.
- **Structure** is from the last three completed periods' highs/lows/closes (shifts 3, 2, 1, oldest first) through the OHLC classifier (§8.2). A row whose closes are usable but whose OHLC sequence is incomplete keeps its direction with structure `FBPI_STRUCT_NONE` ("Insufficient data").
- **`valid == false` when fewer than 20 bars exist on that timeframe.** The row then shows "—", not a guessed direction. Nothing in the table is hardcoded; every row is computed from real bars.

## 11. Worked example — EURUSD H1 bars (illustrative)

The numbers below are an **illustrative worked example**, constructed to make the arithmetic checkable — they are not a claim about EURUSD on any real date. All arithmetic is shown so it can be re-performed by hand against the code.

### 11.1 Daily layer: three completed days

| Day | High | Low | Close | Range | Range (pips) |
|---|---|---|---|---|---|
| D−3 | 1.0820 | 1.0750 | 1.0805 | 0.0070 | 70.0 |
| D−2 | 1.0845 | 1.0780 | 1.0830 | 0.0065 | 65.0 |
| D−1 | 1.0870 | 1.0810 | 1.0860 | 0.0060 | 60.0 |

(Pips use 0.0001 per pip for EURUSD, a 5-digit symbol: 10 points per pip.)

**ADR (3 sample days, for illustration).** Production ADR averages `InpADRPeriod` = 14 completed days and reports the count via `ADRSampleDays()`; this example uses 3 days so the arithmetic stays visible:

```
ADR = (0.0070 + 0.0065 + 0.0060) / 3 = 0.0195 / 3 = 0.0065 = 65.0 pips, adrDays = 3
```

**PDH / PDL / PDC / PDO** (from D−1): PDH = 1.0870, PDL = 1.0810, PDC = 1.0860, PDO = first bar's open of D−1.

**Daily structure** (OHLC classifier on [D−3, D−2, D−1]): highs 1.0820 < 1.0845 < 1.0870 (rising) **and** lows 1.0750 < 1.0780 < 1.0810 (rising) → `FBPI_STRUCT_HH_HL`.

### 11.2 Today so far

Suppose today's window so far gives high 1.0880, low 1.0835, and Bid 1.0872.

```
Current range      = 1.0880 − 1.0835 = 0.0045 = 45.0 pips
Range as % of ADR  = 45.0 / 65.0 × 100 = 69.2%
Position in range  = (1.0872 − 1.0835) / (1.0880 − 1.0835) = 0.0037 / 0.0045 = 82.2%  →  UPPER (≥ 66.7%)
Distance to PDH    = (1.0872 − 1.0870) / 0.0001 = +2.0 pips  (Bid 2.0 pips above PDH)
Distance to PDL    = (1.0872 − 1.0810) / 0.0001 = +62.0 pips
Direction          = today's last closed close vs PDC 1.0860 (bullish if above)
```

### 11.3 Monthly structure — breakout down

Monthly closes [M−3, M−2, M−1] = 1.0750, 1.0780, 1.0740. They are not strictly rising or falling. The newest close 1.0740 is below every earlier close (min 1.0750) → close-sequence classifier step 5 → `FBPI_STRUCT_BREAKOUT_DOWN`. (Under the OHLC classifier, the same result follows if 1.0740 is also below the prior month's low.)

### 11.4 Quarterly range position — contraction, not expansion

Quarter: high 1.0950, low 1.0600, previous quarter range 0.0400, Bid 1.0872.

```
Current range       = 1.0950 − 1.0600 = 0.0350
Range vs previous   = 0.0350 / 0.0400 = 87.5%  →  < 90%  →  FBPI_RANGE_CONTRACTING
Position-only       = (1.0872 − 1.0600) / 0.0350 = 77.7%  →  UPPER
```

So `rangePos` is `CONTRACTING` while `positionOnly` is `UPPER`. Both are stored; the dashboard must show both, not one in place of the other. Had the current range been 0.0450 instead, 0.0450 / 0.0400 = 112.5% > 110% → `EXPANDING`.

## 12. Inputs that control this module

Declared only in `FBPI_Main.mq4`: `InpADRPeriod` = 14 (1…500), `InpWeeklyLookback` = 12 (clamped 2…52 in code), `InpShowQuarterly` / `InpShowMonthly` / `InpShowWeekly` / `InpShowDaily` = true (setting one false invalidates that layer's levels instead of computing them), `InpDayStartUTC` = `"00:00"`, `InpCutoffHourUTC` = 21, `InpBrokerGMTOffset` = 0.0 (double). `FBPI_MarketStructure_Init()` rejects `InpADRPeriod` outside 1…500 and `InpWeeklyLookback` outside its range, and Main must not call `Calculate()` after a failed Init.

## 13. Divergences and known limitations (recorded honestly)

1. **Quarterly exception is deliberate.** Structure is completed-periods-only everywhere except the quarterly trend, which includes the current quarter (§8.3). This follows the spec's framing, not an oversight.
2. **Liquidity's standalone daily assembly differs.** `FBPI_Liquidity_AssembleLevels()` reconstructs PDH/PDL/PDC/PDO from the *literal previous calendar day* (`dayStart − 86400`), with no weekend/holiday skip — unlike this module's 10-day search (§3.1). In the assembled indicator this does not bite, because MarketStructure runs first (RecalcAll step 2, Liquidity step 7) and Liquidity never overwrites a level that is already valid. Used standalone, Liquidity's daily levels would be invalid on a Monday. The fix belongs to Liquidity, not to this module.
3. **Two scan implementations exist.** Sessions has its own `FBPI_Sessions_ScanH1` copy; its header notes it should delegate to `FBPI_MarketStructure_ScanHighLow` once MarketStructure exists. The two scans agree on the [start, end) rule, but only this module's is the Architecture's shared primitive.
4. **ADR sample size is reported, not enforced.** When history is shorter than `InpADRPeriod`, ADR is the mean of the days that exist (with `adrDays` reported). It is not held back as INSUFFICIENT DATA. A 3-day ADR is a noisier number than a 14-day ADR, and the dashboard shows the count so the reader can tell.
5. **DST-transition days.** The broker day is 23 or 25 hours on a DST-transition day. Day windows are computed from UTC anchors, so the UTC frame stays correct, but a session window straddling the transition is computed from the offset in force at the window start (Architecture limitation L-5). Test 2 covers this.
6. **Live-terminal verification outstanding.** No value in §11 has been checked against a live terminal. Tests 1 and 4 remain CANNOT-VERIFY-WITHOUT-TERMINAL until run on the user's laptop after MetaEditor compile.
