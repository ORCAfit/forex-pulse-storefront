# FBPI Data Source Register — FBPI-MT4-001

| Field | Value |
|---|---|
| Project | Forex Bigger Picture Intelligence System, FBPI-MT4-001 |
| Companion | `docs/Technical_Architecture.md` (design authority), `include/FBPI_Common.mqh` (contract) |
| Date | 2026-11-27 (Phase 1) |
| Rule | Every datum is exactly one of: **(a) calculable natively in MQL4**, **(b) manual user input** (exact input field named), or **(c) external feed (optional)**. No datum is left unclassified. A datum with no source is **UNAVAILABLE** and displays the string in the last column — never a fabricated value, never a substitute from an unrelated source. |

## Classification key

| Code | Meaning | Availability flag (`ENUM_FBPI_AVAIL`) |
|---|---|---|
| **N** | Calculable natively in MQL4 from broker bars / `MarketInfo` / terminal time | `FBPI_AVAIL_CALCULATED` |
| **M** | Manual user input — the exact input field is named; value is shown with source "Manual input" and the timestamp it was entered | `FBPI_AVAIL_MANUAL` |
| **E** | External feed (optional) — a configured source; if not configured, the datum is UNAVAILABLE, not estimated | `FBPI_AVAIL_EXTERNAL` |
| **U** | Unavailable by default in MT4 — no native source and no feed configured; manual input is the only route | `FBPI_AVAIL_UNAVAILABLE` |

Stale rule (all M/E data): a manual/external value older than `InpMacroMaxAgeHours` (default 168 h = 7 days; central-bank rates: 2160 h = 90 days, set by `InpRateMaxAgeHours`) is flagged `FBPI_AVAIL_STALE` and displayed with a **STALE DATA** warning. Stale never silently becomes current.

Tick-volume rule (Layers 15, 19, 20): broker tick volume is always labelled **tick volume**, never consolidated volume. A footprint built from it is labelled **ESTIMATED TICK ACTIVITY**, never true bid/ask footprint.

---

## Layer 1 — Global Economy

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Global economic condition (expansion / contraction / mixed) | **M** | `InpGlobalCondition` (enum: Expansion / Contraction / Mixed / Unknown) | `DATA UNAVAILABLE` |
| Growth indicator (e.g. global GDP growth %) | **M/E** | `InpGlobalGrowthPct` (double, %); optional external calendar feed (not implemented in v1 — no WebRequest, no DLL) | `DATA UNAVAILABLE` |
| Inflation indicator (global CPI %) | **M/E** | `InpGlobalInflationPct` | `DATA UNAVAILABLE` |
| Employment indicator (global unemployment %) | **M/E** | `InpGlobalUnemploymentPct` | `DATA UNAVAILABLE` |
| Trade indicator (trade balance direction) | **M** | `InpGlobalTradeNote` (string, free text) | `DATA UNAVAILABLE` |
| Global risk sentiment (risk-on / risk-off / neutral) | **M** | `InpRiskSentiment` (enum) — user judgement, labelled as such | `DATA UNAVAILABLE` |
| Data source + last update (per observation) | **M/E** | Recorded automatically from the input/feed that supplied it (`MacroObservation.source`, `.updatedAt`) | `Source: none — DATA UNAVAILABLE` |
| Macroeconomic context field (free-text summary) | **M** | `InpMacroContextNote` (string) | *(field hidden when empty)* |

**Default state:** the whole layer is UNAVAILABLE until the user enters at least one value. Nothing is inferred from price action.

## Layer 2 — Monetary Policy (one row per central bank: Fed, ECB, BoE, BoJ, SNB, BoC, RBA, RBNZ)

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Current policy rate (%) | **M/E** | `InpRate_<CCY>` (e.g. `InpRate_USD`, `InpRate_EUR`, `InpRate_GBP`, `InpRate_JPY`, `InpRate_CHF`, `InpRate_CAD`, `InpRate_AUD`, `InpRate_NZD`) | `DATA UNAVAILABLE` |
| Previous policy rate (%) | **M** | `InpPrevRate_<CCY>` | `DATA UNAVAILABLE` |
| Latest policy decision (hike / hold / cut + date) | **M** | `InpDecision_<CCY>` (enum) + `InpDecisionDate_<CCY>` (string `yyyy.mm.dd`) | `DATA UNAVAILABLE` |
| Expected policy direction | **M** | `InpExpectedDir_<CCY>` (enum: Hike / Hold / Cut / Unknown) | `DATA UNAVAILABLE` |
| Interest-rate differential (pair, pp) | **N** | **Calculated** from the two entered rates above (base − quote); if either rate is missing, the differential is UNAVAILABLE, not zero | `DATA UNAVAILABLE` |
| Next scheduled policy announcement | **M** | `InpNextMeeting_<CCY>` (string `yyyy.mm.dd`) | `DATA UNAVAILABLE` |

**Default state:** all rates UNAVAILABLE. The differential is the only native calculation in this layer, and it depends entirely on manual rates.

## Layer 3 — Financial Conditions

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Interest-rate environment (summary) | **M** | Derived from Layer 2 rates; no separate input | `DATA UNAVAILABLE` (if Layer 2 empty) |
| Government bond yield (e.g. US 10Y %) | **M/E** | `InpBondYield10Y` (double); optional external feed | `DATA UNAVAILABLE` |
| Credit conditions | **M** | `InpCreditConditions` (enum: Tightening / Neutral / Easing / Unknown) | `DATA UNAVAILABLE` |
| Funding conditions | **M** | `InpFundingConditions` (enum, as above) | `DATA UNAVAILABLE` |
| Dollar liquidity | **M** | `InpDollarLiquidity` (enum: Ample / Neutral / Tight / Unknown) | `DATA UNAVAILABLE` |
| Risk appetite | **M** | `InpRiskAppetite` (enum: Risk-on / Neutral / Risk-off) | `DATA UNAVAILABLE` |
| Financial stress indicator | **M/E** | `InpStressNote` (string); optional external feed | `DATA UNAVAILABLE` |
| Source + timestamp per observation | **M/E** | Automatic (`MacroObservation`) | `Source: none — DATA UNAVAILABLE` |

**Default state:** UNAVAILABLE. MT4 does not possess any of this information natively; the dashboard must not imply otherwise.

## Layer 4 — Global Markets (cross-market)

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Gold price, daily change % | **N** | Broker symbol `InpGoldSymbol` (default `XAUUSD`, mapped via prefix/suffix); price + change calculated from broker bars | `DATA UNAVAILABLE` (symbol not offered by broker) |
| Oil price, daily change % | **N** | Broker symbol `InpOilSymbol` (default `XTIUSD`); as above. CAD-related context only | `DATA UNAVAILABLE` |
| Major equity index direction / % change (per configured index) | **N** | Broker symbols in `InpIndexSymbols` (comma list, e.g. `US30,SPX500,NAS100`); calculated from broker bars | `DATA UNAVAILABLE` per index |
| Bond price / yield direction | **N/M** | Broker bond CFD if offered (add to `InpIndexSymbols`); otherwise `InpBondYield10Y` (Layer 3) | `DATA UNAVAILABLE` |
| Currency-market direction (per watchlist pair) | **N** | Calculated from broker bars (daily change, ADR position) | `DATA UNAVAILABLE` |
| Correlation / relative strength / risk-on-off | **N** | **Calculated** from broker price series only (Pearson on daily closes, lookback `InpCorrLookback` = 20 days); labelled "20-day price correlation — not permanent, not causal" | `DATA UNAVAILABLE` (fewer than `InpCorrLookback` closes) |
| Other configured market indicators | **N/M** | Any broker symbol added to `InpCrossSymbols`; otherwise manual note `InpCrossNote` | `DATA UNAVAILABLE` |

## Layer 5 — Asset Class

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Asset-class strengthening/weakening (equities, fixed income, FX, commodities, precious metals, energy) | **N** | **Calculated** from Layer 4 broker symbols: daily % change per class proxy, ranked; shown as contextual ranking only | `DATA UNAVAILABLE` (no proxy symbol for that class) |
| Asset-class relationships | **N** | Calculated correlation (Layer 4 method); displayed as "contextual information, not a guaranteed causal relationship" | `DATA UNAVAILABLE` |

Class proxies (defaults, all overridable): equities `InpIndexSymbols[0]`; fixed income — manual/bond CFD (Layer 4); FX — watchlist average daily move; commodities — `InpOilSymbol`; precious metals — `InpGoldSymbol`; energy — `InpOilSymbol`. If a class has no proxy, it is omitted from the ranking, not given a zero.

## Layer 6 — Market Index

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Index current price | **N** | Broker symbol from `InpIndexSymbols` | `DATA UNAVAILABLE` |
| Daily change (% and points) | **N** | Calculated from broker bars | `DATA UNAVAILABLE` |
| Trend (vs 20-day direction) | **N** | Calculated (close vs open of lookback window) | `DATA UNAVAILABLE` |
| Daily high / low | **N** | Calculated from broker bars | `DATA UNAVAILABLE` |
| Relative performance (vs other configured indices) | **N** | Calculated ranking of daily % changes | `DATA UNAVAILABLE` |

Broker naming differs (e.g. `US30` vs `DJ30`); the user must configure the exact broker symbol. A wrong symbol is UNAVAILABLE, never guessed.

## Layer 7 — Futures Contract

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Futures price (NQ, ES, currency futures) | **E/U** | Optional external futures feed only (not implemented in v1 — no WebRequest/DLL). Broker futures CFD, if offered, may be entered as a symbol in `InpFuturesSymbols` and is then labelled **broker CFD, not exchange futures** | `DATA UNAVAILABLE` |
| Spot Forex price | **N** | Broker bars (the chart symbol) | — (always present when attached) |
| Broker CFD price | **N** | Broker symbol, labelled CFD | `DATA UNAVAILABLE` |
| Futures vs spot vs CFD distinction | **N** | Display rule: the three are shown in separate rows with their source labels; never merged into one price | `DATA UNAVAILABLE` for the futures row |

**Default state:** `DATA UNAVAILABLE`. Futures are manual-input or unavailable by default — never fabricated, never proxied by the spot price.

## Layer 8 — Quarterly Structure

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Quarterly high / low / open / close | **N** | Calculated from H1 bars in the current quarter window | `DATA UNAVAILABLE` (no bars) |
| Current quarterly range | **N** | high − low | `DATA UNAVAILABLE` |
| Price position within quarterly range (%) | **N** | (Bid − low)/(high − low) | `DATA UNAVAILABLE` |
| Quarterly trend (direction) | **N** | Close vs open + HH/HL sequence on quarterly closes | `DATA UNAVAILABLE` |
| Classification: upper / lower / midrange / expanding / contracting | **N** | Calculated from position % + range vs prior-quarter range | `DATA UNAVAILABLE` |

## Layer 9 — Monthly Structure

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Current monthly high / low / open / close | **N** | Calculated from H1 bars | `DATA UNAVAILABLE` |
| Previous monthly high / low | **N** | Calculated from H1 bars of the prior month | `DATA UNAVAILABLE` |
| Monthly range | **N** | high − low | `DATA UNAVAILABLE` |
| Directional structure: HH/HL, LH/LL, consolidation, breakout | **N** | Calculated from monthly closes sequence (3 months minimum) | `DATA UNAVAILABLE` / `INSUFFICIENT DATA` (< 3 monthly closes) |

## Layer 10 — Weekly Context

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Previous week high / low / close | **N** | Calculated from H1 bars | `DATA UNAVAILABLE` |
| Current week open / high / low | **N** | Calculated from H1 bars | `DATA UNAVAILABLE` |
| Weekly range | **N** | high − low | `DATA UNAVAILABLE` |
| Weekly expansion / contraction | **N** | Current range vs prior-week range and vs average weekly range (`InpWeeklyLookback` = 12) | `DATA UNAVAILABLE` |
| Previous-week liquidity (level = PWH/PWL) | **N** | LevelInfo PWH/PWL (Layer 17) | `DATA UNAVAILABLE` |
| Price position within weekly range (%) | **N** | Calculated | `DATA UNAVAILABLE` |

## Layer 11 — Daily Context

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| PDH / PDL / PDC / PDO, current DO, current day high / low | **N** | Calculated from H1 bars of the previous/current trading day (UTC reference frame — see Architecture §4) | `DATA UNAVAILABLE` |
| Daily range, ADR (`InpADRPeriod` = 14) | **N** | Calculated | `DATA UNAVAILABLE` / `INSUFFICIENT DATA` (< 14 days) |
| Current range as % of ADR | **N** | Calculated | `DATA UNAVAILABLE` |
| Distance to PDH / PDL (pips) | **N** | Calculated | `DATA UNAVAILABLE` |
| Daily directional structure | **N** | Calculated (close vs open, HH/HL on daily closes) | `DATA UNAVAILABLE` |

## Layer 12 — Trading Session

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Session windows (Asian 00:00–09:00, London 07:00–16:00, NY 12:00–21:00 UTC defaults) | **N/M** | UTC defaults, configurable via `InpAsianStartUTC` etc. as **"HH:MM" strings**; broker offset `InpBrokerGMTOffset` (**double**, half-hours allowed); DST `InpDSTMode` (rule-based US/EU/Manual/Off) | Windows always computable from inputs; if an input is malformed, `OnInit` returns `INIT_PARAMETERS_INCORRECT` |
| Session open / high / low / range / direction | **N** | Calculated from H1 bars in each window | `DATA UNAVAILABLE` (window not started / no bars) |
| London breakout / Asian high-low interaction | **N** | Calculated (London close vs ASH/ASL) | `DATA UNAVAILABLE` |
| NY continuation / reversal vs London high/low | **N** | Calculated | `DATA UNAVAILABLE` |
| Session overlap analysis | **N** | Calculated (12:00–16:00 UTC overlap window) | `DATA UNAVAILABLE` |
| Current session + market status | **N** | Calculated from UTC time + broker offset | `Closed` (weekend / between sessions) |

## Layer 13 — Opening Range

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Opening range high / low / midpoint | **N** | Calculated from H1/M15 bars in the first `InpOpeningRangeMinutes` (15/30/60) after the `InpOpeningRangeSession` open (default New York) | `DATA UNAVAILABLE` (session not started) |
| Breakout above / below, failed breakout, retest, rejection | **N** | Calculated from closed bars after the range (see Architecture §4.5) | `—` (no event yet today) |
| Independent London and New York opening ranges | **N** | Calculated separately (`InpORLondonMinutes`, `InpORNewYorkMinutes`) | `DATA UNAVAILABLE` per session |

## Layer 14 — Intraday Auction

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Auction state (trend / balance / consolidation / expansion / reversal / failed breakout / range rejection) | **N** | Calculated from measurable behaviour only: candle range vs ATR, HH/LL sequences, close location, range expansion, breakout persistence (`ENUM_FBPI_AUCTION`) | `UNKNOWN` (fewer than `InpAuctionMinBars` = 10 closed bars) |
| Supporting measurements (ATR, range, close location) | **N** | Calculated | `DATA UNAVAILABLE` |

No institutional-intent claim is ever displayed. The dashboard shows the measurements behind the classification.

## Layer 15 — Volume Profile

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| POC, volume distribution, high/low-volume nodes, profile boundaries | **N** | Calculated from **broker tick volume** on H1 bars, binned (`InpProfileBins`, default 24); labelled **tick volume** | `DATA UNAVAILABLE` (no tick volume / too few bars) |
| Daily / session / weekly profile | **N** | Calculated per scope | `DATA UNAVAILABLE` per scope |
| Exchange-traded currency-futures volume | **E/U** | Optional external feed only; if configured, labelled with its source name | `DATA UNAVAILABLE` (default) — tick-volume profile is shown instead, clearly labelled |

## Layer 16 — Value Area

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| VAH / VAL / POC | **N** | Calculated from the Layer 15 profile at `InpValueAreaPct` (default 70%) | `DATA UNAVAILABLE` |
| Price above / below / inside value | **N** | Calculated (Bid vs VAH/VAL) | `DATA UNAVAILABLE` |
| Value-area acceptance / rejection / migration | **N** | Calculated from closed bars vs VAH/VAL over `InpVAConfirmBars` = 3 | `—` (no event) |
| Calculation method documentation | — | `docs/Volume_Profile_Methodology.md` (Phase 5 deliverable) | — |

## Layer 17 — Key Levels

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| All levels (quarterly/monthly/weekly/daily/session/OR/POC/VAH/VAL — 28 kinds, `ENUM_FBPI_LEVEL`) | **N** | Calculated (Layers 8–13, 15–16 feed this layer) | `DATA UNAVAILABLE` per level (invalid levels are hidden, never zero) |
| Distance from current price (pips) | **N** | Calculated | `DATA UNAVAILABLE` |
| Historical touch frequency / probability % + Wilson 95% interval + sample size N | **N** | Calculated from history only (lookback `InpProbLookback` = 100 days, min N `InpMinSample` = 20); **no probability is shown without N**; `INSUFFICIENT DATA` when N < 20 | `INSUFFICIENT DATA (N=…)` |
| Breakout / rejection / sweep / retest (per level) | **N** | Calculated (Layer 6 module `FBPI_Liquidity`) | `—` (no event) |

## Layer 18 — Order Book

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Bid depth / ask depth / imbalance / displayed liquidity levels / changes | **E/U** | Genuine depth only, via a broker/exchange depth feed if one is ever configured (`InpOrderBookSource`, empty by default). MT4 does not guarantee consolidated Forex depth | **`ORDER BOOK UNAVAILABLE`** (default, and whenever the feed is absent) |

**Hard rule:** resting orders are never invented from candlestick patterns. The dashboard shows `ORDER BOOK UNAVAILABLE` in grey, not a blank or a zero.

## Layer 19 — Order Flow

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Aggressive buying / selling, bid/ask volume, delta, cumulative delta, volume imbalance | **E/U** | True bid/ask volume from an external exchange feed only (`InpOrderFlowSource`, empty by default) | `DATA UNAVAILABLE` |
| Tick-activity estimate (delta proxy from tick volume × candle direction) | **N** | Calculated from broker tick volume; **always labelled ESTIMATED TICK ACTIVITY**, never presented as verified institutional order flow | `DATA UNAVAILABLE` (no tick volume) |

## Layer 20 — Footprint Candle

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Bid volume / ask volume / delta / imbalance / absorption candidates / volume concentration per price level | **E/U** | True bid/ask volume only (external feed, as Layer 19) | `DATA UNAVAILABLE` |
| Tick-volume alternative mode | **N** | Calculated from broker tick volume per price bin; labelled **ESTIMATED TICK ACTIVITY** in the panel heading | `DATA UNAVAILABLE` (no tick volume) |

## Layer 21 — Confirmation

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| HTF alignment (20), key-level location (20), liquidity event (20), market-structure confirmation (20), candle confirmation (10), session alignment (10) | **N** | Calculated from Layers 8–14, 17; weights are inputs `InpWeightHTF` etc. (defaults 20/20/20/20/10/10 = 100) | **Missing data scores ZERO** for that factor; the factor row shows `No data — 0 pts` |
| Total confirmation score (0–100) + band (Strong 80–100 / Moderate 65–79 / Weak 50–64 / Insufficient < 50) | **N** | Calculated sum; thresholds are inputs (`InpConfStrong` = 80, `InpConfModerate` = 65, `InpConfWeak` = 50) | Score shown with the factors that produced it; never shown without the factor breakdown |
| Per-factor evidence text | **N** | Calculated (one line per factor) | `No data` |

## Layer 22 — Risk Plan

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Account/paper capital, risk %, max daily loss, min/preferred R:R | **M** | `InpPaperCapital` = 5000, `InpRiskPct` = 0.5, `InpMaxDailyLossPct` = 2.0, `InpMinRR` = 2.0, `InpPrefRR` = 3.0, `InpAccountCurrency` = `USD` | Defaults apply (these are user configuration, not market data) |
| Risk amount, entry, stop, target, stop distance, position size, pip value, spread impact, commission, potential profit, R:R | **N/M** | Calculated from the setup + `MarketInfo` (tick value/size, lot step, min lot); entry/SL/TP come from the identified setup (Layers 21/23) or manual plan inputs `InpPlanEntry`, `InpPlanStop`, `InpPlanTarget` (0 = use setup); commission from `InpCommissionPerLot` (0 = none) | `—` (no setup and no manual plan); pip value `DATA UNAVAILABLE` if `MarketInfo` returns 0 |
| Daily loss so far | **M** | `InpDailyLossSoFar` (user updates it; the indicator never reads a broker account) | Assumed 0 with a note "daily loss not entered" |
| Risk-rule violation warning | **N** | Calculated (min R:R, daily-loss limit, lot-step) | Warning shown only when a rule is violated; never recommends increasing risk |

## Layer 23 — Execution

| Datum | Class | Source / input field | Display when missing |
|---|---|---|---|
| Pair, direction, entry, SL, TP, position size, risk %, R:R, confirmation score, session, key level, liquidity event, rationale | **N** | Assembled from Layers 21–22 (all calculated) | `—` / `ANALYSIS INCOMPLETE` |
| Execution status (6 states, spec L23) | **N** | Calculated state machine (`ENUM_FBPI_EXEC_STATUS`) | `ANALYSIS INCOMPLETE` |
| Order placement | — | **DOES NOT EXIST.** No `OrderSend`/`OrderModify`/`OrderClose` anywhere. Human approval is mandatory and happens outside the indicator | — |

---

## Cross-layer summary

| Layer | Native (N) | Manual (M) | External (E) | Unavailable by default (U) |
|---|---|---|---|---|
| 1 Global Economy | 0 | 7 | 3 (optional) | Whole layer until entered |
| 2 Monetary Policy | 1 (differential) | 6 per bank | 6 (optional) | All rates until entered |
| 3 Financial Conditions | 1 (derived) | 6 | 2 (optional) | Whole layer until entered |
| 4 Global Markets | 7 | 1 | 0 | Per-symbol if broker lacks it |
| 5 Asset Class | 2 | 0 | 0 | Per class without a proxy |
| 6 Market Index | 5 | 0 | 0 | Per index if broker lacks it |
| 7 Futures | 2 (spot/CFD) | 0 | 1 | Futures row by default |
| 8 Quarterly | 5 | 0 | 0 | — |
| 9 Monthly | 4 | 0 | 0 | — |
| 10 Weekly | 6 | 0 | 0 | — |
| 11 Daily | 6 | 0 | 0 | — |
| 12 Session | 6 | 1 (times) | 0 | — |
| 13 Opening Range | 3 | 1 (duration) | 0 | — |
| 14 Auction | 2 | 0 | 0 | — |
| 15 Volume Profile | 3 | 0 | 1 (optional) | Futures volume by default |
| 16 Value Area | 4 | 0 | 0 | — |
| 17 Key Levels | 4 | 0 | 0 | — |
| 18 Order Book | 0 | 0 | 1 | **Whole layer by default** |
| 19 Order Flow | 1 (estimate) | 0 | 1 | True flow by default |
| 20 Footprint | 1 (estimate) | 0 | 1 | True footprint by default |
| 21 Confirmation | 3 | 0 | 0 | Per factor (scores 0) |
| 22 Risk Plan | 2 | 2 | 0 | — |
| 23 Execution | 2 | 0 | 0 | — |

**Net position:** Layers 8–17, 21–23 are fully native. Layers 1–3 are manual-or-unavailable by default. Layer 7 futures, Layer 18 order book, and true bid/ask flow (19–20) are unavailable by default. No datum in any layer is fabricated: the only values the indicator ever shows are calculated, manually entered (labelled), externally sourced (labelled with source + timestamp), or marked unavailable.

*End of Data Source Register — FBPI-MT4-001 Phase 1.*
