# Probability Methodology — FBPI-MT4-001

| Field | Value |
|---|---|
| Project | Forex Bigger Picture Intelligence System, FBPI-MT4-001 |
| Spec | `FBPI-MT4-001-spec.md` v1.0, Layer 17, §12 (source of truth) |
| Design authority | `docs/Technical_Architecture.md` §4.6, §6.1 |
| Code | `include/FBPI_Liquidity.mqh` (probability engine), `include/FBPI_Common.mqh` (`FBPI_BarTouchesLevel`, `FBPI_WilsonInterval`, `FBPI_Brier`), `include/FBPI_Statistics.mqh` (Brier skill, calibration) |
| Date | 2026-11-27 |
| Status | **Live-terminal verification outstanding.** Tests 8 and 12 (spec §17) are CANNOT-VERIFY-WITHOUT-TERMINAL until the indicator is compiled in MetaEditor and run on the user's laptop. Nothing in this document is a claim that the terminal agrees. |

## 1. What the engine answers

For each of 7 probability levels — **PDH, PDL, PDC, ONH, ONL, ORH, ORL** — the engine answers one question, and only one:

> *On past days like today, how often was this level touched inside its evaluation window?*

The answer is a frequency over completed days, with a sample size and a Wilson 95% interval, always shown together. It is a descriptive summary of the past. It is not a prediction, not a trade signal, and not a statement about profitability (§10).

The 7 levels are the FLR set, kept for continuity. The other 21 level kinds (quarterly, monthly, weekly, session, POC, VAH, VAL, …) have no probability: the engine covers only these 7.

## 2. The touch test — and why the OR form is a tautology

There is exactly one touch test in the system: `FBPI_BarTouchesLevel()` in `FBPI_Common.mqh`. The live status, the alert path, and the probability loop all call it — one helper, three call sites, no divergent copies.

| Touch direction | Levels | Test on one H1 bar (High, Low, Close) |
|---|---|---|
| UP | PDH, ONH, ORH | `High >= level` |
| DOWN | PDL, ONL, ORL | `Low <= level` |
| NEUTRAL | PDC only (among probability levels) | `High >= level AND Low <= level` — the bar's range **contains** the level |

The neutral test is the point of this section, because getting it wrong silently destroys the engine.

### 2.1 Proof that OR is a tautology

For any bar and any level, at least one of `High >= level` or `Low <= level` is always true. Proof: suppose `High < level`. Since `Low <= High` for every bar, `Low < level` follows, so `Low <= level` is true. Hence `High >= level OR Low <= level` is true for **every** bar, whatever the level is. A test that is true for every bar counts every day as a touch, and the probability is 100% by construction — it measures nothing.

Worked example, level 1.0825:

| Bar | High | Low | OR test | AND test |
|---|---|---|---|---|
| Bar entirely above the level | 1.0850 | 1.0830 | true (`High >= level`) | **false** (`Low 1.0830 > level`, range does not contain it) |
| Bar entirely below the level | 1.0820 | 1.0800 | true (`Low <= level`) | **false** (`High 1.0820 < level`) |
| Bar straddling the level | 1.0835 | 1.0805 | true | **true** (range contains 1.0825) |

Only the AND form distinguishes "price traded through the level" from "price was somewhere near it". The OR form is **forbidden** in FBPI.

### 2.2 The FLR PDC bug

In the predecessor indicator FLR-MT4-001, the neutral (PDC) touch test was written with OR. The result was exactly what the proof predicts: the PDC probability was always 100%, on every symbol, on every lookback — a number that looked like a finding and was actually an artefact of the test. Architecture §8.2 item F-5 records the fix; `FBPI_BarTouchesLevel()` implements the AND form, and the comment in the common header states the prohibition in the code itself. **Test 8's regression check is: PDC is not 100%.** If a PDC probability of 100% ever appears with a real sample size, the engine is broken, not the market.

### 2.3 Touch methods and spread adjustment

`InpTouchMethod` (default `FBPI_TOUCH_HIGH_LOW`) selects the test shape; `InpSpreadAdjPoints` (default 0.0) is the adjustment in points:

| Method | UP test | DOWN test | NEUTRAL test |
|---|---|---|---|
| `HIGH_LOW` (default) | `High >= level` | `Low <= level` | `High >= level AND Low <= level` |
| `SPREAD_ADJ` | `High >= level + spread` | `Low <= level − spread` | `High >= level + spread AND Low <= level − spread` |
| `CLOSE` | `Close >= level − tol` | `Close <= level + tol` | `\|Close − level\| <= tol` |

where `spread` / `tol` = `InpSpreadAdjPoints × point` for the symbol. Note the direction of the spread adjustment: it **narrows** the touch zone — the level is moved *against* the touch (up: higher; down: lower), making a touch harder. FLR widened the zone (`level − adj`), making touches easier; that is the opposite of the spec and is fixed here (Architecture F-4). At defaults (method `HIGH_LOW`, adjustment 0) behaviour is identical to FLR's at defaults — only the neutral test differs, and that is the bug fix.

The touch method is recorded per scoreboard row (`touch_method` column: `HIGH_LOW`, `CLOSE`, or `SPREAD_ADJ`), so a probability can always be traced to the test that produced it.

## 3. Forecast construction — from days before D only

For each probability level and each past day D = 1…`InpProbLookback` (default 100), the engine:

1. **Reconstructs D's forecast level from days before D only** (`FBPI_Liquidity_ForecastLevel()`).
2. **Tests the touch inside D's evaluation window** (`FBPI_Liquidity_EvalWindow()` + `FBPI_Liquidity_TouchInWindow()` on H1 bars).
3. Counts eligible days and touches: `prob = touches / eligible × 100`.

**Today (day 0) is excluded from every lookback loop.** There is no look-ahead by construction of the loop bounds, not by convention: the loop runs `day = 1` to `lookback`, and the forecast level for day D is built only from data dated before D.

### 3.1 How each forecast level is reconstructed

| Level | Forecast level for day D | Built from |
|---|---|---|
| PDH | High of the day before D (daysAgo + 1) | H1 scan of that day's window |
| PDL | Low of the day before D | H1 scan of that day's window |
| PDC | Close of the day before D | H1 scan of that day's window (close = last bar's close in the window) |
| ONH | High of the overnight window [21:00 UTC previous day, 07:00 UTC] of day D | H1 scan spanning the day boundary — genuine overnight, **not** the Asian session high |
| ONL | Low of the same overnight window | H1 scan spanning the day boundary |
| ORH | High of day D's opening range (session open + `InpOpeningRangeMinutes`, M15 bars) | M15 scan of day D's opening range |
| ORL | Low of day D's opening range | M15 scan of day D's opening range |

Two nuances, stated plainly:

- **ORH/ORL are built from day D's own opening range.** That is not "days before D" in the strict sense — but the opening range is complete *before* the evaluation window starts (the evaluation window for ORH/ORL begins at the end of the opening range, §3.2). Nothing inside the evaluation window is used to build the level. The forecast is known at the moment the window opens.
- **ONH/ONL are genuine overnight levels.** The window [21:00 UTC previous day, 07:00 UTC current day) crosses the trading-day boundary. FLR set ONH/ONL equal to the Asian session high/low; FBPI does not (Architecture F-1).

### 3.2 Evaluation windows

The evaluation window runs from the moment the level is known until the cutoff (`InpCutoffHourUTC`, default 21:00 UTC), capped at the day end:

| Level | Evaluation window (day D) |
|---|---|
| PDH, PDL, PDC | Day start → 21:00 UTC cutoff |
| ONH, ONL | Asian session end (09:00 UTC at defaults) → 21:00 UTC cutoff |
| ORH, ORL | End of the opening range → 21:00 UTC cutoff |

If the computed window end is not after the window start, the code forces a 1-hour window (`we = ws + 3600`) rather than an empty one — a guard, not a normal case.

### 3.3 Worked example — PDH over 20 days

Take `InpProbLookback` = 20, `InpMinSample` = 20, level PDH, touch method `HIGH_LOW`. For each day D = 1…20: forecast PDH = the high of day D+1's [00:00, 21:00) window; test whether any H1 bar in day D's [00:00, 21:00) window has `High >= forecast PDH`. Suppose 14 of the 20 days touch:

```
eligible N = 20, touches = 14
prob = 14 / 20 × 100 = 70.0%
Wilson 95% interval = 48.1% – 85.5%   (worked in §6)
display: "70.0% (N=20, Wilson 48.1-85.5)"
```

If only 19 of the 20 days could be evaluated (one day's forecast level unbuildable, §4), then N = 19 and, with the default minimum sample of 20, the display is `INSUFFICIENT DATA (N=19)` and no scoreboard row is written — even though 19 days were examined.

## 4. Eligible-observation rules

A day enters N only if **both** of these hold:

1. **The forecast level can be built.** `ForecastLevel()` returns false when the source window has no bars. That day is skipped, not counted as a miss.
2. **The source window lies entirely inside available H1 history.** The engine takes the earliest available H1 bar open time (`iTime(symbol, PERIOD_H1, totalBars − 1)`) and excludes any day whose forecast source window starts before it. A window partly outside history would silently bias the result — a level built from a truncated window is a different level — so the day is excluded from N. The dashboard can tell history is short because `eligible < lookback`: a lookback of 100 that yields N = 63 means 37 days were excluded, and the reason is visible in the number itself. (The Architecture document describes this as a `historyShort` flag; the code as written carries no such flag field — the shortfall is signalled by eligible < lookback. See §11.2.)

Weekends and holidays are not "days" in this loop at all: the loop counts *trading days* back from today by calendar offset, and a calendar day with no bars simply fails rule 1 and is excluded. There is no interpolation and no substitution.

## 5. Sample-size rule

```
N < InpMinSample (default 20)  →  INSUFFICIENT DATA, no probability, no scoreboard row
```

Concretely, in `FBPI_Liquidity_CalcProbabilities()`: when `eligible >= minSample`, `probPct` is set and `valid = true` with the Wilson interval computed; otherwise `probPct` stays `FBPI_INVALID_DOUBLE` (−1.0), `valid = false`, and the display string is `INSUFFICIENT DATA (N=…)`. `FBPI_Liquidity_ProbText()` renders three cases and only three:

- `eligible ≤ 0` → `DATA UNAVAILABLE`
- not valid → `INSUFFICIENT DATA (N=…)`
- valid → `"<prob>% (N=<eligible>, Wilson <low>-<high>)"`

**A probability is never displayed without its sample size.** The Statistics module enforces the same rule at capture time: `CaptureForecast()` skips any level whose stats are not valid and prints `no forecast row for <abbr> — INSUFFICIENT DATA (N=…)`. No scoreboard row is written for that level that day — a missing row is the honest record of an insufficient sample, not a gap to be filled later.

`InpMinSample` is validated to 5…100 and must be ≤ lookback (Main validation); the engine itself clamps it to 5…100 and the lookback to 5…500.

## 6. Wilson 95% interval

Every valid probability carries a Wilson score interval (`FBPI_WilsonInterval()`, z = 1.96, `FBPI_WILSON_Z`). FLR omitted it entirely; FBPI computes it for every probability. The formula, exactly as coded:

```
p      = touches / n
z      = 1.96,  z² = 3.8416
denom  = 1 + z²/n
centre = p + z²/(2n)
inner  = p(1 − p)/n + z²/(4n²)
margin = z × √inner
low    = (centre − margin) / denom × 100
high   = (centre + margin) / denom × 100
```

Bounds are clamped to [0, 100]. The function returns false (no interval) when n ≤ 0.

### 6.1 Worked numeric example — 72 touches in 100 days

```
p = 0.72, n = 100, z² = 3.8416
denom  = 1 + 3.8416/100        = 1.038416
centre = 0.72 + 3.8416/200     = 0.72 + 0.019208 = 0.739208
inner  = 0.72×0.28/100 + 3.8416/40000 = 0.002016 + 0.00009604 = 0.00211204
margin = 1.96 × √0.00211204    = 1.96 × 0.045957 = 0.090076
low    = (0.739208 − 0.090076) / 1.038416 × 100 = 62.51%
high   = (0.739208 + 0.090076) / 1.038416 × 100 = 79.86%
display: "72.0% (N=100, Wilson 62.5-79.9)"
```

The interval is wide even at N = 100: a 72% point estimate is consistent, at 95% confidence, with a true touch rate anywhere from about 63% to about 80%. That width is the point of showing it — the point estimate alone overstates what 100 days can say.

### 6.2 Worked numeric example — 14 touches in 20 days (small sample)

```
p = 0.70, n = 20
denom  = 1 + 3.8416/20  = 1.19208
centre = 0.70 + 3.8416/40 = 0.79604
inner  = 0.70×0.30/20 + 3.8416/1600 = 0.0105 + 0.002401 = 0.012901
margin = 1.96 × √0.012901 = 1.96 × 0.113585 = 0.222627
low    = (0.79604 − 0.222627) / 1.19208 × 100 = 48.10%
high   = (0.79604 + 0.222627) / 1.19208 × 100 = 85.45%
```

At the minimum sample of 20, a 70% estimate carries an interval 48%–85% — nearly 40 points wide. Any decision that treats "70%" as precise at N = 20 is misreading the number.

### 6.3 A discrepancy to record

The Architecture document's §6.1 example scoreboard row shows a PDH forecast of 72.00% with Wilson bounds 62.40–80.60. Recomputing 72 touches in 100 days with `FBPI_WilsonInterval()` gives **62.51–79.86** (§6.1), not 62.40–80.60. The Architecture example row is therefore illustrative, not a recomputation from its own figures — the code's formula governs, and the two worked examples above were verified against the code's arithmetic. (The same row's Brier contribution, 0.0784 = (0.72 − 1)², does reproduce exactly.)

## 7. Probability categories (descriptive labels)

The code displays a raw percentage and a Wilson interval; it computes **no category**. The categories below are this document's reading labels, defined so that a percentage can be described in words without implying precision it does not have. They are descriptive, not guarantees, and not thresholds for trading.

| Probability | Label | Reading |
|---|---|---|
| 80–100% | Very High | Touched on at least 4 in 5 past days in the sample. |
| 65–79% | High | Touched on roughly 2 in 3 past days or more. |
| 50–64% | Moderate | Touched on about half the past days. |
| 30–49% | Low | Touched on fewer than half the past days. |
| 0–29% | Very Low | Rarely touched in the sample. |

Two warnings apply to every row of this table. First, the label inherits the interval: a "High" 70% at N = 20 has a Wilson interval reaching down to 48% (Moderate) — the label describes the point estimate, not the range the data supports. Second, the boundaries (80/65/50/30) are round-number conventions chosen for this document, not values derived from the data or the code. Nothing in the indicator uses them; the Confirmation module's key-level factor uses its own thresholds (65% for full points, 50% for half — see §11.4) and does not use these labels.

## 8. Brier score

The Brier score measures how close a probabilistic forecast was to the binary outcome. For one finalised day, with forecast f as a proportion (0…1) and outcome o ∈ {0, 1}:

```
Brier contribution = (f − o)²        — FBPI_Brier() in FBPI_Common.mqh
```

`FBPI_Brier()` clamps f to [0, 1] first. Worked examples at f = 0.72:

```
outcome touched (o = 1):  (0.72 − 1)² = 0.0784
outcome not touched (o = 0): (0.72 − 0)² = 0.5184
```

A confident forecast that is wrong is punished quadratically: forecasting 72% and missing costs 0.5184, more than six times the 0.0784 cost of forecasting 72% and being right. The mean Brier score over finalised rows is `FBPI_Statistics_Brier()` = `g_fbpiSbSumBrier / g_fbpiSbBrierN`. A lower mean Brier score is a better forecast; 0 is perfect, 1 is the worst possible.

**Where the Brier score lives.** `TouchStats.brier` is **−1** in the Liquidity engine: the Brier score is a mean over *finalised scoreboard rows* and is computed by the Statistics module, not from the probability loop. A per-row `brier_contribution` is written to the scoreboard CSV only at finalisation, once the outcome is known. An open (unfinalised) row has no Brier value — it cannot, because its outcome does not exist yet.

### 8.1 Worked example — mean Brier over 3 finalised rows

| Row | Forecast f | Outcome o | (f − o)² |
|---|---|---|---|
| 1 | 0.72 | 1 (touched) | 0.0784 |
| 2 | 0.65 | 0 (not touched) | 0.4225 |
| 3 | 0.80 | 1 (touched) | 0.0400 |

```
mean Brier = (0.0784 + 0.4225 + 0.0400) / 3 = 0.5409 / 3 = 0.1803
```

### 8.2 Brier skill vs climatology

The Brier skill score compares the forecasts against the dumbest reasonable alternative: always forecasting the overall actual touch rate (the "climatology" or base rate). `FBPI_Statistics_BrierSkill()`:

```
p_clim     = total touches / total finalised rows   (overall actual touch rate)
Brier_clim = p_clim × (1 − p_clim)
skill      = 1 − Brier / Brier_clim
```

- Skill **1.0** is perfect. **0.0** means no better than always forecasting the base rate. **Negative** means worse than the base rate.
- The function returns `FBPI_INVALID_DOUBLE` when there is no finalised row yet, or when every outcome is identical — in that case `Brier_clim` is 0 (climatology is then perfect) and skill is undefined, not zero.

Worked example continuing §8.1: 2 touches in 3 rows, so `p_clim = 2/3 ≈ 0.6667`, `Brier_clim = 0.6667 × 0.3333 = 0.2222`, and:

```
skill = 1 − 0.1803 / 0.2222 = 1 − 0.8113 = 0.19
```

A skill of 0.19 means the forecasts beat the base-rate forecast by about 19% of the gap between the base rate and perfection, over these 3 rows — a small sample, reported as such, not as a finding.

## 9. Calibration deciles

`FBPI_Statistics_Calibration()` groups finalised rows into **10 decile bins** by frozen forecast — 0–10%, 10–20%, …, 90–100% — and reports per bin the mean frozen forecast, the actual touch rate, and the sample size n. Bins with no row keep invalid values and n = 0. A forecast of 70% that touches 70% of the time is calibrated; a systematic gap between the two columns is miscalibration — of the *forecast*, not of any trade.

**Deviation to record (Statistics D-1).** The Architecture document §6.1 specifies five calibration bins (0–29 / 30–49 / 50–64 / 65–79 / 80–100). The code implements ten decile bins instead. The five-bin scheme can be recovered exactly by merging deciles (0–29 = bins 0–10, 10–20, 20–30; and so on), so nothing is lost, but the Architecture document and the code disagree and the code governs what the dashboard can show.

Per-day-of-week counts are also kept (`TouchStats.dowN[7]` / `dowTouch[7]`, Sunday = 0 … Saturday = 6) and broken down by the Statistics module — but a per-day figure is only ever displayed with its own N. A "Monday 80%" from 5 Mondays is not the same evidence as an "80%" from 100 days.

## 10. What a probability is NOT

- **Not a prediction.** A 72% touch frequency over the last 100 days is a statement about those 100 days. It does not say today will touch, and it does not say the next 100 days will look like the last 100. Markets change; the sample does not know that.
- **Not a trade signal.** A high touch probability for PDH does not mean "buy at PDH" or "sell at PDH". A touch says price reached the level; it says nothing about what happened next — rejection, breakout, or chop. The indicator never converts a probability into an order, and no probability threshold in the code places, modifies, or closes a trade.
- **Not profitability.** Forecast accuracy and trading profitability are different quantities, measured in different files. A correct touch forecast says nothing about entry, spread, slippage, position size, or whether a trade at that level would have made money. The Statistics module's header states this on its first page, and every label and exported file in the module says so. Separating the two is a design requirement (spec §12), not a footnote.
- **Not precise at small N.** §6.2 shows the interval at the minimum sample. A probability without its N and interval is an incomplete number; the code refuses to display one.

## 11. Divergences and known limitations (recorded honestly)

1. **Forecast PDH/PDC window is 24 hours, live PDH is 21.** `FBPI_Liquidity_ForecastLevel()` reconstructs the previous day's PDH/PDL/PDC from a full 24-hour window starting at that day's start (`s` to `s + 86400`), while `FBPI_MarketStructure` builds the live PDH from the [00:00, 21:00) trading-day window. A forecast PDH can therefore include a high printed between 21:00 and 24:00 UTC that the live PDH would never contain. The evaluation window still ends at the 21:00 cutoff, so the extra three hours affect only the *level*, not the *test window*. This is a real inconsistency between the two modules; it should be reconciled (both to the 21-hour window) before Test 8 results are treated as final.
2. **Day anchors differ between modules.** MarketStructure builds its windows from true UTC epoch arithmetic (`TimeGMT()`-based). Liquidity's `DayAnchors()` and the Statistics module compute "UTC midnight" as `(TimeCurrent() / 86400) × 86400` — but `TimeCurrent()` is broker time, so that midnight is broker midnight, not UTC midnight. At `InpBrokerGMTOffset` = 0 the two agree exactly; at any other offset they differ by the offset, and the probability engine's day boundaries, forecast times, and finalisation days are broker-midnight anchored while the structure module's are UTC anchored. The scoreboard's `day_start_hour_utc` column records the configured day-start hour, not the anchor actually used. Test 12 must be run with the broker offset in force, and this divergence must be resolved or explicitly accepted before multi-offset results are compared.
3. **No `historyShort` flag field exists in the code.** Architecture §4.6 describes a flag so the dashboard can show "history too short". The code signals short history only through `eligible < lookback`. Functionally equivalent for a reader who checks N; not the named flag the Architecture document describes.
4. **Spread-adjustment points are not frozen.** At finalisation the Statistics module uses the *current* `InpSpreadAdjPoints` (Statistics D-5); the CSV records the touch *method* but not the adjustment points. If the user changes the adjustment between capture and finalisation, the finalised outcome is tested with the new value while the frozen forecast was computed with the old one. The frozen touch method always governs the test shape; the points do not.
5. **Settings changes continue the same file.** Architecture §6.1 says a settings change starts a new versioned file. The Statistics module records deviation D-4: Storage exposes header validation but no settings-comment getter, so a settings change that keeps the same 21-column header continues the same file. A header mismatch still forks to a versioned file (`_v2`, `_v3`, …).
6. **Late-issued forecasts have no CSV column.** `forecast_time` is the nominal time (the trading-day start); `lateIssued` is true when capture happens more than 1 hour (`FBPI_STAT_LATE_SECONDS` = 3600) after the day start, and is recorded only in the terminal log at write time (Architecture divergence D-2). A reader of the CSV alone cannot tell a late-issued row from an on-time one.
7. **Calibration bins differ from the Architecture document** (§9 above).
8. **Live-terminal verification outstanding.** No probability in this document has been checked against a live terminal. Tests 8 and 12 remain CANNOT-VERIFY-WITHOUT-TERMINAL until run on the user's laptop after MetaEditor compile. In particular, the PDC regression check (§2.2) must be performed live: a PDC probability of 100% with a real sample size means the engine is broken.
