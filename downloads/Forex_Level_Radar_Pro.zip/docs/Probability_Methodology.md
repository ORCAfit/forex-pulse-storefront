# Forex Level Radar Pro — Probability Methodology

| Field | Value |
|---|---|
| Project ID | FLR-MT4-001 |
| Product | Forex Level Radar Pro |
| Platform | MetaTrader 4 (MT4) |
| Language | MQL4 |
| Version | 1.0 |
| Status | Phase 1 — Design Authority |
| Companion document | `Technical_Specification.md` (system architecture and implementation authority) |
| Source spec | `../FLR-MT4-001-spec.md` |

> **Authority rule.** This document is the mathematical authority for every
> probability, interval, and score in Forex Level Radar Pro. The
> `Technical_Specification.md` states *how* the engine implements these
> definitions; this document states *what* they mean. Where the two disagree,
> the more restrictive (no-look-ahead, no-repaint) reading governs, and the
> discrepancy must be resolved by amending both documents before code is changed.
>
> A probability in this system is a **descriptive historical frequency**: the
> share of comparable past observations in which price touched a level. It is
> not a prediction that price will touch the level today, not a trading signal,
> and not a guarantee of any kind.
>
> **Errata (2026-11-27).** The neutral-level touch rule in §2 and §16
> originally read "`High >= level` **or** `Low <= level`". That was wrong:
> for any bar, one of those two is always true (if `High < level` then
> `Low <= High < level`), so the rule as written would count every bar as
> a touch and every neutral-level probability would be 100%. The correct
> rule — and the one the code implements (`TouchInWindow()`,
> `BarTouchesLevel()`, and the live-status check in
> `CalcProbabilities()`) — is **AND**: the bar's range must contain the
> level, `High >= level` **and** `Low <= level` (under the Close method,
> `|Close − level| <=` the spread adjustment). A neutral level can be
> touched from either side, but one side alone is not a touch. See Test
> Report F2 and the matching errata in `Technical_Specification.md` §7.

---

## 1. What a probability means here

For a level `L` (e.g. PDH — Previous Day High) and a conditioning set `C`
(e.g. "EURUSD, London session, Tuesdays"), the touch probability is:

```
P_touch(L, C) = (number of eligible observations in C where price touched L)
                ÷ (total number of eligible observations in C)  ×  100
```

An **observation** is one trading day (see §3). An observation is a
**touch** (success, outcome = 1) if price reached the level at least once
inside the observation's evaluation window, under the touch rule of §2.
Otherwise it is a **miss** (outcome = 0).

Example — the display example from the source spec:

> `PDH | 1.08750 | 72% | N=100`
>
> means: in the 100 eligible observations counted, price touched the
> previous day's high on 72 of them, before the evaluation cutoff. It does
> **not** mean there is a 72% chance price will touch PDH today in any
> causal or predictive sense. It means 72% of comparable past days did.

Three consequences follow from this definition and are enforced throughout
the system:

1. **A probability without its sample size is meaningless.** 72% from
   N=100 and 72% from N=18 are not the same evidence. The system never
   displays one without the other (§6).
2. **A probability is always conditional.** It is conditional on the pair,
   the level, the session, the day of week, and the lookback that produced
   it. Quoting "the probability" without those conditions is an error.
3. **A probability is backward-looking.** It summarises the past. Whether
   the past resembles today is a judgement the indicator does not make.

---

## 2. Touch definition

A touch is evaluated on **closed bars only**, inside the evaluation window
`[forecastTime, cutoffTime]` for that observation (see §5 for what those
moments are).

| Level direction | Touch condition (Bid basis, default) |
|---|---|
| Upward — a high: PDH, ONH, Asian High, London High, New York High, ORH | `High >= level` |
| Downward — a low: PDL, ONL, Asian Low, London Low, New York Low, ORL | `Low <= level` |
| Neutral — an open or close: PDC, PDO, DO, London Open, New York Open | `High >= level` **and** `Low <= level` (the bar's range must contain the level) |

Rules (normative, shared with `Technical_Specification.md` §7):

1. **Equality counts.** `High == level` is a touch. Floating-point
   comparison uses an epsilon of half a point (`_Point / 2`).
2. **Wick touches count.** Only the high/low needs to reach the level; the
   close does not need to cross it. A touch is not a breakout (see §10).
3. **First touch time** is the open time of the first bar satisfying the
   condition in the window. Later touches in the same window do not change
   the outcome.
4. **One touch per observation.** An observation contributes at most one
   success to the numerator, however many bars touch the level that day.
   Counting bars instead of days would inflate the probability and is
   prohibited.
5. **Spread adjustment.** The default method is Bid-only (no spread
   adjustment), so a historical probability is exactly reproducible from
   the bar history alone. The two optional methods are defined in §7 and
   must be disclosed wherever they are used; a probability computed with
   one method must never be compared with an outcome computed with another.

---

## 3. Eligibility rules — which observations count

A day enters the denominator only if **all** of the following hold.
A day that fails any rule is excluded entirely: it counts neither as a
touch nor as a miss, and it does not consume a lookback slot (§4).

| # | Rule | Rationale |
|---|---|---|
| E-1 | **Complete data.** The day must have bars covering its source window(s): the full trading day for daily levels, the full session window for session levels. A day with a hole in the relevant window (history gap, holiday short session, terminal offline) is ineligible for that level. | A missing bar could have contained the touch. Counting the day as a miss would understate the probability; counting it as a touch would invent data. |
| E-2 | **Level existed and was known.** The level being evaluated must have existed at the observation's forecast time, computed only from data available then. A day whose PDH could not be computed (no previous-day bars) is ineligible for PDH. | A probability must be computable in real time, at the moment it would have been shown. |
| E-3 | **Only observations available at forecast time.** For a forecast issued at time `T`, only observations whose evaluation window **ended before `T`** are eligible. An observation still in progress at `T` is not eligible. | This is the no-look-ahead rule. It is the single most important rule in this document. |
| E-4 | **No future candles.** No bar with open time at or after `T` may contribute to a probability shown at `T`, in any way: not to the level, not to the touch count, not to the denominator. | Same rule as E-3, stated separately because it is violated most often by accident (e.g. by using the current day's high while computing "history"). |
| E-5 | **One observation per trading day per level.** Each trading day contributes at most one observation for a given level and conditioning set. | Prevents double-counting from overlapping sessions (London overlaps Asian 07:00–09:00 UTC; New York overlaps London 12:00–16:00 UTC). The overlap is real, but a day is still one observation. |
| E-6 | **Same conditioning.** An observation counts only if it matches the conditioning set exactly: same symbol, same level, same session, same day-of-week bucket (or the "all days" bucket — see §9), same price basis, same touch method. | Pooling across conditions that differ systematically (e.g. Mondays vs. Fridays, Asian vs. New York) produces a number that describes no real situation. |
| E-7 | **No manufactured data.** Missing bars are never interpolated, synthesised, or filled with another pair's or another timeframe's data. A day with missing data is excluded under E-1. | The source spec is explicit: "Do not manufacture missing data." |

**Worked check — E-3/E-4 in practice.** Suppose today is Friday 2026-11-27
and the forecast time is 00:00 UTC. The lookback walks backwards:
Thursday 2026-11-26 (complete — eligible), Wednesday 2026-11-25 (complete
— eligible), …, and it stops before today, because today's outcome is not
yet known. Today's developing price action contributes nothing to today's
forecast. Today's outcome will be eligible for *future* forecasts only,
once its evaluation window has closed.

---

## 4. Lookbacks

| Lookback | Meaning |
|---|---|
| 20 trading days | The most recent 20 **eligible** trading days |
| 50 trading days | The most recent 50 eligible trading days |
| 100 trading days (**default**) | The most recent 100 eligible trading days |
| 200 trading days | The most recent 200 eligible trading days |
| Custom | Any integer in [5, 500] via `InpLookbackDays` |

Rules:

- **Eligible days only.** Walk backwards from the forecast time, count only
  days passing §3, stop at N. Ineligible days do not consume a slot. This
  means a "100-day lookback" may span more than 100 calendar days if some
  days were ineligible.
- **Trading days, not calendar days.** Weekends have no bars and are never
  observations. The sampling method is `TradingDays` by default
  (`InpSamplingMethod`); the `CalendarDays` alternative is defined in the
  Technical Specification §13.4 and is not recommended, because it counts
  a day with no trading as a miss.
- **Short vs. long lookbacks.** A 20-day lookback reacts faster to recent
  regime change but has a wide confidence interval (§8). A 200-day
  lookback is more stable but may include a market regime that no longer
  applies. Neither is "correct"; the dashboard shows the selected
  lookback, and the scoreboard records which lookback produced each
  forecast, so the two can be compared honestly.
- **Changing the lookback** recomputes all probabilities from the same bar
  history. It never changes a finalised scoreboard row: a forecast scored
  under a 100-day lookback stays a 100-day forecast forever.

---

## 5. Forecast definition and evaluation cutoff

### 5.1 What a forecast is

A **forecast** is a single dated statement:

> "At [forecast time], for [symbol] [level], the historical touch
> probability is [P]% (N=[n], lookback=[L] days), to be evaluated by
> [cutoff time]."

The forecast's probability is **frozen** at forecast time. Later bars may
change the level's live status (Waiting → Hit) but never the frozen
probability, and never the sample behind it.

### 5.2 Forecast times and cutoffs (normative)

| Forecast type | Forecast time | Evaluation cutoff (default) |
|---|---|---|
| Daily levels (PDH/PDL/PDC/PDO/DO/ONH/ONL) | Trading-day start (`InpDayStartHourUTC`, default 00:00 UTC) | **21:00 UTC** same trading day (New York close) |
| Asian session levels (ASH/ASL) | Asian session start (00:00 UTC) | Asian session end (09:00 UTC) |
| London session levels (LSH/LSL/LSO) | London session start (07:00 UTC) | London session end (16:00 UTC) |
| New York session levels (NYH/NYL/NYO) | New York session start (12:00 UTC) | New York session end (21:00 UTC) |
| Opening range (ORH/ORL) | End of the opening-range window | New York session end (21:00 UTC) |

- The daily cutoff is configurable via `InpEvaluationCutoffUTC`
  (default `21:00`). Session cutoffs always equal their session end.
- **Outcome:** `1` if the level is touched (§2) at any time in
  `[forecastTime, cutoffTime]`; otherwise `0`. A touch after the cutoff
  does not change the outcome. A touch before the forecast time does not
  count.
- **One forecast per level per trading day.** Key
  `(symbol, tradingDay, level, session)`. Refreshing the dashboard,
  restarting the terminal, or changing timeframe must not create a second
  forecast for the same key.
- **Late issue.** If the terminal was off at forecast time, the forecast
  is emitted on the first bar after startup, computed **only from bars
  available at the original forecast time**, and marked `lateIssued`.
  It is scored normally.

### 5.3 Why the cutoff matters

Without a cutoff, "price touched the level" is nearly always true given
enough time, and every probability would drift towards 100%. The cutoff
is what makes the statement testable: a 72% forecast means "72% of
comparable days touched the level **before 21:00 UTC**". Change the cutoff
and the probability changes — which is why the cutoff is part of the
forecast's identity and is stored with every scoreboard row.

---

## 6. Minimum sample size and INSUFFICIENT DATA

- **Minimum sample size:** `InpMinSampleSize`, default **20**, range [5, 100].
- If `observations < InpMinSampleSize`, **no probability is displayed as a
  number**. The display shows `INSUFFICIENT DATA`, the record's category
  is `INSUFFICIENT DATA`, and the stored probability is left undefined
  (sentinel `-1.0`, never displayed).
- No forecast is written to the scoreboard for a level with insufficient
  data on that day. An unmeasured forecast cannot be scored; the day is
  skipped for that level, not scored as a miss.
- The minimum applies per conditioning set: a level may have sufficient
  data overall (N=100, all days) but insufficient data for Tuesdays alone
  (N=14) — in that case the Tuesday-conditioned probability shows
  `INSUFFICIENT DATA` while the all-days probability is shown normally.
- Insufficient data is a normal state at the start of available history and
  on thinly traded symbols. It is not an error and not a zero.

**Why 20?** With N=20, the Wilson 95% interval for a 50% estimate is
roughly ±22 percentage points (§8) — already wide. Below 20, the interval
is so wide that the point estimate misleads more than it informs. The
minimum is configurable, but lowering it below 10 is discouraged and the
interval must still be shown whenever a probability is shown.

---

## 7. Probability categories

| Probability | Category | Dashboard colour |
|---|---|---|
| 80–100% | Very High | Green (dark green fill) |
| 65–79% | High | Green (light green fill) |
| 50–64% | Moderate | Yellow |
| 30–49% | Low | Red (light red / amber-red fill) |
| 0–29% | Very Low | Red (dark red fill) |
| Insufficient data | INSUFFICIENT DATA | Grey |

- The categories are **descriptive labels** for a historical frequency,
  not guarantees and not trading advice. A "Very High" level has been
  touched on 80–100% of comparable past days; it may still not be touched
  today.
- Boundaries are configurable (`InpCatVeryHigh` = 80, `InpCatHigh` = 65,
  `InpCatModerate` = 50, `InpCatLow` = 30 by default) but must stay
  strictly decreasing; the names must not be renamed.
- A probability is assigned to exactly one category by its value; the
  boundary value belongs to the higher category (80% is Very High,
  65% is High, 50% is Moderate, 30% is Low).

---

## 8. Per-level, per-session, and per-day-of-week conditioning

Probabilities are computed **separately** for each combination of:

1. **Currency pair** — EURUSD's PDH probability is computed from EURUSD
   bars only. Never pool pairs.
2. **Individual key level** — PDH, PDL, ONH, ORH, etc. are separate
   series. Never pool levels: a level above price and a level below price
   have different touch mechanics and different base rates.
3. **Trading session** — the session conditions *which* evaluation window
   the probability refers to (§5.2). A PDH probability evaluated by the
   London close is a different number from a PDH probability evaluated by
   the New York close, and both are stored with their cutoff.
4. **Day of the week** — probabilities may be conditioned on the trading
   day's day of week (Monday–Friday; Saturday/Sunday have no Forex trading
   day under the default calendar). The dashboard's default view is the
   **all-days** probability (all eligible days pooled, regardless of
   weekday). A day-of-week view (e.g. "PDH on Tuesdays") is a separate
   record with its own N, and shows `INSUFFICIENT DATA` when its own N is
   below the minimum (§6) — which happens often, since a 100-day lookback
   contains only ~20 Tuesdays.
5. **Time of day** — time-of-day conditioning is expressed through the
   session and the forecast time, not as a separate free parameter. There
   is no additional "hour of day" conditioning set in v1.0.
6. **Historical lookback** — see §4. The lookback is part of the
   conditioning and is recorded with every forecast.

**Conditioning and sample size trade off against each other.** Every
additional condition slices the sample thinner. The system therefore
always shows N alongside the probability (§1) and always shows the Wilson
interval (§9), so a thinly conditioned estimate is visibly uncertain.

---

## 9. Spread adjustment

The default touch method is **Bid-only** (`TOUCH_BID_ONLY`): levels are
computed from Bid bars and touches are evaluated on Bid High/Low. This
makes every historical probability exactly reproducible from the bar
history alone.

Two optional methods exist:

| Method | Upward touch | Downward touch | When to use |
|---|---|---|---|
| `TOUCH_BID_ONLY` (default) | Bid `High >= level` | Bid `Low <= level` | Default. Reproducible. |
| `TOUCH_SPREAD_ADJUSTED` | Bid `High >= level + spread` | Bid `Low <= level − spread` | When the user wants the probability that price moved far enough past the level for a Bid-side fill to have been executable at the Ask. `spread` is the symbol's **current** spread in price units, used as a constant for the whole lookback (the historical spread per bar is not recoverable in MT4). This approximation is disclosed on the dashboard whenever the method is active. |
| `TOUCH_ASK_BASED` | Ask `High >= level`, where Ask High = Bid High + spread | Ask `Low <= level`, where Ask Low = Bid Low + spread | When the user wants levels and touches evaluated on the Ask series. Every level price is shifted up by the current spread relative to the Bid series. |

Rules:

- The touch method and price basis in force are recorded in every
  probability record and every scoreboard row. A scoreboard must never mix
  methods silently.
- Spread adjustment **lowers** upward-touch probabilities and **lowers**
  downward-touch probabilities relative to Bid-only, because the bar must
  travel further. If enabling spread adjustment raises a probability, the
  implementation is wrong.
- The spread used is the current spread at evaluation time. It is a
  single number, not a per-bar series, and the methodology does not pretend
  otherwise.

---

## 10. Confidence intervals — Wilson score interval

Every probability is reported with a **Wilson score interval** (95%,
z = 1.96). The Wilson interval is used instead of the normal
("Wald") approximation because the Wald interval performs badly for small
N and for probabilities near 0% or 100% — exactly the cases this indicator
produces (a level touched on 19 of 20 days is 95%, where the Wald interval
would exceed 100%).

### 10.1 Formula

Let `p̂ = touches / N` (as a proportion, 0–1), `N` the number of eligible
observations, and `z = 1.96` for 95% confidence.

```
denominator = 1 + z²/N
centre      = (p̂ + z²/(2N)) / denominator
halfWidth   = z × sqrt( p̂(1 − p̂)/N + z²/(4N²) ) / denominator

lower = centre − halfWidth
upper = centre + halfWidth
```

Report `lower × 100` and `upper × 100` as percentages, to one decimal
place, clipped to [0, 100]. The interval is stored as
`wilsonLowerPct` / `wilsonUpperPct` in every probability and scoreboard
record.

### 10.2 Worked example — PDH 72/100

`p̂ = 0.72`, `N = 100`, `z = 1.96`, `z² = 3.8416`.

```
denominator = 1 + 3.8416/100 = 1.038416
centre      = (0.72 + 3.8416/200) / 1.038416
            = (0.72 + 0.019208) / 1.038416 = 0.7118
halfWidth   = 1.96 × sqrt(0.72×0.28/100 + 3.8416/40000) / 1.038416
            = 1.96 × sqrt(0.002016 + 0.000096) / 1.038416
            = 1.96 × 0.04597 / 1.038416 = 0.0868

lower = 0.7118 − 0.0868 = 0.625  →  62.5%
upper = 0.7118 + 0.0868 = 0.799  →  79.9%
```

Result: **72% (95% Wilson interval 62.5%–79.9%, N=100).** The correct
reading is: "On 72 of the last 100 comparable days price touched PDH
before the cutoff; given the sample size, the underlying rate is plausibly
between about 62% and 80%."

### 10.3 Worked example — same rate, small sample

PDH touched on 14 of 20 days: `p̂ = 0.70`, `N = 20`.

```
denominator = 1 + 3.8416/20 = 1.19208
centre      = (0.70 + 3.8416/40) / 1.19208 = 0.6677
halfWidth   = 1.96 × sqrt(0.70×0.30/20 + 3.8416/1600) / 1.19208
            = 1.96 × sqrt(0.0105 + 0.002401) / 1.19208 = 0.1868
lower = 48.1%   upper = 85.5%
```

Result: **70% (95% Wilson interval 48.1%–85.5%, N=20).** Same headline
rate as a 70/100 case would give, but the interval is nearly twice as wide.
This is why the interval must be shown: without it, 70% from N=20 looks
as solid as 70% from N=100, and it is not.

### 10.4 What the interval is and is not

- It quantifies **sampling uncertainty**: how much the estimate would
  wobble if a different sample of the same size had been drawn from the
  same underlying process.
- It does **not** quantify regime change, broker differences, or whether
  the past resembles today. A narrow interval around a stale estimate is
  still a stale estimate.
- It is **not** a prediction interval for today. It says nothing about the
  probability that today's outcome is a touch; it describes the
  uncertainty of the historical rate.

---

## 11. Worked numeric examples

### 11.1 PDH — the headline example (72/100 = 72%)

Setup: EURUSD, PDH, daily forecast, forecast time 00:00 UTC, cutoff
21:00 UTC, lookback 100 eligible trading days, Bid-only touches.

| Quantity | Value |
|---|---|
| Eligible observations (N) | 100 |
| Touches | 72 |
| Misses | 28 |
| Probability | 72 / 100 × 100 = **72.0%** |
| Category | High (65–79%) |
| Wilson 95% interval | **62.5%–79.9%** (§10.2) |
| Display | `PDH \| 1.08750 \| 72% \| N=100 \| Waiting` |

### 11.2 PDL — a low-probability level (31/100 = 31%)

Setup: same, PDL.

| Quantity | Value |
|---|---|
| Touches / N | 31 / 100 |
| Probability | **31.0%** |
| Category | Low (30–49%) |
| Wilson 95% interval | 22.8%–40.6% |
| Display | `PDL \| 1.08120 \| 31% \| N=100 \| Waiting` |

Note that 31% is not "price will probably not touch PDL": it is "price
touched PDL on 31 of the last 100 comparable days". The interval shows the
rate is plausibly as low as ~23% or as high as ~40%.

### 11.3 Insufficient data (11/14 — not shown)

Setup: GBPJPY, ORH, Tuesdays only, lookback 100 days → only 14 eligible
Tuesdays.

| Quantity | Value |
|---|---|
| Touches / N | 11 / 14 |
| Probability | **Not displayed.** 14 < minimum sample 20 |
| Display | `ORH \| — \| INSUFFICIENT DATA \| N=14` |

The arithmetic (11/14 = 78.6%) is not shown, because showing it would
invite treating a 14-observation slice as a reliable estimate. The
all-days ORH probability (N=100) is shown normally alongside it.

### 11.4 A touch that is not a breakout

EURUSD, PDH = 1.08750. During the day, a 1-hour candle prints
High 1.08790, Close 1.08710.

- **Touch:** yes — High (1.08790) >= PDH (1.08750). Outcome = 1.
- **Breakout:** no — the candle closed below PDH. This is a wick excursion
  (§12), not a breakout.
- The probability engine records a touch; the liquidity engine separately
  evaluates the excursion as a potential sweep (§12).

### 11.5 Lookback comparison

Same level, same day, different lookbacks (illustrative counts):

| Lookback | Touches / N | Probability | Wilson 95% interval |
|---|---|---|---|
| 20 days | 15 / 20 | 75.0% | 53.1%–88.8% |
| 50 days | 34 / 50 | 68.0% | 54.2%–79.2% |
| 100 days | 72 / 100 | 72.0% | 62.5%–79.9% |
| 200 days | 138 / 200 | 69.0% | 62.3%–75.0% |

The point estimates cluster around 68–75%, but the intervals tell the real
story: the 20-day estimate could plausibly be anywhere from 53% to 89%.
The dashboard shows one lookback at a time (the selected one) and records
which one produced each forecast, so this comparison is available in the
scoreboard rather than silently blended into a single number.

---

## 12. Sweep vs. breakout vs. failed breakout — classification logic

(Implementation detail is in `Technical_Specification.md` §8; this section
states the statistical meaning of each class.)

Let `L` be a level and consider the upward case. The downward case is the
mirror image.

| Observation on closed candles | Classification | Statistical meaning |
|---|---|---|
| Wick beyond `L` (`High > L`), close back inside (`Close < L`), no close beyond `L` | **Buy-side liquidity sweep** (`EVENT_SWEEP_BUY`) | Price probed above the level and was rejected there, at least for the confirmation window. The level held as resistance on a closing basis. |
| Close beyond `L` (`Close > L`), and the next `InpBreakoutConfirmBars` candles (default 1) also close beyond `L` | **Breakout up** (`EVENT_BREAKOUT_UP`) | Price accepted above the level on a closing basis. The level did not hold. |
| Close beyond `L`, then a close back inside (`Close <= L`) within `InpFailedBreakoutBars` candles (default 3) | **Failed breakout up** (`EVENT_FAILED_BREAKOUT_UP`) | Price closed beyond the level but could not stay there. Distinct from a sweep: the close *did* go beyond, so it was a breakout that failed, not a wick rejection. |
| Touch exactly (`High == L`), never beyond | **No event** | A touch (§2), not an excursion. |
| Excursion still inside its confirmation window | **No event yet** | Unresolved. Never shown as a final event. |

Rules:

- **A sweep and a breakout are mutually exclusive for one excursion.**
  Once a candle closes beyond the level, the sweep path is closed for
  that excursion; once a candle closes back inside without any close
  beyond, the breakout path is closed.
- **No event is labelled manipulation.** The words "manipulation",
  "stop hunt", and "smart money" appear nowhere in the indicator, its
  dashboard, or its exports. A sweep is a price event with a defined
  shape, not an attribution of intent.
- Each event records excursion size in pips and follow-through over
  `InpFollowThroughBars` (default 3) bars after confirmation, so the
  user can study whether sweeps and breakouts behaved differently
  *after* classification — without that follow-through being part of the
  classification itself (which would be look-ahead inside the classifier).
- Classification uses **only the level as known at the time of the
  excursion**. If a provisional session level later moves, the event is
  not reclassified.

---

## 13. Scoreboard evaluation — Brier score

### 13.1 Definition

For `N` finalised forecasts, let `fᵢ` be the forecast probability as a
proportion (0–1) and `oᵢ` the outcome (1 = touched, 0 = not touched):

```
Brier score = (1/N) × Σ (fᵢ − oᵢ)²
```

Range 0 (perfect) to 1 (worst possible). A constant 50% forecast scores
0.25 regardless of outcomes. A constant forecast equal to the base rate
`ō` (the "climatology" forecast) scores `ō(1 − ō)`.

### 13.2 Worked example

Five PDH forecasts, all at 70% (`f = 0.70`), outcomes: touched, touched,
missed, touched, missed → `o = 1, 1, 0, 1, 0`.

```
(0.70−1)² = 0.09
(0.70−1)² = 0.09
(0.70−0)² = 0.49
(0.70−1)² = 0.09
(0.70−0)² = 0.49
Sum = 1.25   Brier = 1.25 / 5 = 0.2500
```

The Brier score is 0.25 — exactly the score of a constant 50% forecast —
even though the forecast (70%) and the actual touch rate (60%) look close.
The Brier score penalises *overconfidence*: forecasting 70% and being
wrong costs 0.49 per miss, while forecasting 50% and being wrong costs
0.25. That penalty is the point: it rewards forecasts that are honest
about their uncertainty.

### 13.3 Worked example — well-calibrated vs. overconfident

Ten forecasts at 70%, seven touches (actual rate 70% — perfectly
calibrated on average):

```
7 × (0.70−1)² = 7 × 0.09 = 0.63
3 × (0.70−0)² = 3 × 0.49 = 1.47
Brier = 2.10 / 10 = 0.2100
```

Ten forecasts at 90%, seven touches (same outcomes, overconfident):

```
7 × (0.90−1)² = 7 × 0.01 = 0.07
3 × (0.90−0)² = 3 × 0.81 = 2.43
Brier = 2.50 / 10 = 0.2500
```

The overconfident forecaster scores worse despite the same number of
correct directional calls, because the three misses were confidently
wrong. The Brier score is the scoreboard's primary headline metric for
exactly this reason: it measures the quality of the *probabilities*, not
just the hit rate.

### 13.4 Brier skill vs. climatology

```
Brier_climatology = ō × (1 − ō)      (forecasting the base rate every time)
Brier skill       = 1 − Brier / Brier_climatology
```

Positive skill means the forecasts beat always forecasting the base rate;
zero means no better; negative means worse. This is the fair benchmark:
a level touched 90% of the time is easy to "predict" by always saying
90%, and the skill score gives no credit for that.

### 13.5 What the Brier score does not measure

- **Profitability.** A forecast can have an excellent Brier score and a
  trade based on it can still lose money. The scoreboard measures
  forecast quality only.
- **Usefulness.** A well-calibrated 50% forecast is honest but carries
  little information. Calibration (§14) and the Brier score must be read
  together with the spread of forecasts issued.

---

## 14. Calibration analysis

Calibration asks: *when the indicator said 70%, did the level get touched
about 70% of the time?* A perfectly calibrated system is right about its
own uncertainty; a miscalibrated one is systematically over- or
under-confident.

### 14.1 Method

1. Take all finalised scoreboard rows in the group being analysed
   (overall, per level, per session, per pair, or per day of week — each
   analysed separately, from the same rows).
2. Bin the rows by forecast probability into the five category bins of §7:
   0–29, 30–49, 50–64, 65–79, 80–100.
3. For each bin, compute:
   - `n` — number of forecasts in the bin,
   - mean forecast probability in the bin,
   - actual touch rate in the bin (`touches / n × 100`),
   - difference (mean forecast − actual rate, in percentage points).
4. Display one row per bin. Bins with `n < InpMinSampleSize` are flagged
   `INSUFFICIENT DATA` (their numbers are shown, because they describe
   what happened, but flagged so they are not over-interpreted — see
   Technical Specification §10.3).

### 14.2 Worked example — calibration table

| Forecast bin | n | Mean forecast | Actual touch rate | Difference |
|---|---|---|---|---|
| 80–100% (Very High) | 120 | 87% | 82% | +5 pp (slightly overconfident) |
| 65–79% (High) | 210 | 71% | 68% | +3 pp |
| 50–64% (Moderate) | 260 | 56% | 55% | +1 pp |
| 30–49% (Low) | 180 | 40% | 44% | −4 pp (slightly underconfident) |
| 0–29% (Very Low) | 90 | 18% | 21% | −3 pp |

Reading: the system is close to calibrated — no bin is off by more than
5 points — with a mild tendency to over-forecast at the top and
under-forecast at the bottom (a common pattern: forecasts are slightly
too extreme). A system that said 80–100% but was touched only 50% of the
time would be badly miscalibrated, and no headline Brier score alone would
reveal where the error lived.

### 14.3 Calibration vs. resolution

Calibration (this section) and resolution are different virtues:

- **Calibration** — the forecast probabilities match the observed
  frequencies in each bin.
- **Resolution** — the forecasts separate high-touch days from low-touch
  days (a system that always forecasts the base rate is perfectly
  calibrated and has zero resolution).

The scoreboard reports both: calibration via this table, resolution via
the Brier skill score (§13.4) and the spread of forecasts issued. A good
system needs both.

---

## 15. Assumptions and limitations

### 15.1 Explicit assumptions

| # | Assumption | Why it matters |
|---|---|---|
| A-1 | **The past is a usable reference for the frequencies quoted.** The probability is a summary of past days, and it is only informative about today to the extent that the market regime producing those days persists. | A regime change (central-bank shock, crisis, holiday-thinned liquidity) can make a historically accurate probability wrong for weeks. The indicator does not detect regime change. |
| A-2 | **Bars are a faithful record of price.** High/Low/Close from the broker's history are taken as the price that traded. | Different brokers' histories differ slightly (different liquidity providers, different filtering). The same level can have a slightly different probability on two brokers. |
| A-3 | **Bid bars represent the market for touch purposes.** The default method evaluates touches on Bid High/Low. | A level that was "touched" on Bid may not have been executable at the Ask, and vice versa. See §9 for the spread-adjusted alternative. |
| A-4 | **Trading days are independent observations for the Wilson interval.** The interval (§10) treats each day as an independent draw. | Forex days are not strictly independent (trends persist across days, volatility clusters). The interval is therefore a useful approximation, not an exact statement. It understates uncertainty when days are correlated. |
| A-5 | **Session windows in UTC describe the market's sessions.** Asian 00:00–09:00, London 07:00–16:00, New York 12:00–21:00 UTC are conventional windows, not exchange opening hours. | Forex has no central exchange. The windows are conventions, configurable by the user (§6.2 of the Technical Specification). A user whose broker or strategy uses different session definitions must change them. |
| A-6 | **The evaluation cutoff (21:00 UTC) defines the forecast.** A different cutoff defines a different forecast and a different probability. | Probabilities quoted without their cutoff are not comparable — including with probabilities from this same indicator under a different cutoff setting. |

### 15.2 Limitations

1. **Descriptive, not predictive.** The probabilities describe how often
   price touched a level on comparable past days. They are not a model of
   why price moves, and they carry no causal claim. A 72% historical rate
   does not cause, and does not guarantee, a touch today.
2. **Forecast accuracy ≠ trading profitability.** A level-touch forecast
   can be correct (price touched the level) while a trade based on that
   level loses money — through spread, slippage, entry timing, position
   size, or exit. The scoreboard measures forecast quality only. Nothing
   in this system is a trading recommendation.
3. **Small samples mislead.** Conditioning slices the sample thin (§8).
   A day-of-week probability from N=14 is not reliable, which is why it
   is suppressed (§6). Even N=20 has a wide interval (§10.3).
4. **Lookback choice changes the answer.** A 20-day and a 200-day
   probability for the same level can differ by 10 points or more (§11.5)
   without either being wrong — they summarise different pasts. The
   user must know which lookback produced the number they are reading.
5. **Survivorship and availability.** The history available in the
   terminal is the broker's history. Days missing from it are excluded
   (§3, E-1), not reconstructed. If the broker's history is short or
   filtered, the probabilities reflect that history, not the whole market.
6. **No volatility or news adjustment.** The probability does not adjust
   for today's expected volatility, scheduled news, or the distance from
   current price to the level. A level 5 pips away and a level 150 pips
   away can have the same historical probability and very different
   chances of being touched *in the remaining time* — the dashboard shows
   distance and time remaining alongside the probability precisely so the
   reader does not conflate them.
7. **Multiple comparisons.** With 17 level kinds × 5 sessions × 5 weekdays,
   the system computes many probabilities. Some will look extreme by
   chance alone. A single striking number (e.g. "95% on Fridays") should
   be checked against its N and interval before being believed.
8. **The Brier score and calibration are in-sample until the scoreboard
   accumulates out-of-sample forecasts.** Forecasts scored on the same
   history that produced them are not a validation. Honest validation
   requires forecasts issued live (or by replay, Technical Specification
   §14.1) and scored only afterwards — which is what the scoreboard does,
   provided the user does not recompute history and re-score it.

### 15.3 What this methodology does not do

- It does not estimate the probability of a *profitable trade*.
- It does not estimate the probability that price *closes* beyond a level
  (that is a breakout question — see §12 — with its own base rate, not
  the touch probability).
- It does not combine probabilities across levels (the probability of
  touching PDH *or* PDL is not the sum of the two, because the events are
  not mutually exclusive and not independent).
- It does not produce a single "market direction" call. Levels above price
  and levels below price are evaluated separately, and both probabilities
  are shown.

---

## 16. Formula summary (quick reference)

| Quantity | Formula |
|---|---|
| Touch probability | `P = touches / N × 100` |
| Touch (up) | `High >= level` |
| Touch (down) | `Low <= level` |
| Touch (neutral) | `High >= level` and `Low <= level` (bar range contains the level) |
| Wilson 95% interval | §10.1, `z = 1.96` |
| Brier score | `(1/N) Σ (fᵢ − oᵢ)²` |
| Brier skill | `1 − Brier / (ō(1 − ō))` |
| Calibration difference (per bin) | `mean forecast − actual touch rate` (percentage points) |
| Forecast identity | `(symbol, trading day, level, session, lookback, cutoff)` |
| Minimum sample | `N >= 20` (default) or `INSUFFICIENT DATA` |

Defaults (locked in Phase 1, shared with the Technical Specification):
lookback **100** days; minimum sample **20**; daily cutoff **21:00 UTC**;
touch method **Bid-only**; opening range **30 minutes from the New York
open**; sessions **Asian 00:00–09:00, London 07:00–16:00, New York
12:00–21:00 UTC**; trading-day start **00:00 UTC**.

---

## 17. Document control

| Version | Date | Change |
|---|---|---|
| 1.0 | 2026-11-27 | Phase 1 initial issue. Companion: `Technical_Specification.md` v1.0. |
| 1.0 + errata | 2026-11-27 | Neutral-touch rule corrected (OR → AND) in §2 and §16; errata note added. No other change. |

*End of Probability Methodology — FLR-MT4-001 v1.0.*
