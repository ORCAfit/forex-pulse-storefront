# Forex Level Radar Pro — User Manual

| Field | Value |
|---|---|
| Project ID | FLR-MT4-001 |
| Product | Forex Level Radar Pro |
| Platform | MetaTrader 4 (MT4), MQL4 |
| Version | 1.0 |
| Source file | `Forex_Level_Radar_Pro.mq4` |
| Companion documents | `Installation_Guide.md`, `Technical_Specification.md`, `Probability_Methodology.md`, `Technical_Architecture.md`, `Backtesting_Protocol.md`, `Source_Code_Documentation.md` |

> **Read this first — what this tool is and is not.**
>
> Forex Level Radar Pro is an **analytical indicator**. It draws important
> price levels, reports how often price touched those levels on comparable
> past days, watches for liquidity sweeps, and keeps a scoreboard of how
> its own historical frequencies held up. It **never places, modifies, or
> closes trades**, and it never tells you to buy or sell. A probability in
> this system is a **descriptive historical frequency** — "on 72 of the last
> 100 comparable days, price touched this level before the cutoff" — not a
> prediction, not a guarantee, and not a trading signal. Nothing in this
> manual is trading advice. See §9 for the full disclaimer.

---

## 1. What the indicator shows

When attached to a chart, Forex Level Radar Pro draws three things:

1. **Level lines** across the chart — horizontal lines at the key prices,
   each with a text label (`PDH 1.08750`) and its own colour and line
   style.
2. **The dashboard** — a dark panel (322 px wide) in the chart corner with
   the pair, session, market status, current price, the level values, and
   the probability table.
3. **The scoreboard panel** — directly below the dashboard, with the
   running forecast-vs-actual record, a per-level and per-day-of-week
   breakdown, and a calibration table.

Sweep events are marked on the chart with arrows. Everything the indicator
creates is named with the prefix `FLR_` and is removed when the indicator
is removed.

---

## 2. What each level means

There are 17 level kinds. Each is computed from **closed H1 bars** only,
and each is final once its source window has closed — a final level never
moves, however many new bars arrive afterwards.

### 2.1 Daily levels — from the previous trading day

The trading day starts at `InpDayStartHour` **broker time** (default
00:00). "Previous trading day" means the 24 hours before the current
trading-day start.

| Level | Abbrev. | Colour / style | Meaning |
|---|---|---|---|
| Previous Day High | **PDH** | Dodger blue, solid, width 2 | Highest high of the previous trading day. The most-watched upside reference: price above it is in new territory for the day; price returning to it is testing yesterday's extreme. |
| Previous Day Low | **PDL** | Orange-red, solid, width 2 | Lowest low of the previous trading day. The downside mirror of PDH. |
| Previous Day Close | **PDC** | Gold, dashed | Close of the last H1 bar of the previous trading day. A neutral level — it is a price, not a direction. The market's last agreed price before the new day. |
| Previous Day Open | **PDO** | Grey, dotted | Open of the first H1 bar of the previous trading day. |
| Current Day Open | **DO** | White, dotted | Open of the first H1 bar of the current trading day. Final from the first bar of the day and never changes thereafter. |

PDH/PDL/PDC/PDO are final at the start of the current trading day. If the
previous trading day has no H1 bars (short history, holiday), they show
`--` and have no line — they are absent, not zero.

**Prior-day review:** `InpShowPriorDay` (default on) also draws the
*day-before-previous* PDH/PDL/PDC/PDO as faded dim-grey dotted lines
(`FLR_PREV_*`). These never move; they are there so you can see where
yesterday's levels sat relative to the day before.

### 2.2 Overnight / Asian session levels

| Level | Abbrev. | Colour / style | Meaning |
|---|---|---|---|
| Overnight High | **ONH** | Medium purple, dash-dot | In v1.0, the high of the **Asian session so far today** (see note below). |
| Overnight Low | **ONL** | Medium purple, dash-dot | The low of the Asian session so far today. |
| Asian Session High | **ASH** | Aqua, dashed | High of the Asian session window (default 00:00–09:00 UTC). |
| Asian Session Low | **ASL** | Aqua, dashed | Low of the Asian session window. |

> **Implementation note — read this, it differs from the design
> documents.** The Phase 1 specification defines ONH/ONL from a separate
> overnight window (21:00 UTC previous day to 07:00 UTC). In the v1.0
> code, ONH and ONL are computed from exactly the same window as ASH/ASL
> — the Asian session — so **ONH = ASH and ONL = ASL** on every day.
> They are drawn as separate lines (different colour/style) but carry the
> same price. Treat them as one range shown twice, not as two independent
> ranges, until a later version separates them.

Asian levels are provisional while the session is in progress (the running
high/low so far) and final at 09:00 UTC.

### 2.3 London session levels

| Level | Abbrev. | Colour / style | Meaning |
|---|---|---|---|
| London Session High | **LONH** | Lime green, solid | High of the London window (default 07:00–16:00 UTC). |
| London Session Low | **LONL** | Lime green, solid | Low of the London window. |
| London Session Open | **LONO** | Lime green, solid | Open of the first H1 bar in the London window. Final from the first bar of the session. |

### 2.4 New York session levels

| Level | Abbrev. | Colour / style | Meaning |
|---|---|---|---|
| New York Session High | **NYH** | Hot pink, dashed | High of the New York window (default 12:00–21:00 UTC). |
| New York Session Low | **NYL** | Hot pink, dashed | Low of the New York window. |
| New York Session Open | **NYO** | Hot pink, dashed | Open of the first H1 bar in the New York window. Final from the first bar of the session. |

### 2.5 Opening range levels

| Level | Abbrev. | Colour / style | Meaning |
|---|---|---|---|
| Opening Range High | **ORH** | Orange, solid | High of the first `InpOpeningRangeMinutes` (default 30) after the trading-day start. |
| Opening Range Low | **ORL** | Orange, solid | Low of the same window. |

> **Implementation note.** The design documents place the opening range at
> the New York open. In the v1.0 code the opening range starts at the
> **trading-day start** (`InpDayStartHour` broker time, default midnight),
> not at 12:00 UTC. With default settings the "opening range" is the first
> 30 minutes of the trading day. If you want the range to start at the New
> York open, set `InpDayStartHour` to the broker hour corresponding to
> 12:00 UTC — but remember that changes *every* daily level and every
> probability, because the trading-day boundary moves with it. There is no
> separate "opening-range session" input in v1.0.
>
> The duration must be 15, 30, or 60 minutes; `OnInit()` refuses to
> start with any other value, so stay with 15/30/60.

### 2.6 Which levels get probabilities?

Only **seven** levels have probabilities computed and scored: **PDH, PDL,
PDC, ONH, ONL, ORH, ORL**. The other ten levels (PDO, DO, ASH, ASL, LONH,
LONL, LONO, NYH, NYL, NYO) are drawn and monitored for alerts and sweeps,
but they have no probability row and no scoreboard row. This is a v1.0
scope limit, not a display fault.

### 2.7 Hiding levels

Each level kind (or group) has a show/hide input: `InpShowPDH`,
`InpShowPDL`, `InpShowPDC`, `InpShowPDO`, `InpShowDO`, `InpShowONH`,
`InpShowONL`, `InpShowAsianHL`, `InpShowLondonHL`, `InpShowNYHL`,
`InpShowORHL`, `InpShowPriorDay`. Hiding a level removes its line and
label only — its probability, sweep monitoring, alerts, and scoreboard
computation continue unchanged.

---

## 3. Reading the dashboard

The dashboard is 322 px wide, anchored to `InpDashCorner` plus
`InpDashX` / `InpDashY` (default top-left, 10/15). It is **not draggable**
in v1.0 — move it by changing those inputs. Click **[-]** (top right) to
minimise it to the title bar, **[+]** to expand it again, **[x]** to hide
it entirely (re-attach the indicator to bring it back).

### 3.1 Header block

| Field | Meaning |
|---|---|
| PAIR | Chart symbol. |
| TIMEFRAME | Chart timeframe (M1…MN1). Display only — calculations always scan H1 bars. |
| SESSION | Current session: **Asian**, **London**, **New York**, or **Closed**. When sessions overlap, the later-starting session wins: at 13:00 UTC the dashboard says New York, not London. If `InpUseCustomSession` is on and the current UTC hour is inside the custom window, the custom session name is shown instead. |
| MARKET STATUS | **Active** when the current time is inside any configured session window; **Closed** otherwise (including weekends). |
| CURRENT PRICE | Live Bid, to the symbol's digits. |
| DAILY OPEN | DO. |
| PDH / PDL / PDC | Previous-day levels. `--` means no data for that level. |
| ASIAN H/L, LONDON H/L, NY H/L | Session highs/lows. `--` before the session starts. |
| OR H/L (30m) | Opening-range high/low, with the configured duration in brackets. |
| SWEEPS TODAY / BREAKOUTS | Count of sweep events recorded today (max 100, ring buffer) and sustained breakouts counted today. Both reset at the day rollover. |
| CUTOFF 21:00 – remaining H:MM | The evaluation cutoff (`InpCutoffHour` hours after the trading-day start) and the time left until it. Shows `00:00` once the cutoff has passed. |

### 3.2 Probability table

Columns, in order: **LEVEL | PRICE | ODDS | N | STATUS**.

```
LEVEL   PRICE        ODDS   N      STATUS
PDH     1.08750      72.0% (High)  N=100  Waiting
PDL     1.08120      31.0% (Low)   N=100  Hit
PDC     1.08400      58.0% (Moderate) N=100 Waiting
ONH     1.08550      64.0% (Moderate) N=98  Waiting
ONL     1.08200      44.0% (Low)   N=98  Hit
ORH     1.08480      69.0% (High)  N=100  Waiting
ORL     1.08310      52.0% (Moderate) N=100 Waiting
```

- **LEVEL** — the abbreviation.
- **PRICE** — today's level price (`--` if the level does not exist today).
- **ODDS** — the historical touch probability for this level, as a
  percentage with one decimal, plus its category in brackets. The row is
  coloured by category: green for High/Very High, gold for Moderate, red
  (tomato) for Low/Very Low.
- **N** — the sample size behind the percentage. **Never read the
  percentage without the N.** 72% from N=100 and 72% from N=31 are not the
  same evidence.
- **STATUS** — **Waiting** (not yet touched today), **Hit** (touched at
  least once since the evaluation window opened), or **INSUFFICIENT DATA**
  (fewer than `InpMinSample` eligible days — the row then shows `--` for
  the odds instead of a number).

Two footnotes under the table say it plainly: *"Odds are historical touch
rates, not guarantees"* and *"N = sample size. Hit = touched before cutoff
today."*

### 3.3 How a probability is computed (short version)

For a level on day D, the indicator looks back over the last
`InpProbLookback` (default 100) **completed** trading days. For each past
day it reconstructs *that day's* forecast level using only days before it,
then checks whether price touched that level before that day's cutoff.
The probability is touches ÷ eligible days × 100. Today is never in the
sample — today's outcome is not known yet, so it cannot be part of
today's forecast. The full mathematics, eligibility rules, and worked
examples are in `Probability_Methodology.md`; the verification procedure
is in `Backtesting_Protocol.md`.

**Touch rule (v1.0 code):** with the default `InpTouchMethod =
TOUCH_HIGH_LOW`, an upward level is touched when a closed H1 bar's **High
>= level**, a downward level when **Low <= level**, and PDC (neutral) when
the bar's **range contains the level** — `High >= level` **and**
`Low <= level`. With `TOUCH_CLOSE`, the bar's **Close** must reach the
level instead (up: `Close >= level`, down: `Close <= level`, neutral:
`|Close − level|` within the spread adjustment). `InpSpreadAdjPoints`
(default 0.0) widens the touch zone by that many points — an upward level
is then touched at `High >= level − adjustment`, so a positive adjustment
makes touches *easier* to record, not harder. Keep it at 0.0 unless you
understand that direction. Note this differs from the spread-adjusted
method described in the design documents (which requires extra travel past
the level); the code's behaviour governs.

### 3.4 Probability categories

| Probability | Category | Row colour |
|---|---|---|
| ≥ 80% | Very High | Green |
| 65–79% | High | Green |
| 50–64% | Moderate | Gold |
| 30–49% | Low | Red |
| 0–29% | Very Low | Red |
| Fewer than `InpMinSample` observations | INSUFFICIENT DATA | Grey |

Thresholds are configurable (`InpThreshVeryHigh` 80, `InpThreshHigh` 65,
`InpThreshModerate` 50, `InpThreshLow` 30) and must stay strictly
descending; `OnInit()` refuses to start if they are not. The category is a
descriptive label for a historical frequency. A "Very High" level has been
touched on 80–100% of comparable past days; it may still not be touched
today.

### 3.5 What the dashboard does NOT show

- **No Wilson confidence interval.** `Probability_Methodology.md` §10
  defines a 95% Wilson interval for every probability, but v1.0 does not
  compute or display it. Treat a probability from a small N as less
  certain than the same percentage from a large N, and use the sample-size
  rule in §3.2 as your guard.
- **No day-of-week probability on the dashboard.** The code computes
  per-day-of-week touch counts internally, but the dashboard shows only
  the all-days probability. The scoreboard panel shows per-day-of-week
  *actual* touch rates from finalised forecasts (§6).
- **No combined probability.** The probability of touching PDH *or* PDL
  is not the sum of the two — the events are not mutually exclusive. The
  indicator never combines probabilities across levels.

---

## 4. Sweeps, breakouts, and failed breakouts

### 4.1 What the liquidity engine watches

Eight levels are monitored for liquidity events: the four upside levels
**PDH, ASH, LONH, ORH** (buy-side) and the four downside levels **PDL,
ASL, LONL, ORL** (sell-side). The engine watches the **live Bid** against
each level and classifies what happens next, on closed bars.

### 4.2 Sweep — what it means

A **sweep** is recorded when price trades **beyond** a level, then a later
close comes back **inside** it within `InpConfirmBars` (default 3) bars.
Classification happens only once the excursion bar has closed — a sweep
is never recorded while the excursion candle is still forming:

- **Buy-side sweep** (above a high): Bid goes above the level, then a
  close prints back below it. The level held as resistance on a closing
  basis, after a probe above it.
- **Sell-side sweep** (below a low): the mirror image.

When a sweep is recorded, an arrow is drawn on the chart at the extreme
price reached beyond the level: arrow code 234 (up arrow), orange-red, for
a buy-side sweep; arrow code 233 (down arrow), dodger blue, for a
sell-side sweep. The marker object is named `FLR_SWEEP_<slot>` (slot
0–99, ring buffer — the 101st sweep reuses slot 0). The dashboard's
"SWEEPS TODAY" count increments. A sweep alert fires if
`InpAlertSweep` is on (see §7).

### 4.3 Breakout — what it means

A **sustained breakout** is recorded when price closes beyond a level and
**stays** beyond it for `InpBreakoutBars` (default 3) bars. The dashboard's
"BREAKOUTS" count increments. A breakout is explicitly **not** a sweep:
once a close goes beyond the level, the sweep path for that excursion is
closed. Breakouts are counted only — v1.0 draws no breakout marker and
stores no breakout record. The opening-range breakout alert
(`InpAlertORBreakout`) fires only for ORH/ORL breakouts.

### 4.4 Failed breakout — not classified in v1.0

The design documents define a **failed breakout** (close beyond the level,
then a close back inside within a few bars) as a third class, distinct
from a sweep. **v1.0 recognises the shape but does not record it as an
event class.** What the code does:

- If a close goes beyond the level and a later close comes back inside,
  the excursion is a failed breakout, **not** a sweep — the sweep path is
  closed the moment any close goes beyond the level, and the state is
  cleared without recording anything. No failed-breakout marker or
  scoreboard entry is created.
- If price closes back inside *after* the sweep confirmation window
  (`InpConfirmBars`) has expired but *before* the breakout window
  (`InpBreakoutBars`) is satisfied, and no close went beyond, the
  excursion state is dropped silently — no event is recorded at all.

So in v1.0 an excursion has three possible endings: sweep, sustained
breakout, or nothing. Do not look for failed-breakout markers; there are
none.

### 4.5 What a sweep is not

- It is **not** labelled "manipulation", "stop hunt", or "smart money"
  anywhere — in the indicator, the dashboard, or the exports. A sweep is a
  price event with a defined shape, not an attribution of intent.
- It is not a touch. A touch (§3.3) needs only a wick to reach the level
  (`High >= level`); a sweep needs price to go *beyond* it and come back.
  A candle that touches PDH exactly and closes below it is a touch and a
  wick excursion, but the excursion alone is not a sweep until a close
  back inside confirms it within the window.
- A sweep is classified against the level **as known at the time of the
  excursion**. If a provisional session level later moves, the event is
  not reclassified.

---

## 5. The scoreboard panel

The scoreboard sits directly below the dashboard (same X, Y + 566). Click
**[-]** to minimise it, **[+]** to expand, **[Export]** to write the
summary CSV (see below).

### 5.1 Headline figures

| Field | Meaning |
|---|---|
| Total Observations | Number of finalised forecasts (one per level per trading day). |
| Average Forecast | Mean of the forecast probabilities across all finalised rows, in %. |
| Actual Touch Rate | Share of finalised forecasts whose level was actually touched before the cutoff, in %. |
| Forecast − Actual | Average forecast minus actual touch rate, in percentage points. Positive = the forecasts over-estimated touch rates on average; negative = under-estimated. |
| Brier Score | Mean squared error between forecast probability (0–1) and outcome (1 = touched, 0 = not), shown to 4 decimals. 0 is perfect; 0.25 is the score of a constant 50% forecast. It penalises confident wrong forecasts more than cautious ones. See `Probability_Methodology.md` §13 for worked examples. |

### 5.2 Breakdowns

- **Per level** (PDH, PDL, PDC, ONH, ONL, ORH, ORL): observations,
  average forecast, actual touch rate.
- **Per day of week** (Sun–Sat): observations and actual touch rate, from
  finalised forecasts only. Days with no rows show `Obs 0`.
- **Calibration table** (if `InpShowCalibration` is on): forecasts binned
  into 0–29%, 30–49%, 50–64%, 65–79%, 80–100%, with each bin's observation
  count and actual touch rate. A well-calibrated system has each bin's
  actual rate close to its forecast range. See
  `Probability_Methodology.md` §14.

### 5.3 How rows get into the scoreboard

1. At the start of each trading day, the indicator stores that day's
   seven forecast probabilities in memory (with their N).
2. At the next day rollover — and only once that day's cutoff has passed —
   `FinaliseYesterday()` evaluates each level: was it touched before the
   cutoff? Up to one row per level (7 max) is appended to
   `MQL4/Files/FLR_Scoreboard_<SYMBOL>.csv`; levels whose forecast had
   insufficient data that day are skipped, not scored as a miss.
3. A row is never edited or deleted afterwards, and never written twice:
   the key `Date|Level` is deduplicated on insert and on file load.

So the scoreboard grows by up to 7 rows per trading day, appearing the
following morning — not during the day. **Open forecasts are held in
memory only and are not in the CSV.** If the terminal was off at the
rollover, finalisation happens on the first recalculation after restart.

### 5.4 Export

Clicking **[Export]** writes
`MQL4/Files/FLR_Scoreboard_Summary_<SYMBOL>.csv` — a two-column
(Metric, Value) file with the headline figures, per-level figures, and
calibration bins. It overwrites the previous summary each time. The
per-row file is separate and is appended to, never overwritten.

### 5.5 Daily reset

`InpDailyReset` (default **false**) resets only the *displayed* totals
each morning; the CSV file is kept. Leave it off unless you want the panel
to show only the current day's running totals. It does not delete history.

### 5.6 Reading the scoreboard honestly

- The scoreboard measures **forecast quality only**. A forecast can be
  perfectly calibrated and a trade based on it can still lose money
  (spread, entry, size, exit are not part of the forecast). The dashboard
  carries no profitability claim, and neither should you infer one.
- Small groups mislead. A per-level row with 12 observations says almost
  nothing; wait for the counts to grow. The panel flags nothing
  automatically — apply the same minimum-sample judgement as for
  probabilities (§3.2).
- Changing a structural input (day start, cutoff, touch method, lookback)
  changes future forecasts but never rewrites old rows. Rows computed
  under different settings accumulate in the same file. If you change such
  a setting, start a fresh scoreboard (see `Installation_Guide.md` §8.10)
  so you are not scoring two different systems in one table.
- **Brier skill vs. climatology** (forecasting the base rate every time)
  is defined in `Probability_Methodology.md` §13.4 but is **not computed**
  in v1.0. Only the raw Brier score is shown.

---

## 6. Alerts

Alerts are configured in the **Alerts** input group. Each alert type can
be switched on/off, and each delivery channel (popup, sound, push) can be
switched on/off independently. **Every alert is throttled to at most once
per hour per level per alert type** — price sitting near a level will not
spam you.

| Alert | Input | Trigger |
|---|---|---|
| Approach | `InpAlertApproach` (default off) | Live Bid comes within `InpApproachPoints` (default **100 points** — points, not pips: on a 5-digit symbol 100 points = 10 pips) of any of the 17 levels. Message: `FLR Approach: <SYMBOL> within <n> pts of <LEVEL> <price>`. |
| Touch | `InpAlertTouch` (default on) | The **last closed bar** touches a level, tested direction-aware: upward levels by the bar's High, downward levels by its Low, neutral levels by the bar's range containing the level (High/Low method); or the close reaching the level (Close method). Message: `FLR Touch: <SYMBOL> touched <LEVEL> <price>`. |
| Sweep | `InpAlertSweep` (default on) | A sweep is recorded (§4.2). Message includes the level, its price, and the excursion in points. |
| Opening-range breakout | `InpAlertORBreakout` (default off) | A **sustained** breakout of ORH or ORL only (see §4.3). Other levels' breakouts are counted but do not alert. Message: `FLR OR Breakout: <SYMBOL> <LEVEL> <price> - sustained breakout`. |

Delivery channels: `InpAlertPopup` (default on — MT4 `Alert()` window),
`InpAlertSound` (default on — plays `alert.wav` from the terminal's
`Sounds/` folder), `InpAlertPush` (default **off** — requires push
notifications configured in Tools → Options → Notifications with a
MetaQuotes ID). If all three channels are off, an alert is detected and
throttled but never delivered — check the channel inputs before concluding
alerts are broken.

Note the touch alert uses the same direction-aware touch rule as the
probability engine (§3.3): a bar whose high merely reaches an upward level
counts as a touch, and a bar entirely above that level counts too — the
alert fires on the same test the probability engine uses. An approach
alert will usually have fired first.

---

## 7. Daily workflow — the 5 PM-style routine

The indicator is built around one trading day at a time. A practical
daily routine (times in broker time; adapt to your own day start):

### 7.1 At the day start (or when you sit down in the morning)

1. Open the chart and confirm the dashboard is showing today's levels —
   PDH/PDL/PDC from yesterday, DO from today's first bar, ONH/ONL from the
   Asian session so far.
2. Read the probability table. For each level, note the **odds and the N**
   together, and the category. A level at 72% (N=100) is a historically
   frequent touch; a level at 72% (N=31) is the same headline from much
   thinner evidence.
3. Note the **cutoff and time remaining**. The odds only mean anything
   against that cutoff — "72% before 21:00" is a different statement from
   "72% at some point".
4. Note the **distance** implicitly: the dashboard shows the level price
   and the current price side by side. The probability does **not** adjust
   for distance — a level 5 pips away and a level 150 pips away can have
   the same historical probability. Do not conflate the two.

### 7.2 During the day

- Watch STATUS change from **Waiting** to **Hit** as levels are touched.
  A Hit stays a Hit — the outcome is "touched at least once", not "closed
  beyond".
- Watch for sweep arrows (§4.2). A sweep of PDH followed by price staying
  below it is the level holding on a closing basis; a sustained breakout
  (BREAKOUTS count) is the level not holding. Neither is a trade
  instruction.
- If you use alerts, the approach alert is your early warning that price
  is near a level; the touch alert confirms the last closed bar touched
  it under the direction-aware rule (§6).

### 7.3 At the end of the day / next morning

- The scoreboard finalises yesterday's seven forecasts at the rollover
  (after the cutoff). Check the panel the next morning: Total
  Observations should have grown by up to 7, and the per-level actual
  rates should have moved slightly.
- **Marking outcomes is automatic** — there is no manual "mark won/lost"
  step in this indicator. The outcome is the touch test against the
  cutoff, applied by `FinaliseYesterday()`. If a row is missing for a
  level, that level had no forecast (insufficient data that day) or no
  computable level — it is skipped, not scored as a miss.
- Once a week, open the scoreboard CSV and check the calibration table:
  are the 80–100% forecasts actually being touched ~80–100% of the time?
  A persistent gap in one bin is the signal that the historical
  frequencies for that bin are not holding up. That is a fact about the
  forecasts, not a reason to change the inputs mid-stream — changing
  inputs invalidates the comparison (see §5.6).

### 7.4 What not to do daily

- Do not change the lookback, cutoff, or touch method day to day to make
  the numbers look better. Every change restarts the comparability of the
  scoreboard.
- Do not read a single day's Hit/Miss as evidence about a probability.
  One day is one observation; the scoreboard needs dozens before its
  averages mean anything.

---

## 8. Multi-pair scan

The scan is **off by default** (`InpEnableScan = false`). When enabled, a
second panel appears to the right of the dashboard (X + 332) titled
**MULTI-PAIR PDH ODDS**, listing one row per symbol in `InpScanSymbols`
(default the 15 pairs from the spec: EURUSD, GBPUSD, USDJPY, USDCHF,
USDCAD, AUDUSD, NZDUSD, EURGBP, EURJPY, GBPJPY, AUDJPY, CADJPY, CHFJPY,
EURAUD, GBPAUD).

Each row shows that symbol's **PDH probability only**, computed the same
way as the main table's PDH row, but with two scan-specific limits:

- The lookback is **capped at 50 days** for speed, whatever
  `InpProbLookback` says.
- A symbol with fewer than 100 H1 bars, or fewer than 5 eligible days,
  shows `-- (no data)` instead of a number.

Practical notes:

- The scan reads H1 history for every listed symbol. Symbols whose history
  has not been loaded (see `Installation_Guide.md` §5.2) will show no data.
  Load H1 history for each symbol first — open an H1 chart of that symbol
  and scroll back.
- The scan runs on every recalculation (new bar or timer). With 15 symbols
  it is a noticeable but bounded amount of work; if the terminal feels
  sluggish, turn the scan off and check pairs one chart at a time.
- The scan shows PDH only. It does not show PDL, PDC, or any session
  level, and it writes nothing to the scoreboard. To see a pair's full
  table, attach the indicator to that pair's chart.
- You can edit `InpScanSymbols` (comma-separated, up to 30 symbols). Add
  a symbol only if you have its H1 history loaded; remove symbols you do
  not follow to keep the scan fast.

---

## 9. FAQ

**Q: The dashboard says INSUFFICIENT DATA. Is something broken?**
A: No. It means fewer than `InpMinSample` (default 20) eligible days exist
in the lookback. Load more H1 history, or lower the minimum sample. It is
a normal state at the start of available history.

**Q: Why does PDH show a different price from my broker's daily high?**
A: PDH is the high of the *previous trading day* as defined by
`InpDayStartHour` broker time, computed from H1 bars. If your broker's
"daily" candle starts at a different hour, the two will differ. Check the
day-start setting before assuming an error.

**Q: Why is ONH the same price as ASH?**
A: Because in v1.0 they are computed from the same window (see §2.2).
This is a known v1.0 limitation, not a display fault.

**Q: A level was touched, but STATUS still says Waiting.**
A: STATUS is updated on recalculation (new bar or timer, default every 5
seconds). The live check uses the current bar's High/Low and an H1 scan
up to now. If the touch happened on a lower-timeframe wick inside the
current H1 bar, it is visible in the live check only through the current
bar's High/Low — a touch that occurred and reversed within the same H1 bar
on a shorter timeframe is still inside that H1 bar's range, so it will
register. If it does not register after a new H1 bar, check the touch
method input.

**Q: The scoreboard total did not increase this morning.**
A: Rows are appended only after the previous day's cutoff has passed and
the day has rolled over. If the terminal was off, finalisation happens on
the first recalculation after restart. Also check that
`InpEnableScoreboard`, `InpPersistentStorage`, and `InpExportCSV` are all
true — all three gate the append in v1.0.

**Q: Can I move the dashboard by dragging it?**
A: Not in v1.0. Use `InpDashCorner`, `InpDashX`, and `InpDashY` in the
inputs.

**Q: Does the indicator repaint?**
A: Completed levels, frozen forecasts, and finalised scoreboard rows never
change. Provisional levels (a session high/low while the session is still
running) do move — that is their definition, and the dashboard shows them
as the running extreme so far. A sweep or breakout is recorded once and
never revised. See `Backtesting_Protocol.md` for the verification
procedure.

**Q: Can I use it on gold, indices, or crypto?**
A: The code is symbol-agnostic — it scans whatever symbol the chart
shows, and the scan list is editable. It was designed and specified for
the 15 Forex pairs. Other symbols will work mechanically if they have H1
history, but session definitions (Asian/London/New York) are Forex
conventions and may not suit them. No support for non-Forex session
definitions is provided in v1.0.

**Q: Does it work in the Strategy Tester?**
A: No — not usefully. The Strategy Tester is built for Expert Advisors;
indicators cannot be meaningfully backtested in it, and visual mode will
not reproduce the dashboard, the scoreboard file, or the timer behaviour.
Use the manual replay procedure in `Backtesting_Protocol.md` instead.

---

## 10. Disclaimer — read before relying on any number shown

- **Probabilities are descriptive, not predictive.** Every percentage in
  this system is a historical frequency: the share of comparable past
  trading days on which price touched a level before a stated cutoff. It
  is not a prediction that price will touch the level today, not a
  statement about why price moves, and not a guarantee of any kind. A
  "Very High" level may not be touched today; a "Very Low" level may be
  touched in the first hour.
- **Analytical only — it never trades.** The indicator places no orders
  and gives no buy/sell advice. Any trading decision you make using these
  levels is yours alone.
- **Forecast accuracy is not trading profitability.** A level-touch
  forecast can be correct while a trade based on that level loses money
  (spread, slippage, entry, size, exit). The scoreboard measures forecast
  quality only.
- **The past may not resemble today.** Regime changes, news, holidays, and
  broker history differences all affect whether historical frequencies
  hold. The indicator does not detect regime change and does not adjust
  for news or volatility.
- **Sample size matters.** A probability from N=30 is far less certain
  than the same percentage from N=200. v1.0 does not display a confidence
  interval; treat small-N probabilities with corresponding caution.
- **Verify before trusting.** The procedures in
  `Backtesting_Protocol.md` let you check any probability by hand from
  the same history the indicator used. If a hand check disagrees with the
  display, trust the hand check and report the discrepancy — do not trade
  on the display.

---

*End of User Manual — FLR-MT4-001 v1.0.*
