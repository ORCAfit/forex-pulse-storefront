# Forex Level Radar Pro — Backtesting Protocol

| Field | Value |
|---|---|
| Project ID | FLR-MT4-001 |
| Product | Forex Level Radar Pro |
| Platform | MetaTrader 4 (MT4), MQL4 |
| Version | 1.0 |
| Source file | `Forex_Level_Radar_Pro.mq4` |
| Companion documents | `Probability_Methodology.md` (definitions under test), `Technical_Specification.md`, `Technical_Architecture.md`, `User_Manual.md`, `Source_Code_Documentation.md` |

> **Purpose.** This document tells you how to test whether the indicator's
> numbers are right — using only the price history in your own terminal.
> It does not tell you whether the levels are profitable to trade. Those
> are different questions, and this protocol answers only the first one.

---

## 1. Why the Strategy Tester is NOT suitable

Do **not** use MT4's Strategy Tester (Ctrl+R) to backtest this indicator:

1. The Strategy Tester is built for Expert Advisors. An indicator
   attached in visual mode runs under tester conditions that do not
   reproduce the live environment: the timer (`OnTimer()`) does not fire
   the same way, chart objects and the dashboard are not exercised
   faithfully, and file operations in `MQL4/Files/` behave differently
   under the tester's sandboxed file access.
2. The scoreboard is a **live, forward-only** record. A tester run would
   write rows into the same per-symbol CSV as live use, mixing simulated
   history with real finalised forecasts — and the deduplication key
   (`Date|Level`) would then silently refuse the genuine rows when the
   indicator later runs live on the same dates.
3. The tester cannot show you *what the indicator knew at the time*.
   The whole point of this protocol is to reconstruct, for a past day,
   exactly the information available at that day's forecast time. The
   tester hides that behind its own bar feed.

Use the manual procedures below instead. They are slower, but they are the
only procedures that can actually verify the no-look-ahead property.

---

## 2. Prerequisites

- MT4 build 600+, the indicator compiled with 0 errors, attached to an H1
  chart of the symbol under test (see `Installation_Guide.md` §5).
- **H1 history loaded** for the full test window plus the lookback before
  it. For a 30-day test with lookback 100, you need ~130 trading days of
  H1 bars before the test window's end. Verify the bar count before
  starting: scroll the H1 chart back to the start of the test window and
  confirm bars exist there.
- A fixed, written-down configuration for the whole test. Record every
  input that affects the numbers: `InpProbLookback`, `InpMinSample`,
  `InpCutoffHour`, `InpTouchMethod`, `InpSpreadAdjPoints`,
  `InpDayStartHour`, `InpBrokerGMTOffset`, `InpDSTMode`, session hours,
  `InpOpeningRangeMinutes`, and the probability thresholds. Changing any
  of these mid-test invalidates the comparison. **Do not change inputs
  during a test.**
- A spreadsheet (or paper) for the hand-check tables in §4 and §5.

---

## 3. Manual chart scroll-back / replay procedure

This is the primary test. It verifies that the levels and probabilities
the indicator shows for a past day are the ones that were computable at
that day's start.

### 3.1 Setup

1. Attach the indicator to an H1 chart with the frozen test
   configuration. Note the values the dashboard shows **today** (the
   live probabilities and Ns) and write them down.
2. Press **F12** (step forward one bar) is not available for replay in
   MT4 the way it is in some platforms — MT4 has no true bar replay.
   Instead, use **scroll-back inspection**: scroll the chart so that the
   rightmost visible bar is the last H1 bar of the test day, and read the
   indicator's state from the chart at that point. Because the indicator
   recomputes from history on every recalculation, scrolling does not
   change what it computes for the current day — so scroll-back alone
   cannot reproduce "what the indicator showed on that day". That is why
   the hand-check in §4 is the authoritative test, and scroll-back is used
   only for level verification (§3.2), not for probability verification.

### 3.2 Verifying levels by scroll-back (TEST 1 / TEST 2)

For a chosen past trading day D (with the frozen configuration):

1. Identify D's window: `[dayStart, dayStart + 24h)` in broker time,
   where dayStart is the most recent `InpDayStartHour:00` at or before D.
2. Find the previous trading day D−1 in the same way.
3. On the H1 chart, read the highest high and lowest low of the H1 bars
   whose open time falls in D−1, the close of the last such bar, and the
   open of the first such bar. These are, by definition, PDH, PDL, PDC,
   PDO for day D.
4. Compare with the indicator: attach the indicator and read the PDH/PDL/
   PDC lines — but note the indicator always shows the *current* day's
   levels, not D's. To compare for day D you must either (a) do the check
   on the morning of D (live), or (b) reconstruct D's levels by hand from
   the H1 bars as in step 3 and compare them with the levels the
   *probability engine* would have used — which is exactly the §4
   hand-check. In practice: **the hand-check in §4 subsumes the level
   check**, because a wrong level produces a wrong touch count.
5. Session levels: repeat step 3 for the session windows. Convert the UTC
   session hours to broker time using the frozen offset and DST setting,
   then read the H1 high/low/open inside each window. Compare with the
   level values the indicator shows while that session is running (live
   check) or with the values implied by the §4 hand-check.
6. Opening range: read the H1 high/low of the bars whose open time falls
   in the first `InpOpeningRangeMinutes` after D's trading-day start.
   Remember the v1.0 definition: the range starts at the **trading-day
   start**, not at the New York open (see `User_Manual.md` §2.5).

**Pass criterion:** every hand-read level matches the indicator's level
(or the level implied by the hand-check) to the pip — i.e. within the
spread adjustment in force (`InpSpreadAdjPoints`, default 0.0 points:
with the default, equality counts exactly). A mismatch larger than that
is a defect, unless the H1 history has a gap in the window (in which case
the day is ineligible, not wrong — see §4.3).

### 3.3 Verifying the dashboard's live status (TEST 5 — no repainting)

1. Pick a day and note, at the close of each H1 bar, the dashboard STATUS
   for each level (Waiting/Hit) and the level prices.
2. The next day, scroll back and re-read the same levels from history.
   The level prices for the completed day must be identical to what you
   noted. A completed level that has moved is a repainting defect.
3. The probability shown for a day must not change after that day's start:
   note the seven probabilities in the morning, then again in the evening
   — the percentages and Ns must be identical (only STATUS may change,
   Waiting → Hit). If a percentage moves during the day, the forecast was
   not frozen, which is a defect.

---

## 4. Verifying a probability by hand

This is the core of the protocol. It is tedious and it is the only way to
be sure.

### 4.1 Procedure (one level, one day)

Pick a level L (start with PDH), a forecast day D, and the frozen
configuration (lookback N, cutoff, touch method, spread adjustment).

1. **Reconstruct the lookback sample.** Walk backwards from D, day by day,
   for the last `InpProbLookback` *eligible* days (days 1…N before D):
   - For each past day d, reconstruct d's forecast level using **only
     days before d**: for PDH, the high of the H1 bars in the trading day
     before d (d−1). For ONH/ONL, d's Asian session high/low. For ORH/ORL,
     the high/low of the first `InpOpeningRangeMinutes` after d's
     trading-day start.
   - If the level cannot be reconstructed (no H1 bars in the source
     window), day d is **ineligible**: skip it entirely — it counts as
     neither a touch nor a miss, and it does not consume a lookback slot.
     Walk one day further back to replace it.
2. **Evaluate each eligible day.** For day d, check the H1 bars in d's
   evaluation window (see §4.2) for a touch under the frozen touch method:
   - `TOUCH_HIGH_LOW` (default): upward level — any bar with
     `High >= level`; downward — any bar with `Low <= level`; PDC
     (neutral) — any bar whose range contains the level (`High >= level`
     **and** `Low <= level`). With `InpSpreadAdjPoints > 0`,
     the touch zone is widened by that many points (upward:
     `High >= level − adjustment`).
   - `TOUCH_CLOSE`: the bar's **Close** must reach the level (same
     widening rule; neutral: `|Close − level|` within the adjustment).
   - One touch per day maximum, however many bars touch.
3. **Compute.** `P = touches / eligible × 100`. Round to one decimal.
4. **Compare** with the probability the indicator showed for L on the
   morning of D (or, equivalently, the probability it shows now if you
   recompute with the same lookback — the indicator recomputes the same
   sample from the same history, so the number must match). Also compare
   the **N** (eligible count) and the **touch count** — a matching
   percentage with a different N is still a failure, because it means the
   sample differs.

### 4.2 Evaluation windows (frozen configuration, v1.0 code)

| Level | Evaluation window |
|---|---|
| PDH, PDL, PDC | Day start → day start + `InpCutoffHour` hours (capped at the day end) |
| ONH, ONL | Asian session end → day start + `InpCutoffHour` hours |
| ORH, ORL | End of the opening range (day start + `InpOpeningRangeMinutes`) → day start + `InpCutoffHour` hours |

A touch after the cutoff does not count. A touch before the window opens
does not count. For ONH/ONL and ORH/ORL, price action *before* the level
existed cannot be a touch — that is the point of the later window start.

### 4.3 Worked mini-example (PDH, lookback 20)

Suppose lookback 20, cutoff 21:00, `TOUCH_HIGH_LOW`, spread adjustment 0.
For forecast day D = Monday 2026-11-23:

| Past day | d's PDH (high of d−1) | Touched before 21:00 on d? |
|---|---|---|
| Fri 2026-11-20 | 1.16200 | Yes — H1 bar 14:00 High 1.16230 |
| Thu 2026-11-19 | 1.15950 | No — day high 1.15910 |
| Wed 2026-11-18 | 1.15800 | Yes — H1 bar 09:00 High 1.15800 (equality counts) |
| … | … | … |
| (20 eligible days) | | **14 touches** |

Result: 14/20 = **70.0%**, N=20. The indicator must show `70.0% N=20`
for PDH on the morning of 2026-11-23. If it shows 70.0% with N=19, or
75.0% with N=20, the sample or the touch test differs — investigate
before trusting any other number. (The prices and counts in this table
are illustrative, not real data — run the check on your own history.)

### 4.4 Pass criterion

**Pass:** the hand-computed probability, N, and touch count match the
indicator exactly (probability to one decimal place) for the level and day
tested. **Fail:** any difference. There is no tolerance — the computation
is deterministic from the same bars, so a difference means the code and
the hand-check disagree about a level, a window, or a touch, and the
reason must be found.

**Minimum scope for a meaningful check:** hand-verify at least **3 levels
(PDH, PDL, ORH)** on at least **3 different forecast days**, including one
day that follows a Monday (weekend gap) and one day after a holiday or
short session if your history contains one. That is 9 hand-checks. A
single passing check proves little; nine passing checks across different
conditions is reasonable evidence.

---

## 5. Checking for look-ahead bias

Look-ahead bias is the failure this system is most designed to prevent,
and the hardest to spot by inspection. Test it directly:

### 5.1 The "today must not matter" test

1. Note the seven probabilities on the morning of day D.
2. At the end of day D, note them again. They must be **unchanged**
   (percentages and Ns identical). Today's price action must not enter
   today's forecast. If any probability moved during D, the lookback loop
   is including day 0 — a look-ahead defect.
3. Stronger version: on the morning of D+1, the probabilities will have
   moved (D is now a completed day in the sample, and the oldest day has
   dropped out). Verify by hand (§4) that the D+1 sample is exactly the
   D sample shifted by one day: D included, the oldest day excluded, all
   other days identical. Any other change is a defect.

### 5.2 The "future level" test

1. Pick a past day d in the lookback. Reconstruct d's forecast level by
   hand using only days before d (§4.1 step 1).
2. Now reconstruct it *incorrectly*, using the level as known at the end
   of d (e.g. for PDH, using d's own high instead of d−1's high), and
   compute the probability that would result.
3. If the indicator's number matches the *incorrect* reconstruction
   rather than the correct one, the implementation is using future data.
   (In v1.0 the code path is `ForecastLevelValue(p, day)` with `day + 1`
   for daily levels — verify by reading that function, not by trusting
   this document.)

### 5.3 The "cutoff" test

1. For a past day d where the level was touched **after** the cutoff but
   before midnight, verify by hand that the day counts as a **miss** in
   the probability sample and as `Touched = 0` in the scoreboard CSV.
2. If it counts as a touch, the evaluation window is not being honoured.

### 5.4 The "late issue" test

If the terminal was off at a day's start (e.g. started at 10:00 when the
forecast time was 00:00), the indicator captures the forecast on the first
recalculation after startup. Verify that the captured forecast equals the
hand-computed forecast for that day start (§4) — i.e. that it was computed
from bars available at the original forecast time, not from bars after it.
In v1.0 the capture happens in `CalcProbabilities()` from the same
lookback loop, so it is computed from completed days only by construction;
confirm it by hand for one such day.

---

## 6. Validating the scoreboard against raw history

### 6.1 Procedure

1. Let the indicator run live (or on a replayed period) until the CSV has
   at least **30 rows** (about 5 trading days at 7 rows/day). Do not
   hand-edit the file.
2. Open `MQL4/Files/FLR_Scoreboard_<SYMBOL>.csv`. For each row, verify:
   - **Date** is a trading day (not a weekend), and the level is one of
     the 7 probability levels.
   - **ForecastPct** equals the probability the indicator showed on the
     morning of that date (compare with your notes, or recompute by hand
     per §4 — the forecast is frozen, so it must equal the hand-check for
     that date).
   - **N** equals the eligible count from the hand-check.
   - **Touched** is 1 if and only if the level was touched inside that
     day's evaluation window (§4.2), checked by hand from the H1 bars.
   - **DOW** equals the day of week of the date (0 = Sunday … 6 =
     Saturday).
   - No duplicate `Date|Level` pair appears twice.
3. Verify the panel aggregates: Total Observations = row count; Total
   Touches = sum of Touched; Average Forecast = mean of ForecastPct;
   Actual Touch Rate = touches / rows × 100; Brier Score =
   mean((ForecastPct/100 − Touched)²) computed over the rows. Recompute
   these in a spreadsheet from the CSV and compare with the panel to 2
   decimal places (Brier to 4).

### 6.2 Pass criteria

- Every row's ForecastPct, N, Touched, and DOW match the hand-check.
- No duplicate keys; no missing rows for days where a forecast existed
  (a level with insufficient data that day is legitimately absent — check
  that the absence is explained by N < minimum sample, not by a missing
  write).
- Panel aggregates match the spreadsheet recomputation exactly (to the
  stated precision).
- Rows appear the morning after the forecast day, not during it.

### 6.3 What the scoreboard cannot validate

The scoreboard is **in-sample until it accumulates out-of-sample
forecasts**. Rows finalised from history the indicator already used to
compute its probabilities are not an independent validation of the
probabilities — they are a consistency check. Honest validation requires
forecasts issued live (or by the §4 hand procedure) and scored only
afterwards, which is what the scoreboard does from the day you start
running it. Do not backfill the CSV with hand-computed historical rows
and present the result as validation: the file's deduplication would
accept them, but they would not be forecasts the indicator ever issued.

---

## 7. Sample-size rules

| Situation | Rule |
|---|---|
| Probability display | Shown only when N ≥ `InpMinSample` (default 20, clamped to ≥ 5 in code). Below that: `INSUFFICIENT DATA`. |
| Hand-check of one probability | N must be at least the minimum sample, and the hand-check must reproduce N exactly, not just the percentage. |
| Scoreboard headline (average forecast, actual rate, Brier) | Do not interpret until **N ≥ 50 finalised rows**. Below that, the numbers describe what happened but are too noisy to judge calibration. |
| Per-level scoreboard row | Do not interpret until that level has **≥ 30 rows**. |
| Calibration bin | Do not interpret a bin with **< 20 rows**. The panel shows the counts — read them before reading the rates. |
| Day-of-week breakdown | Each weekday accumulates ~1 row per week per level; a weekday rate from fewer than 10 rows is noise. |
| Comparing two lookbacks | Compare them on the **same** days with the **same** cutoff and touch method, using the scoreboard rows each produced. Different lookbacks summarise different pasts; a difference between them is not evidence that either is wrong. |

---

## 8. What "pass" means — per check

| Check | Procedure | Pass |
|---|---|---|
| TEST 1 — Key levels | §3.2 | Hand-read PDH/PDL/PDC/PDO, session H/L/O, and ORH/ORL match the indicator to within half a point, for the days tested |
| TEST 2 — Session boundaries | §3.2 step 5 | Session windows in broker time match the UTC definitions plus the frozen offset/DST; the dashboard session name matches the real session at the time of checking |
| TEST 3 — Probability | §4 | Hand-computed probability, N, and touch count match the indicator exactly (1 dp) for ≥ 9 level/day combinations |
| TEST 4 — Sample size | §4 + dashboard | Levels with N < minimum sample show `INSUFFICIENT DATA` (not a number); no scoreboard row is scored as a miss for a day with insufficient data — it is absent, not 0 |
| TEST 5 — No repainting | §3.3 | Completed level prices and frozen forecast probabilities are identical morning and evening; finalised scoreboard rows never change |
| TEST 6 — Scoreboard | §6 | Every CSV row matches the hand-check; panel aggregates match a spreadsheet recomputation; no duplicate keys; rows appear the morning after the forecast day |
| TEST 7 — Historical replay / look-ahead | §5 | Probabilities do not move during their own forecast day; the sample shifts by exactly one day overnight; late-issue forecasts equal the hand-check; post-cutoff touches count as misses |
| TEST 8 — Restart persistence | §6 + restart | Restart MT4: the scoreboard panel totals are unchanged, the CSV is intact, and no duplicate rows appear after the restart |
| TEST 9 — Multi-pair | §3.2 + §4, per pair | Levels and PDH probabilities hand-verify on each pair with sufficient H1 history; pairs without history show `-- (no data)` in the scan rather than a fabricated number |
| TEST 10 — Performance | Observation | A full recalculation completes without visible terminal lag; with the scan on and 15 symbols, the terminal remains responsive. No formal timing target is set in v1.0 — "responsive" means no missed bars and no UI freeze |
| TEST 11 — Alerts | Live observation | Each alert type fires once (and only once per hour per level) when its condition is met; approach fires before touch when price approaches gradually; sweep alert fires on the confirming close, not on the excursion |
| TEST 12 — Compilation | MetaEditor F7 | 0 errors, 0 warnings |

A check that fails is a defect report, not a tuning opportunity: record
the date, level, configuration, hand-computed values, and indicator values,
and do not trade on the affected numbers until the discrepancy is
explained. In particular, **do not "fix" a failing probability check by
changing the lookback or the minimum sample** — that changes the question
instead of answering it.

---

## 9. Recording a test run

Keep one short log per test run (a text file next to the project is fine):

```
FLR-MT4-001 test run — <date>
Symbol: EURUSD | Config: lookback 100, minSample 20, cutoff 21,
  touch High/Low, spreadAdj 0.0, dayStart 0, brokerGMT +0, DST Auto,
  sessions Asian 0-9 / London 7-16 / NY 12-21 UTC, OR 30 min
History: H1 bars from <date> to <date> (<n> bars)
Checks: TEST 3 PDH 2026-11-23 hand 70.0% N=20 vs indicator 70.0% N=20 — PASS
        ...
Result: <n> pass / <n> fail. Failures: <list, or "none">
```

A test run without the frozen configuration written down is not
reproducible and should not be relied on.

---

*End of Backtesting Protocol — FLR-MT4-001 v1.0.*
