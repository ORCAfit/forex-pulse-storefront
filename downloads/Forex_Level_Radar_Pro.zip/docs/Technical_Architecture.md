# Forex Level Radar Pro — Technical Architecture

| Field | Value |
|---|---|
| Project ID | FLR-MT4-001 |
| Product | Forex Level Radar Pro |
| Platform | MetaTrader 4 (MT4), MQL4, `#property strict` |
| Version | 1.0 |
| Source file | `Forex_Level_Radar_Pro.mq4` (1,774 lines) |
| Companion documents | `Technical_Specification.md` (design authority), `Probability_Methodology.md` (mathematical authority), `Source_Code_Documentation.md` (function reference) |

> **Authority note.** This document describes the architecture **as
> implemented in v1.0**. Where the implementation differs from the Phase 1
> design documents, the difference is stated explicitly (see §8) and the
> code governs. This document does not rewrite the design documents.

---

## 1. Overview

Forex Level Radar Pro is a single-file MQL4 indicator
(`#property indicator_chart_window`, no indicator buffers) that implements
seven engines in one compilation unit. There are no included files, no DLLs,
no external services, and no trade execution of any kind.

```
H1 bars (iOpen/iHigh/iLow/iClose/iTime, Bid basis)
        │
        ▼
┌──────────────────────────────────────────────────────────────────┐
│ 1. Key Level Detection      CalcLevels()                         │
│    → g_levels[17], g_levelValid[17], g_prevLevels[4]            │
├──────────────────────────────────────────────────────────────────┤
│ 2. Historical Probability   CalcProbabilities()                  │
│    → g_prob[7], g_probN[7], g_probTouches[7], g_probStatus[7]   │
├──────────────────────────────────────────────────────────────────┤
│ 3. Session Intelligence     CalcSessions()                       │
│    → g_sessionName, g_marketStatus, g_*Start/g_*End, g_cutoffTime│
├──────────────────────────────────────────────────────────────────┤
│ 4. Liquidity Monitoring     CheckLiquidity() / RecordSweep()     │
│    → sweep ring buffer (100), g_breakoutCount, FLR_SWEEP_* arrows│
├──────────────────────────────────────────────────────────────────┤
│ 5. Candle-by-Candle Analysis  RecalcAll() / CheckNewDay() /       │
│    CheckAlerts() — live state, forecast capture, day rollover    │
├──────────────────────────────────────────────────────────────────┤
│ 6. Performance Scoreboard   LoadScoreboard() / FinaliseYesterday()│
│    / AppendScoreboardRow() / ExportScoreboardSummary()           │
│    → FLR_Scoreboard_<SYMBOL>.csv (+ summary CSV)                │
├──────────────────────────────────────────────────────────────────┤
│ 7. Interactive Dashboard    DrawDashboard() / DrawScoreboardPanel()│
│    / DrawScanPanel() / DrawLevels() — FLR_* chart objects only   │
└──────────────────────────────────────────────────────────────────┘
```

The engines do **not** communicate through the struct-based record arrays
specified in `Technical_Specification.md` §3 (`LevelRecord`,
`ProbabilityRecord`, `SweepEventRecord`, `ScoreboardRecord`). In v1.0 the
shared state is a set of **parallel global arrays** (§2) — the design
documents' structs are a design-time specification, not the implemented
representation. The invariants the structs were meant to enforce
(immutability of completed levels, one forecast per level per day, no
look-ahead) are enforced procedurally instead: by the scan windows used,
by the forecast capture in `CalcProbabilities()`, and by the
deduplication key in `AppendScoreboardRow()`. Any future refactor to the
struct form must preserve those procedural guarantees, not just the field
names.

### 1.1 Design principles (as implemented)

- **Closed H1 bars are the only source of truth.** Every aggregation
  (`ScanHighLow()`, `TouchInWindow()`) scans `PERIOD_H1` bars, regardless
  of the chart timeframe. An H1 bar's high/low are the true extremes of
  that hour, so daily/session extremes are exact and the scan stays cheap.
- **Provisional vs. final is a property of the window, not of the data.**
  A level is final when its source window has closed; until then it is the
  running extreme. The code enforces this by capping each session scan at
  `min(windowEnd, now)` in `CalcLevels()`, and by sourcing PDH/PDL/PDC/PDO
  only from the completed previous day.
- **Probabilities are computed from the past only.** The lookback loop in
  `CalcProbabilities()` iterates days 1…`InpProbLookback` and, for each
  past day D, reconstructs D's forecast level from days before D
  (`ForecastLevelValue(p, day)` uses `day + 1` for daily levels). Today
  (day 0) is excluded. There is no code path that lets a bar after the
  forecast time contribute to a forecast.
- **Finalised records are append-only.** Scoreboard rows are written once
  by `AppendScoreboardRow()`, deduplicated by `Date|Level`, and never
  edited. There is no update or delete path in the code.
- **The display never writes market data.** Dashboard, scoreboard panel,
  and scan panel read globals and create chart objects; they never modify
  a level, a probability, or a scoreboard row.

---

## 2. Data structures (as implemented)

All state is global. There are no classes and no structs in v1.0.

### 2.1 Level state

| Global | Type | Meaning |
|---|---|---|
| `g_levels[LV_COUNT]` (17) | `double` | Current price of each level kind, indexed by `LV_PDH…LV_ORL` (0–16) |
| `g_levelValid[LV_COUNT]` | `bool` | Whether the level exists for the current day (false = no bars in its source window) |
| `g_prevLevels[LV_COUNT]` | `double` | Day-before-previous PDH/PDL/PDC/PDO only (faded review lines) |
| `g_prevValid[LV_COUNT]` | `bool` | Validity flags for the above |
| `g_touchedToday[LV_COUNT]` | `bool` | Whether each level has been touched today (set by `CalcProbabilities()` and `CheckAlerts()`, reset in `CheckNewDay()`) |

Level indexes (`#define`): `LV_PDH 0, LV_PDL 1, LV_PDC 2, LV_PDO 3, LV_DO 4,
LV_ONH 5, LV_ONL 6, LV_ASH 7, LV_ASL 8, LV_LONH 9, LV_LONL 10, LV_LONO 11,
LV_NYH 12, LV_NYL 13, LV_NYO 14, LV_ORH 15, LV_ORL 16`. `LV_COUNT 17`.

Name tables: `g_levelAbbr[17]` (`"PDH","PDL","PDC","PDO","DO","ONH","ONL",
"ASH","ASL","LONH","LONL","LONO","NYH","NYL","NYO","ORH","ORL"`) and
`g_levelName[17]` (display names; `"Day Open"`, `"Asian High"`, etc.).

### 2.2 Probability state

Only 7 of the 17 levels carry probabilities (`PR_COUNT 7`):

| Global | Type | Meaning |
|---|---|---|
| `g_probLevelIdx[7]` | `int` | `{LV_PDH, LV_PDL, LV_PDC, LV_ONH, LV_ONL, LV_ORH, LV_ORL}` |
| `g_probAbbr[7]` | `string` | `{"PDH","PDL","PDC","ONH","ONL","ORH","ORL"}` |
| `g_probIsUp[7]` | `bool` | `{true,false,false,true,false,true,false}` — upward touch direction |
| `g_probBoth[7]` | `bool` | `{false,false,true,false,false,false,false}` — PDC touches either way |
| `g_prob[7]` | `double` | Probability % (one decimal stored; displayed with `FmtPct()`) |
| `g_probN[7]` | `int` | Eligible observations (sample size) |
| `g_probTouches[7]` | `int` | Touches within the sample |
| `g_probValid[7]` | `bool` | `N >= InpMinSample` (clamped to ≥ 5 in logic) |
| `g_probStatus[7]` | `string` | `"Waiting"`, `"Hit"`, or `"Insufficient"` |
| `g_probDowN[7][7]`, `g_probDowTouch[7][7]` | `int` | Per-day-of-week observation/touch counts (Sunday = 0 … Saturday = 6). Computed in `CalcProbabilities()` but **not displayed** anywhere in v1.0 |

Note: `g_prob[]` is populated even when `g_probValid[]` is false (the
computed ratio is stored, but the dashboard shows `INSUFFICIENT DATA`
instead of the number). The design documents specify a `-1.0` sentinel for
the undefined case; the code stores the ratio and gates the display. The
scoreboard is also gated: `FinaliseYesterday()` **skips** a level whose
forecast had insufficient data (`g_yestN[p] < InpMinSample`), so no
scoreboard row is written for it — the day is absent for that level, not
scored as a miss (spec §5.3; fixed in the 2026-11-27 QA pass, Test
Report F7).

### 2.3 Session state

| Global | Meaning |
|---|---|
| `g_sessionName`, `g_marketStatus` | `"Asian"` / `"London"` / `"New York"` / custom name / `"Closed"`; `"Active"` / `"Closed"` |
| `g_asianStart/g_asianEnd`, `g_londonStart/g_londonEnd`, `g_nyStart/g_nyEnd` | Session windows for the current trading day, in **broker datetimes** |
| `g_cutoffTime` | `g_currentDayStart + InpCutoffHour * 3600` |
| `g_currentDayStart` | Start of the current trading day (broker time) |

### 2.4 Liquidity state

| Global | Meaning |
|---|---|
| `g_sweepTime[100]`, `g_sweepLevel[100]`, `g_sweepDir[100]`, `g_sweepExcPts[100]`, `g_sweepConfirm[100]` | Ring buffer of recorded sweeps (`SWEEP_MAX 100`), `g_sweepHead` write index, `g_sweepCount` count (≤ 100) |
| `g_sweepLevelIdx[8]`, `g_sweepIsBuy[8]` | Monitored levels: `{PDH, ASH, LONH, ORH, PDL, ASL, LONL, ORL}`; buy-side = first four |
| `g_exceeded[8]`, `g_exceedTime[8]`, `g_exceedMax[8]`, `g_exceedBars[8]`, `g_exceedClosedBeyond[8]`, `g_exceedBarTime[8]` | Per-level excursion tracking state (in-progress, not yet classified). `g_exceedClosedBeyond` records whether any close went beyond the level during the excursion (failed-breakout guard); `g_exceedBarTime` records the open time of the excursion bar so classification waits until that bar has closed |
| `g_breakoutCount` | Sustained breakouts counted today (no per-event record) |
| `g_lastSweepAlert[8]`, `g_lastApproachAlert[17]`, `g_lastTouchAlert[17]`, `g_lastORAlert` | Alert throttle timestamps (one hour per level/type) |

### 2.5 Scoreboard state

| Global | Meaning |
|---|---|
| `g_sbTotalObs`, `g_sbTotalTouches`, `g_sbSumForecast`, `g_sbSumBrier`, `g_sbBrierN` | Running aggregates rebuilt from the CSV on load |
| `g_sbLevelObs[7]`, `g_sbLevelTouches[7]`, `g_sbLevelSumFc[7]` | Per-level aggregates |
| `g_sbDowObs[7]`, `g_sbDowTouch[7]` | Per-day-of-week aggregates (from finalised rows) |
| `g_sbCalObs[5]`, `g_sbCalTouch[5]` | Calibration-bin aggregates (bins 0–29, 30–49, 50–64, 65–79, 80–100) |
| `g_sbLoadedKeys[5000]`, `g_sbLoadedCount` | Deduplication keys `Date|Level` loaded from the CSV (cap 5,000 rows in memory) |
| `g_yestForecast[7]`, `g_yestN[7]`, `g_yestDayStart`, `g_yestDateStr`, `g_yestHasForecast` | Yesterday's forecast, held so it can be finalised at the rollover |

### 2.6 Scan state

`g_scanSymbols[30]` (`SCAN_MAX 30`), `g_scanCount`, `g_scanText[30]`.
Parsed from `InpScanSymbols` in `OnInit()` by `StringSplit()` on commas.

### 2.7 Theme state

`g_cBg, g_cBg2, g_cText, g_cMuted, g_cAccent, g_cBorder, g_cGreen,
g_cYellow, g_cRed, g_cPanel` — set by `ApplyTheme()`. Dark theme:
background (13,18,32), panel (17,23,38), text white, muted (150,165,190),
accent gold, border (55,70,95). Light theme: background (240,240,245),
text (20,20,30), accent dark gold (180,130,0). Probability colours are
theme-independent: green `clrLimeGreen`, yellow `clrGold`, red `clrTomato`.

---

## 3. Event model

| MQL4 entry point | Function | Responsibility in v1.0 |
|---|---|---|
| `OnInit()` | lines 631–741 | Validate inputs (hard failures listed in `Installation_Guide.md` §6.1); delete stale `FLR_` objects; initialise all globals; parse the scan list; set `g_currentDayStart`; load the scoreboard CSV if enabled; start the timer with `EventSetTimer(InpRefreshSeconds)`; log the initialisation line. Returns `INIT_SUCCEEDED`, `INIT_PARAMETERS_INCORRECT`, or `INIT_FAILED`. |
| `OnCalculate()` | lines 750–769 | Detect a new bar by comparing the last bar's open time with `g_lastBarTime`. Call `RecalcAll(isNewBar)` on a new bar, on the first calculation, or when the timer interval has elapsed since the last recalculation. Otherwise, on ticks, only refresh the dashboard's live price labels (`DrawDashboard()`). Returns `rates_total`. |
| `OnTimer()` | lines 771–777 | Same gating as `OnCalculate()`: full recalculation if the interval elapsed, else a cheap dashboard refresh. |
| `OnChartEvent()` | lines 779–807 | **Object clicks only.** `FLR_DASH_TOGGLE` minimises/expands the dashboard; `FLR_DASH_CLOSE` hides it (until re-attach) and deletes all objects; `FLR_SB_TOGGLE` minimises/expands the scoreboard; `FLR_SB_EXPORT` writes the summary CSV. No drag handling exists in v1.0. Must never alter market data — and does not. |
| `OnDeinit(reason)` | lines 743–748 | `EventKillTimer()`, `DeleteAllObjects()` (deletes every object with prefix `FLR_`), log line. No CSV flush is needed: rows are appended at finalisation time, not held in a write buffer. |

### 3.1 Master recalculation — `RecalcAll(bool isNewBar)`

Runs, in order, on every new bar, on the first calculation, and on every
timer tick once the refresh interval has elapsed:

1. `CheckNewDay()` — day rollover: finalise yesterday, reset daily state.
2. `CalcSessions()` — session windows, current session, market status.
3. `CalcLevels()` — all 17 levels for the current day.
4. `CalcProbabilities()` — the 7 probabilities, live statuses, forecast capture.
5. `CheckLiquidity(isNewBar)` — sweep/breakout classification.
6. `CheckAlerts()` — approach/touch alerts.
7. `DrawLevels()` — level lines and labels.
8. `DrawDashboard()` (if enabled and not hidden), `DrawScoreboardPanel()`
   (if enabled), `DrawScanPanel()` (if enabled).
9. `ChartRedraw()`.

The full history scan is bounded: `CalcProbabilities()` scans at most
`InpProbLookback` days × the H1 bars in each day's windows, using
`iBarShift()` to bound each scan to the bars inside the window. There is
no full-terminal-history scan on any bar.

### 3.2 Recalculation strategy and caching

- **Incremental by default, but not by cache.** v1.0 does not cache
  completed days' levels or probabilities in the sense of
  `Technical_Specification.md` §2.3: `CalcLevels()` and
  `CalcProbabilities()` recompute from H1 history on every
  `RecalcAll()` call. The work is bounded (lookback days, H1 bars, window
  bounded by `iBarShift()`), so the cost is acceptable; the design
  documents' incremental-cache scheme is not implemented.
- **Full recomputation triggers:** init, symbol/timeframe change (MT4
  re-runs `OnInit()`), input change, new bar, timer expiry. There is no
  separate "history reload" detection.
- **No tick-level probability recomputation.** Ticks between
  recalculations only refresh the dashboard's live price via
  `DrawDashboard()`. Probabilities, forecasts, and scoreboard rows never
  change on a tick. The live `Hit`/`Waiting` status is recomputed in
  `CalcProbabilities()` (on recalculation), using the current bar's
  High/Low and an H1 scan up to now — so a status can change intrabar on
  the next recalculation, but the frozen forecast probability cannot.
- **Timer discipline.** `OnTimer()` and `OnCalculate()` share the same
  gate (`TimeCurrent() - g_lastCalcTime >= InpRefreshSeconds`), so the two
  paths cannot double-recalculate in the same interval.

---

## 4. The seven engines — implementation mapping

### 4.1 Engine 1 — Key Level Detection (`CalcLevels()`, `ScanHighLow()`, `GetDayHL()`)

`CalcLevels()` rebuilds all 17 levels for the current trading day:

- **Daily:** `GetDayHL(1, …)` gives the previous trading day's
  high/low/open/close → PDH/PDL/PDC/PDO. `GetDayHL(2, …)` gives the
  day-before-previous → faded `g_prevLevels[]`. `GetDayHL(0, …)` gives the
  current day's open → DO.
- **Asian/overnight:** scans `[g_asianStart, min(g_asianEnd, now))` →
  ONH/ONL **and** ASH/ASL from the same scan (identical prices — see §8).
- **London / New York:** scans the session window capped at now, only
  once `now >= sessionStart` → LONH/LONL/LONO, NYH/NYL/NYO.
- **Opening range:** scans `[g_currentDayStart, min(dayStart +
  InpOpeningRangeMinutes, now))` → ORH/ORL. The range starts at the
  trading-day start, not at the New York open (see §8).

`ScanHighLow(sym, start, end, hi, lo, op, cl)` is the single aggregation
primitive: it finds the H1 bars whose open time lies in `[start, end)`
via `iBarShift()`, then returns max High, min Low, the open of the oldest
bar in the window, and the close of the newest bar. Returns `false` when
no bar exists in the window — the caller then leaves the level invalid
rather than inventing a price. `DayWindow()` / `DayWindowFor()` compute
24-hour trading-day windows as `dayStart + daysAgo * 86400`.

### 4.2 Engine 2 — Historical Probability (`CalcProbabilities()`, `ForecastLevelValue()`, `EvalWindow()`, `DayOutcome()`, `TouchInWindow()`)

For each of the 7 probability levels, for each past day `day` in
1…`InpProbLookback`:

1. `ForecastLevelValue(p, day, level)` reconstructs that day's forecast
   level using only earlier days: PDH/PDL/PDC from `GetDayHL(day + 1)`;
   ONH/ONL from that day's Asian window; ORH/ORL from that day's opening
   range. Returns false if the level could not be computed — the day is
   then skipped entirely (not counted as a miss).
2. `EvalWindow(p, day, ws, we)` gives the evaluation window: daily levels
   from the day start to `dayStart + InpCutoffHour * 3600` (capped at the
   day end); ONH/ONL from the Asian session end to the cutoff; ORH/ORL
   from the end of the opening range to the cutoff. If the window is
   empty, it is widened to one hour (`we = ws + 3600`).
3. `TouchInWindow(sym, ws, we, level, isUp, both)` scans the H1 bars in
   the window: `TOUCH_HIGH_LOW` checks High/Low against the level;
   `TOUCH_CLOSE` checks the Close. The spread adjustment widens the zone
   by `InpSpreadAdjPoints * Point` (upward: `High >= level − adj`). For
   a neutral level (`both`, i.e. PDC) the bar's range must contain the
   level under High/Low (`High >= level − adj` **and**
   `Low <= level + adj`), and `|Close − level| <= adj` under Close.
   (The neutral test used to be `High >= level OR Low <= level`, which
   is true for every bar; corrected to AND in the 2026-11-27 QA pass,
   Test Report F2.)
4. Eligible days and touches are counted; `g_prob[p] = touches /
   eligible * 100`. `g_probValid[p] = (eligible >= max(InpMinSample, 5))`.

Day-of-week counts are accumulated in the same loop
(`g_probDowN[p][dow]`, `g_probDowTouch[p][dow]`).

The live status for today is computed separately, in the same function:
using the current bar's High/Low and an H1 scan of today's evaluation
window up to now. The live check is direction-aware (upward: High,
downward: Low, neutral PDC: the bar's range must contain the level).
`DayOutcome()` is the single-day version of steps 1–3; it is **defined
but never called** in v1.0 — the main loop and the finalise path inline
the same logic (see `Source_Code_Documentation.md` §2.2 and Test
Report A14).

**Not implemented in v1.0:** Wilson confidence intervals
(`Probability_Methodology.md` §10) — no function computes them and no
field stores them. Brier skill vs. climatology is likewise absent.

### 4.3 Engine 3 — Session Intelligence (`CalcSessions()`, `SessionWindowForDay()`, `BrokerOffsetHours()`, `GetDSTShift()`, `UTCMidnightFor()`, `TradingDayStart()`, `BrokerMidnight()`)

- `TradingDayStart(t)` returns the most recent occurrence of
  `InpDayStartHour:00` broker time at or before `t`.
- `BrokerOffsetHours(t)` returns `InpBrokerGMTOffset + GetDSTShift(t)`
  when `InpUseUTCReference` is true, else 0. `GetDSTShift()`:
  `DST_OFF` → 0; `DST_MANUAL` → `InpDSTShiftHours`;
  `DST_AUTO` → `InpDSTShiftHours` when the broker-time month is April–
  October, else 0. This is an **approximation** (month-based, not rule-based):
  it does not implement the US second-Sunday-in-March / first-Sunday-in-
  November rule or the EU last-Sunday rules described in the design
  documents. Users whose broker DST transitions fall in March or November
  should use `DST_MANUAL` and set the shift by hand.
- `SessionWindowForDay(dayStart, startUTC, endUTC, sStart, sEnd)`
  converts a UTC hour window to broker datetimes for the trading day: it
  takes the UTC midnight of the day, adds the UTC hours, adds the broker
  offset, handles windows that cross midnight (`end <= start` → +24h),
  and shifts the window forward a day if it would otherwise start more
  than an hour before the trading-day start.
- `CalcSessions()` computes the three windows for the current trading day,
  sets `g_cutoffTime`, and derives the current session from the **UTC
  hour**: New York takes priority over London, London over Asian (the
  overlaps are intentional). A custom session (`InpUseCustomSession`,
  single window `InpCustomStartUTC`–`InpCustomEndUTC`, name
  `InpCustomName`) is checked first and overrides the three standard
  sessions when the current hour falls inside it. Market status is
  `Active` when inside any session, `Closed` otherwise (including
  weekends — there are no bars, and the UTC-hour test alone would still
  return a session name on a Saturday; the status is therefore best read
  together with whether the chart has current bars).

### 4.4 Engine 4 — Liquidity Monitoring (`CheckLiquidity()`, `RecordSweep()`)

Monitors 8 levels (`g_sweepLevelIdx`, `g_sweepIsBuy`). The state machine
per level:

1. **Not exceeded.** On each recalculation, if the live Bid is beyond the
   level (above for buy-side, below for sell-side), record the excursion
   start (`g_exceedTime`, `g_exceedMax = Bid`, `g_exceedBars = 0`, and
   `g_exceedBarTime` = the open time of the excursion bar) and
   enter the exceeded state. Note: the trigger is the **live Bid**, not a
   closed candle's high/low — the design documents' excursion detection on
   closed candles is not what the code does.
2. **Exceeded.** Track the worst excursion (`g_exceedMax`). `g_exceedBars`
   increments on each new bar while exceeded. Classification is
   **deferred until the excursion bar has closed**
   (`Time[1] >= g_exceedBarTime[s]`) — nothing is classified on ticks
   while the excursion candle is still forming. Once it has closed, look
   at the last closed bar's close (`Close[1]`):
   - **Closed back inside** (`Close[1]` back inside the level) and
     `g_exceedBars <= InpConfirmBars` **and no close went beyond the
     level during the excursion** (`g_exceedClosedBeyond[s]` is false)
     → **sweep**: `RecordSweep()` writes the ring-buffer entry, draws
     the arrow (`FLR_SWEEP_<slot>`, `OBJ_ARROW`, code 234/233, at
     `g_exceedMax` and `Time[1]`), and the sweep alert fires (throttled
     to one per hour per level).
   - **Closed back inside after a close went beyond** → **failed
     breakout**: the sweep path is closed once any close goes beyond
     (spec §8.2 step 3b). The state is cleared without recording a
     sweep. No failed-breakout event class is recorded in v1.0.
   - **Still beyond** and `g_exceedBars >= InpBreakoutBars` →
     **sustained breakout**: `g_breakoutCount++`; the OR breakout alert
     fires only for ORH/ORL. No event record or marker is created.
   - **Closed back inside but too late** (`g_exceedBars >
     InpConfirmBars` and `< InpBreakoutBars`, with no close beyond) →
     state is dropped silently.
3. State resets at the day rollover (`CheckNewDay()` clears
   `g_exceeded[]`, `g_exceedBars[]`, `g_exceedClosedBeyond[]`, and
   `g_exceedBarTime[]`).

### 4.5 Engine 5 — Candle-by-Candle Analysis (`RecalcAll()`, `CheckNewDay()`, `CheckAlerts()`)

- New-bar detection: `OnCalculate()` compares the last bar's open time
  with `g_lastBarTime`.
- On a new bar or timer expiry, `RecalcAll()` re-runs engines 1–4 and the
  alerts. Between recalculations, ticks only refresh the dashboard's live
  price labels.
- **Day rollover** (`CheckNewDay()`): when `TradingDayStart(TimeCurrent())`
  changes, `FinaliseYesterday()` runs first, then daily state resets
  (`g_touchedToday[]`, excursion state) and, if `InpDailyReset`, the
  displayed scoreboard totals reset (the CSV is untouched).
- **Forecast capture** (`CalcProbabilities()`, end of function): the first
  time the current trading day is seen, today's seven forecast
  probabilities and Ns are copied into `g_yestForecast[]` / `g_yestN[]`
  with `g_yestDayStart` and `g_yestDateStr`. They are frozen from then on
  — later recalculations do not overwrite them (`if(!g_yestHasForecast ||
  g_yestDayStart != g_currentDayStart)`).
- **Alerts** (`CheckAlerts()`): approach (live Bid within
  `InpApproachPoints` of any of the 17 levels) and touch (the last
  closed bar, tested direction-aware via `BarTouchesLevel()` — upward
  levels by High, downward by Low, neutral levels by the bar's range
  containing the level) — both throttled to one per hour per level,
  delivered via `Alert()`, `PlaySound("alert.wav")`, and/or
  `SendNotification()` per the channel inputs.

### 4.6 Engine 6 — Performance Scoreboard (`LoadScoreboard()`, `AppendScoreboardRow()`, `FinaliseYesterday()`, `ScoreboardAccumulate()`, `ExportScoreboardSummary()`, `ScoreboardFileName()`, `ScoreboardKeyExists()`, `ScoreboardAddKey()`)

- **File:** `FLR_Scoreboard_<SYMBOL>.csv` in `MQL4/Files/`
  (`ScoreboardFileName()`). One file per symbol. No settings are recorded
  in the file header (the design documents require the day-start setting
  in the header; v1.0 does not write it).
- **Load** (`LoadScoreboard()`, at `OnInit()` when scoreboard and
  persistent storage are enabled): reads the CSV row by row with
  `FILE_CSV`, skips the header, rebuilds all aggregates via
  `ScoreboardAccumulate()`, and records each `Date|Level` key. Rows whose
  level abbreviation is not one of the 7 probability levels are skipped.
- **Finalise** (`FinaliseYesterday()`, at the day rollover): for each of
  the 7 levels, reconstructs *yesterday's* forecast level from the day
  before yesterday (daily levels) / yesterday's Asian window / yesterday's
  opening range, evaluates the touch over yesterday's evaluation window
  (same rules as §4.2), and calls `AppendScoreboardRow()` with the frozen
  forecast and N captured at yesterday's day start. Levels whose
  forecast had insufficient data (`N < InpMinSample`) are skipped — no
  row is written for them. Finalisation is skipped entirely if the
  current time is before yesterday's cutoff.
- **Append** (`AppendScoreboardRow()`): writes the header
  `Date,Level,ForecastPct,N,Touched,DOW` if the file is empty, then one
  row. Returns without writing if the scoreboard, persistent storage, or
  CSV export is disabled, or if the `Date|Level` key already exists. The
  append opens the file `FILE_READ | FILE_WRITE`, seeks to the end, and
  flushes by closing — there is no separate flush step and no write
  buffering, so a terminal crash loses at most the row being written.
- **Aggregates** (`ScoreboardAccumulate()`): total observations, touches,
  sum of forecasts, Brier sum (`(f − o)²` with `f` as a proportion),
  per-level, per-day-of-week, and calibration-bin counts. All are
  recomputed from the loaded rows; the file is the permanent record and
  the in-memory aggregates are a cache of it.
- **Export** (`ExportScoreboardSummary()`): writes
  `FLR_Scoreboard_Summary_<SYMBOL>.csv` (two columns, Metric/Value) with
  headline, per-level, and calibration figures. Overwrites on each export.
- **Limits:** deduplication keys are capped at 5,000 in memory
  (`g_sbLoadedKeys[5000]`). A scoreboard beyond 5,000 rows (about 714
  trading days at 7 rows/day) will stop deduplicating correctly on load —
  in practice the file keeps growing and later loads may double-count
  rows already present. This is a v1.0 capacity limit; archive the CSV
  annually.

### 4.7 Engine 7 — Dashboard and chart objects (`DrawLevels()`, `DrawDashboard()`, `DrawScoreboardPanel()`, `DrawScanPanel()`, `PutLabel()`, `PutRect()`, `LevelColour()`, `LevelStyle()`, `LevelVisible()`, `DeleteAllObjects()`)

- **Level lines** (`DrawLevels()`): `FLR_LVL_<ABBR>` (`OBJ_HLINE`, back =
  true, not selectable) and `FLR_LBL_<ABBR>` (`OBJ_TEXT`, Arial 8, anchored
  at the current bar's time, text `" <ABBR> <price>"`). Prior-day lines:
  `FLR_PREV_<ABBR>` (dim grey, dotted, PDH/PDL/PDC/PDO only). Objects for
  hidden or invalid levels are deleted on each draw.
- **Dashboard** (`DrawDashboard()`): background `FLR_DASH_BG`
  (`OBJ_RECTANGLE_LABEL`, 322 × 556 px expanded, 34 px minimised) and
  labels `FLR_DASH_*` / `FLR_D_*`. Title, toggle `[-]`/`[+]`, and close
  `[x]` are the only selectable objects (selectable is set explicitly
  after creation, because `PutLabel()` creates them non-selectable).
- **Scoreboard panel** (`DrawScoreboardPanel()`): `FLR_SB_BG`
  (322 × 430 px with calibration, 300 px without; 34 px minimised) at
  Y + 566, labels `FLR_SB_*`, toggle and `[Export]` button.
- **Scan panel** (`DrawScanPanel()`): `FLR_SCAN_BG` (250 px wide, at
  X + 332) with one `FLR_SCAN_<i>` label per symbol, showing PDH
  probability from `CalcSymbolPDHProb()` (lookback capped at 50, symbols
  with < 100 H1 bars or < 5 eligible days shown as `-- (no data)`).
- **Cleanup** (`DeleteAllObjects()`): `ObjectsDeleteAll(0, "FLR_")` —
  every object the indicator owns shares the prefix, so removal is total
  and cannot touch another indicator's objects.

---

## 5. File persistence format

### 5.1 Scoreboard rows — `FLR_Scoreboard_<SYMBOL>.csv`

Written by `FileWrite()` with `FILE_CSV` and delimiter `","`. MT4's CSV
writer quotes fields as needed; the reader (`LoadScoreboard()`) reads with
`FileReadString()` / `FileReadNumber()` in the same field order.

```
Date,Level,ForecastPct,N,Touched,DOW
2026.11.26,PDH,72.00,100,1,4
2026.11.26,PDL,31.00,100,0,4
...
```

| Column | Type | Meaning |
|---|---|---|
| `Date` | `yyyy.mm.dd` string | Trading day the forecast applied to (`TimeToString(dayStart, TIME_DATE)`) |
| `Level` | string | One of PDH, PDL, PDC, ONH, ONL, ORH, ORL |
| `ForecastPct` | number, 2 dp | Frozen forecast probability at that day's start |
| `N` | integer | Eligible observations behind the forecast |
| `Touched` | 0 / 1 | Outcome: 1 = touched before the cutoff, 0 = not |
| `DOW` | integer 0–6 | Day of week of the trading day (0 = Sunday … 6 = Saturday, MQL4 `TimeDayOfWeek()`) |

No Wilson interval, no cutoff, no lookback, no touch method, and no
session is stored per row. A shipped `Sample_Scoreboard.csv` in the
project root shows the exact shape with example values (labelled EXAMPLE;
the numbers are invented, not results).

### 5.2 Scoreboard summary — `FLR_Scoreboard_Summary_<SYMBOL>.csv`

Two columns, `Metric,Value`, written by `ExportScoreboardSummary()`:

```
Metric,Value
Symbol,EURUSD
TotalObservations,142
TotalTouches,71
AverageForecastPct,54.20
ActualTouchRatePct,50.00
ForecastMinusActualPct,4.20
BrierScore,0.2314
PDH_Obs,21
PDH_ForecastPct,68.10
PDH_ActualPct,61.90
...
Cal_0-29%_Obs,12
Cal_0-29%_ActualPct,16.67
...
```

The summary is a snapshot of the in-memory aggregates at export time; it
is overwritten on each export and is not the permanent record — the
per-row file (§5.1) is.

---

## 6. Data flow — a day in the life

```
00:00 broker (day start, default)
  │  OnCalculate new bar → RecalcAll()
  │    CheckNewDay(): FinaliseYesterday() appends up to 7 rows for
  │      the day just ended (if its cutoff passed) → CheckNewDay resets
  │    CalcSessions(): session windows for the new day
  │    CalcLevels(): PDH/PDL/PDC/PDO from yesterday; DO from today
  │    CalcProbabilities(): 7 probabilities from the last 100 completed
  │      days; today's forecast frozen into g_yestForecast[]
  │    DrawDashboard(): probability table shows today's odds, all Waiting
  │
  │  ... during the day, each new bar / 5 s timer ...
  │    RecalcAll(): levels update (session levels provisional until
  │      their window closes); statuses flip Waiting → Hit on touch;
  │      CheckLiquidity() classifies excursions; CheckAlerts() fires
  │      throttled alerts; panels redraw
  │
21:00 broker (cutoff, default)
  │  Outcomes for today are now determined, but rows are NOT written yet
  │
next 00:00 broker (rollover)
  │  CheckNewDay() → FinaliseYesterday() evaluates yesterday against
  │  the frozen forecast and appends the 7 rows → new day begins
```

**Key property:** the forecast for day D is computed at D's start from
days before D, frozen, and scored after D's cutoff using only D's own bars.
No step reads a bar dated after the moment it is reasoning about. The
single exception to be aware of: the *live* status check in
`CalcProbabilities()` uses the current (still-forming) bar's High/Low, so
a level can show Hit intrabar and the final outcome is still decided by
the H1 scan at finalisation — the two agree except in the edge case where
a touch exists only inside the forming H1 bar at the moment of the check.

---

## 7. Performance notes

- **Bounded scans.** Every H1 scan is bounded by `iBarShift()` to the
  bars inside the requested window. A probability computation touches at
  most `lookback` days × (bars per day + bars in the evaluation window) —
  for lookback 100 on H1, roughly 100 × 48 = ~4,800 bar visits per level,
  × 7 levels ≈ 34,000 bar visits per full recalculation. On modern
  hardware this is milliseconds.
- **Recalculation frequency.** A full recalculation happens at most once
  per new bar, once per timer interval (default 5 s), or once per
  `OnCalculate()` call when the interval has elapsed. Ticks in between
  only redraw labels. There is no per-tick scan.
- **Scan panel cost.** `DrawScanPanel()` calls `CalcSymbolPDHProb()` per
  symbol per recalculation — up to 30 symbols × 50 days of H1 scans. This
  is the most expensive optional feature; it is off by default. If the
  terminal feels slow with the scan on, reduce `InpScanSymbols` or turn
  the scan off.
- **Object count.** Level lines and labels: ~17 × 2 + 4 prior-day lines +
  up to 100 sweep arrows + ~50 dashboard/scoreboard labels ≈ 200 chart
  objects maximum. MT4 handles this comfortably; the sweep ring buffer
  cap (100) is what bounds the arrow count.
- **Memory.** Scoreboard deduplication keys are capped at 5,000 strings
  in memory (§4.6). History usage is bounded by the terminal's own bar
  limits, not by the indicator.
- **Known inefficiency (v1.0).** `CalcProbabilities()` recomputes the full
  lookback from history on every recalculation rather than caching
  completed days. This is simple and correct, but it is O(lookback) work
  every 5 seconds / every bar. With lookback 200 and the scan panel on,
  the combined cost is still small on a desktop terminal, but do not
  attach the indicator to many charts with the scan enabled
  simultaneously.

---

## 8. Known divergences from the Phase 1 design documents

Recorded here so they are treated as design decisions to be resolved by
amendment, not as undocumented behaviour. The code is the authority for
v1.0 behaviour.

| # | Area | Design documents | v1.0 implementation |
|---|---|---|---|
| D-1 | Data structures | `LevelRecord` / `ProbabilityRecord` / `SweepEventRecord` / `ScoreboardRecord` structs with named fields | Parallel global arrays; invariants enforced procedurally |
| D-2 | Minimum sample default | 20 | **ALIGNED in the 2026-11-27 QA pass** — `InpMinSample` is now 20 (was 30) |
| D-3 | Dashboard refresh default | 5 s | **ALIGNED in the 2026-11-27 QA pass** — `InpRefreshSeconds` is now 5 (was 30) |
| D-4 | Opening range | First 15/30/60 min of the New York session | First `InpOpeningRangeMinutes` after the **trading-day start** |
| D-5 | Overnight high/low | 21:00–07:00 UTC window, distinct from Asian | **Identical to Asian session** high/low |
| D-6 | Touch methods | Bid-only / spread-adjusted / Ask-based | **High/Low** or **Close**; spread adjustment is a points value that *widens* the touch zone (level − adj), the opposite direction from the design's spread-adjusted method |
| D-7 | Wilson 95% interval | Computed and stored per forecast | **Not computed** |
| D-8 | Brier skill vs. climatology | Defined | **Not computed** (raw Brier only) |
| D-9 | Failed-breakout class | Defined | **Guard implemented, class not recorded.** A close beyond the level followed by a close back inside is now explicitly recognised as a failed breakout (the sweep path is closed and the state is cleared without recording a sweep). No failed-breakout event record, marker, or scoreboard entry exists in v1.0 |
| D-10 | Sweep detection | Excursion on closed candles | Trigger is the **live Bid** crossing the level; confirmation uses the last closed bar's close |
| D-11 | Dashboard dragging | Draggable by title bar | **Not implemented**; position from inputs only |
| D-12 | Day-start change | New scoreboard file on change | Same file continues; manual archival required |
| D-13 | `InpHistoryDays` | History limit | Declared but **unused** |
| D-14 | DST handling | Rule-based US/EU DST rules | **Month-based approximation** (April–October) in AUTO mode; MANUAL mode for exact control |
| D-15 | Scoreboard CSV header | Records day-start setting | Header is only the column names; no settings recorded |
| D-16 | Recalculation | Incremental with cache of completed days | Full lookback recomputation on every recalculation (bounded, but not cached) |
| D-17 | Intrabar updates | `InpIntrabarUpdates` input | No such input; ticks refresh dashboard labels only |
| D-18 | Scoreboard write gating | `InpExportCSV` controls export | `InpExportCSV` also gates the per-row append in `AppendScoreboardRow()` |
| D-19 | Refresh range | 0–60 s, 0 = no timer | **1–600 s** enforced in `OnInit()`; 0 (no timer) is not supported |
| D-20 | Broker offset granularity | Offset in hours, step 0.5 (half-hour offsets such as +5.5) | `InpBrokerGMTOffset` is an **int**; half-hour offsets cannot be represented |
| D-21 | Session time granularity | Session start/end as `HH:MM` strings | Session start/end are **integer UTC hours** only; minute-granularity windows (e.g. 07:30) are impossible |

**Defaults aligned in the 2026-11-27 QA pass (Test Report F9).** Six
defaults that differed from the locked Phase 1 values now match them, so
they are no longer divergences: `InpRefreshSeconds` 30 → **5** (D-3
above), `InpMinSample` 30 → **20** (D-2 above), `InpBrokerGMTOffset`
2 → **0**, `InpShowPDO` true → **false**, `InpAlertApproach` true →
**false**, `InpAlertORBreakout` true → **false**. The last four were
never separate rows in this table; they are recorded here so the
alignment is not lost.

---

## 9. Failure modes and invariants

| Invariant | How v1.0 upholds it | What breaks it |
|---|---|---|
| Completed levels never move | PDH/PDL/PDC/PDO sourced only from the closed previous day; session scans capped at the window end | Changing `InpDayStartHour` or session hours redefines "completed" — levels are recomputed under the new definition, which is correct behaviour, not a violation |
| No look-ahead in probabilities | Lookback loop uses days 1…N and reconstructs each day's level from earlier days only | None in the code paths; verify by hand per `Backtesting_Protocol.md` |
| One forecast per level per day | Forecast captured once per `g_currentDayStart`; scoreboard rows deduplicated by `Date\|Level` | Manually editing the CSV while MT4 runs |
| Finalised rows never change | No update/delete path; `AppendScoreboardRow()` returns early on duplicate keys | Deleting the CSV file (user action, outside the indicator) |
| No repainting of events | Sweep/breakout classification is final once recorded; the ring buffer is append-only | None in the code paths |
| Objects always cleaned up | `OnDeinit()` → `DeleteAllObjects()` (prefix `FLR_`) | Abnormal terminal termination |

---

*End of Technical Architecture — FLR-MT4-001 v1.0.*
