# Forex Level Radar Pro — Source Code Documentation

| Field | Value |
|---|---|
| Project ID | FLR-MT4-001 |
| Product | Forex Level Radar Pro |
| Platform | MetaTrader 4 (MT4), MQL4, `#property strict` |
| Version | 1.0 |
| Source file | `Forex_Level_Radar_Pro.mq4` (1,774 lines) |
| Companion documents | `Technical_Architecture.md`, `Technical_Specification.md`, `Probability_Methodology.md` |

> **Scope.** This document is a function-by-function reference for the
> v1.0 source as written. Function names, line numbers, and input names
> are taken from `Forex_Level_Radar_Pro.mq4`. Where the code differs from
> the Phase 1 design documents, the difference is noted at the function
> concerned. Line numbers refer to the v1.0 file (1,774 lines, after the
> 2026-11-27 QA fixes F1–F12); they will shift if the file is edited — function names are the stable reference.

---

## 1. File header and properties

Lines 1–46 (header comment 1–41, `#property` lines 42–46). Header comment stating the product, the seven engines, the
key definitions (trading day, ONH/ONL = Asian high/low, opening range
from the trading-day start, probability definition, sweep definition, H1
scans), and the requirement of MQL4 build 600+.

```mql4
#property strict
#property copyright "Forex Level Radar Pro - FLR-MT4-001"
#property version   "1.00"
#property description "Analytical key-level / probability / liquidity indicator. No trading."
#property indicator_chart_window
```

No indicator buffers are declared — all output is via chart objects.
No `#import`, no DLL, no `WebRequest`.

### 1.1 Enumerations (lines 49–51)

| Enum | Values | Used by |
|---|---|---|
| `ENUM_FLR_THEME` | `THEME_DARK = 0`, `THEME_LIGHT = 1` | `InpTheme`, `ApplyTheme()` |
| `ENUM_FLR_DST` | `DST_AUTO = 0`, `DST_MANUAL = 1`, `DST_OFF = 2` | `InpDSTMode`, `GetDSTShift()` |
| `ENUM_FLR_TOUCH` | `TOUCH_HIGH_LOW = 0`, `TOUCH_CLOSE = 1` | `InpTouchMethod`, `TouchInWindow()`, `CheckAlerts()` |

Note: the design documents define three touch methods (Bid-only,
spread-adjusted, Ask-based) and three price bases. The code defines two
touch methods (High/Low vs. Close) and implements spread adjustment as a
separate points input (`InpSpreadAdjPoints`). There is no Ask-based mode
and no price-basis input in v1.0.

### 1.2 Level index constants (lines 136–156)

```mql4
#define LV_PDH 0   #define LV_PDL 1   #define LV_PDC 2   #define LV_PDO 3
#define LV_DO 4    #define LV_ONH 5   #define LV_ONL 6   #define LV_ASH 7
#define LV_ASL 8   #define LV_LONH 9  #define LV_LONL 10 #define LV_LONO 11
#define LV_NYH 12  #define LV_NYL 13  #define LV_NYO 14  #define LV_ORH 15
#define LV_ORL 16  #define LV_COUNT 17
#define PR_COUNT 7
#define SWEEP_MAX 100
#define SCAN_MAX 30
```

Probability-level tables (lines 159–162): `g_probLevelIdx[7] =
{LV_PDH, LV_PDL, LV_PDC, LV_ONH, LV_ONL, LV_ORH, LV_ORL}`;
`g_probAbbr[7] = {"PDH","PDL","PDC","ONH","ONL","ORH","ORL"}`;
`g_probIsUp[7] = {true,false,false,true,false,true,false}`;
`g_probBoth[7] = {false,false,true,false,false,false,false}` (PDC touches
either way).

Level name tables (lines 164–165): `g_levelAbbr[17]` and
`g_levelName[17]` (`"PDH","PDL","PDC","PDO","Day Open","ONH","ONL",
"Asian High","Asian Low","London High","London Low","London Open",
"NY High","NY Low","NY Open","ORH","ORL"`).

Sweep tables (lines 168–169): `g_sweepLevelIdx[8] = {LV_PDH, LV_ASH,
LV_LONH, LV_ORH, LV_PDL, LV_ASL, LV_LONL, LV_ORL}`;
`g_sweepIsBuy[8] = {true,true,true,true,false,false,false,false}`.

---

## 2. Function reference

Functions are grouped by engine. "Engine" follows the seven-engine
numbering of the spec.

### 2.1 Time / session helpers — Engine 3

#### `double GetDSTShift(datetime t)` — line 291

- **Purpose:** DST shift (hours) in effect at broker time `t`.
- **Parameters:** `t` — broker time.
- **Returns:** `double` — hours of DST shift.
- **Engine:** 3.
- **Behaviour:** `DST_OFF` → 0. `DST_MANUAL` → `InpDSTShiftHours`.
  `DST_AUTO` → `InpDSTShiftHours` when the broker-time month is April–
  October, else 0. **This is a month-based approximation, not the
  rule-based US/EU DST of the design documents** (`Technical_Specification.md`
  §6.3). Transitions in March and November are wrong under AUTO; use
  MANUAL for exact control.

#### `double BrokerOffsetHours(datetime t)` — line 299

- **Purpose:** Total broker offset from UTC at time `t`.
- **Parameters:** `t` — broker time.
- **Returns:** `double` — offset in hours.
- **Engine:** 3.
- **Behaviour:** Returns 0 when `InpUseUTCReference` is false; otherwise
  `InpBrokerGMTOffset + GetDSTShift(t)`.

#### `datetime BrokerMidnight(datetime t)` — line 306

- **Purpose:** Midnight (00:00 broker time) of the calendar date
  containing `t`.
- **Parameters:** `t` — any broker time.
- **Returns:** `datetime` — broker midnight.
- **Engine:** 3.

#### `datetime TradingDayStart(datetime t)` — line 314

- **Purpose:** Start of the trading day containing `t`.
- **Parameters:** `t` — broker time.
- **Returns:** `datetime` — the most recent `InpDayStartHour:00` broker
  time at or before `t`.
- **Engine:** 3. Used by `OnInit()`, `CheckNewDay()`, and everywhere a
  trading-day boundary is needed. The single trading-day definition in
  the system.

#### `datetime UTCMidnightFor(datetime brokerTime)` — line 323

- **Purpose:** UTC midnight (as an epoch value) of the UTC date
  containing a broker time.
- **Parameters:** `brokerTime` — broker time.
- **Returns:** `datetime` — UTC midnight.
- **Engine:** 3. Used by `SessionWindowForDay()` to anchor UTC session
  windows.

#### `void SessionWindowForDay(datetime dayStart, int startUTC, int endUTC, datetime &sStart, datetime &sEnd)` — line 334

- **Purpose:** Convert a UTC-hour session window to broker datetimes for
  the trading day starting at `dayStart`.
- **Parameters:** `dayStart` — trading-day start (broker time);
  `startUTC` / `endUTC` — session hours in UTC; `sStart` / `sEnd` —
  output broker datetimes (by reference).
- **Returns:** void.
- **Engine:** 3.
- **Behaviour:** Anchors on the UTC midnight of the day, adds the UTC
  hours and the broker offset. If `end <= start` the window crosses
  midnight (+24 h). If the window would start more than an hour before
  the trading-day start, it is shifted forward a day (the session belongs
  to the following UTC date).

### 2.2 H1 scan helpers — Engines 1 and 2

#### `bool ScanHighLow(string sym, datetime start, datetime end, double &hi, double &lo, double &op, double &cl)` — line 352

- **Purpose:** The single aggregation primitive: high/low/open/close of
  the H1 bars whose open time lies in `[start, end)`.
- **Parameters:** `sym` — symbol; `start` / `end` — half-open window
  (broker datetimes); `hi` / `lo` / `op` / `cl` — outputs by reference.
- **Returns:** `bool` — false when no bar exists in the window (or the
  window is empty, or the symbol has no H1 bars). Callers must treat
  false as "level does not exist", never as zero.
- **Engines:** 1, 2.
- **Behaviour:** Bounds the scan with `iBarShift()` on `PERIOD_H1`.
  `hi` = max High, `lo` = min Low, `op` = open of the oldest bar in the
  window, `cl` = close of the newest bar. All level and probability math
  in v1.0 goes through this function.

#### `bool TouchInWindow(string sym, datetime start, datetime end, double level, bool isUp, bool both)` — line 388

- **Purpose:** Test whether a level was touched inside `[start, end)`.
- **Parameters:** `sym`; `start` / `end` — window; `level` — price;
  `isUp` — upward level; `both` — neutral level (the bar's range must
  contain the level).
- **Returns:** `bool` — true on the first bar satisfying the touch rule.
- **Engine:** 2.
- **Behaviour:** Scans H1 bars in the window. `TOUCH_HIGH_LOW`:
  `High >= level − adj` (up), `Low <= level + adj` (down),
  and for a neutral level (`both`, i.e. PDC) the bar's range must
  contain the level: `High >= level − adj` **and**
  `Low <= level + adj`. `TOUCH_CLOSE`: the bar's Close against the
  same widened zone — up `Close >= level − adj`, down
  `Close <= level + adj`, neutral `|Close − level| <= adj`.
  `adj = InpSpreadAdjPoints * Point`, resolved per symbol via
  `MarketInfo(sym, MODE_POINT)` (falling back to the chart symbol's
  point size). Note the widening direction: a positive adjustment
  makes touches *easier*, the opposite of the design documents'
  spread-adjusted method. The neutral High/Low test used to be
  `High >= level OR Low <= level`, which is true for every bar
  (a tautology); it was corrected to AND in the 2026-11-27 QA pass
  (Test Report F2).

#### `void DayWindow(int daysAgo, datetime &start, datetime &end)` — line 425

- **Purpose:** 24-hour trading-day window `daysAgo` days before the
  current trading day, from `g_currentDayStart`.
- **Parameters:** `daysAgo` — 0 = today; `start` / `end` — outputs.
- **Returns:** void. **Engines:** 1, 2.

#### `void DayWindowFor(datetime dayStart, int daysAgo, datetime &start, datetime &end)` — line 430

- **Purpose:** Same as `DayWindow()`, anchored at an explicit `dayStart`
  instead of the current day. Used when evaluating past days (scoreboard
  finalisation, multi-pair scan).
- **Returns:** void. **Engines:** 1, 2.

#### `bool GetDayHL(int daysAgo, double &hi, double &lo, double &op, double &cl)` — line 437

- **Purpose:** Day high/low/open/close for the chart symbol,
  `daysAgo` days back.
- **Returns:** `bool` — false when the day has no H1 bars.
- **Engine:** 1. Thin wrapper over `DayWindow()` + `ScanHighLow()`.

#### `bool GetDayHLFor(string sym, datetime dayStart, int daysAgo, double &hi, double &lo, double &op, double &cl)` — line 442

- **Purpose:** Same as `GetDayHL()`, for an explicit symbol and anchor
  day. Used by the multi-pair scan (`CalcSymbolPDHProb()`).
- **Returns:** `bool`. **Engine:** 1.

#### `bool ForecastLevelValue(int probIdx, int daysAgo, double &value)` — line 451

- **Purpose:** The forecast level for probability index `probIdx` as it
  was known at the start of trading day `daysAgo` — using only earlier
  days. The core of the no-look-ahead guarantee.
- **Parameters:** `probIdx` — 0–6 into the probability tables;
  `daysAgo` — 0 = today; `value` — output.
- **Returns:** `bool` — false when the level cannot be reconstructed.
- **Engine:** 2.
- **Behaviour:** PDH/PDL/PDC from `GetDayHL(daysAgo + 1, …)` (the day
  before the forecast day); ONH/ONL from that day's Asian window;
  ORH/ORL from that day's opening range. Returns false for any other
  level kind (only the 7 probability levels are supported).

#### `void EvalWindow(int probIdx, int daysAgo, datetime &ws, datetime &we)` — line 486

- **Purpose:** Evaluation window for a forecast: from when the level is
  known until the cutoff.
- **Parameters:** `probIdx`; `daysAgo`; `ws` / `we` — outputs.
- **Returns:** void. **Engine:** 2.
- **Behaviour:** Daily levels: day start → `dayStart +
  InpCutoffHour * 3600`, capped at the day end. ONH/ONL: window starts
  at the Asian session end. ORH/ORL: window starts at the end of the
  opening range. An empty window is widened to one hour.

#### `bool DayOutcome(int probIdx, int daysAgo)` — line 507

- **Purpose:** Single-day outcome: did price touch that day's forecast
  level before the cutoff?
- **Parameters:** `probIdx`; `daysAgo`.
- **Returns:** `bool` — touch or not (false also when the level cannot
  be reconstructed).
- **Engine:** 2. Combines `ForecastLevelValue()` + `EvalWindow()` +
  `TouchInWindow()`.
- **Note:** defined but **never called** in v1.0 — neither
  `CalcProbabilities()` nor `FinaliseYesterday()` calls it; both inline
  the same logic (the finalise path duplicates it because `DayOutcome()`
  is anchored to `g_currentDayStart`). Kept as a helper; see Test
  Report A14.

### 2.3 Formatting / category helpers — Engine 7

#### `string FmtPrice(double price)` — line 518

- **Purpose:** Format a price to the symbol's digits, or `"--"` when the
  price is ≤ 0 (level does not exist).
- **Returns:** `string`. **Engine:** 7.

#### `string FmtPct(double v)` — line 523

- **Purpose:** Format a percentage with one decimal plus `"%"`.
- **Returns:** `string`. **Engine:** 7.

#### `string ProbCategory(double prob)` — line 524

- **Purpose:** Category label for a probability, using the configurable
  thresholds (`InpThreshVeryHigh` / `High` / `Moderate` / `Low`).
- **Returns:** `"Very High"` | `"High"` | `"Moderate"` | `"Low"` |
  `"Very Low"`. Boundary values belong to the higher category.
- **Engine:** 7.

#### `color ProbColour(double prob)` — line 532

- **Purpose:** Row colour for a probability: green at/above the High
  threshold, gold at/above Moderate, red below.
- **Returns:** `color` (`g_cGreen` / `g_cYellow` / `g_cRed`).
- **Engine:** 7. Note the colour bands do not distinguish Very High
  from High (both green) or Low from Very Low (both red); the text label
  carries that distinction.

#### `string TimeRemaining(datetime target)` — line 538

- **Purpose:** `H:MM` until `target` from `TimeCurrent()`; `"00:00"`
  once passed.
- **Returns:** `string`. **Engine:** 7.

#### `string TFName(int tf)` — line 546

- **Purpose:** Timeframe code (`"M1"`, `"M15"`, `"H1"`, …) for display.
- **Returns:** `string`. **Engine:** 7.

#### `int CalBucket(double forecastPct)` — line 562

- **Purpose:** Calibration bin index for a forecast percentage: 0 =
  0–29, 1 = 30–49, 2 = 50–64, 3 = 65–79, 4 = 80–100.
- **Returns:** `int` 0–4. **Engine:** 6.

#### `string CalBucketName(int b)` — line 570

- **Purpose:** Bin label (`"0-29%"`, …, `"80-100%"`).
- **Returns:** `string`. **Engine:** 6.

### 2.4 Theme and validation — lifecycle

#### `void ApplyTheme()` — line 585

- **Purpose:** Set the colour globals from `InpTheme`.
- **Returns:** void. Dark: background (13,18,32), panel (17,23,38),
  text white, muted (150,165,190), accent gold, border (55,70,95).
  Light: background (240,240,245), panel (250,250,252), text (20,20,30),
  accent dark gold (180,130,0). Probability colours are set identically
  in both themes (green `clrLimeGreen`, yellow `clrGold`, red `clrTomato`).

#### `void ValidateInputs()` — line 604

- **Purpose:** Log warnings for out-of-range inputs. Called from
  `OnInit()`.
- **Returns:** void.
- **Behaviour:** Prints `FLR: …` messages to the Experts log for:
  refresh seconds outside 5–300; lookback < 5; minimum sample < 5;
  broker offset outside −12…+14; day-start hour outside 0–23; cutoff
  outside 1–24; opening-range minutes not in {15, 30, 60}; approach
  points outside 1–1000; DST shift outside 0–2; thresholds not strictly
  descending. **It warns; it does not correct.** The hard failures are
  in `OnInit()` itself (see below) — including opening-range minutes
  outside {15, 30, 60}, which `OnInit()` now rejects outright instead of
  warning and using the value as-is.

### 2.5 Lifecycle — MT4 entry points

#### `int OnInit()` — line 631

- **Purpose:** Initialise the indicator.
- **Returns:** `INIT_SUCCEEDED`, `INIT_PARAMETERS_INCORRECT`, or
  `INIT_FAILED`.
- **Behaviour:** Sets `g_digits`/`g_point` from the symbol; calls
  `ApplyTheme()` and `ValidateInputs()`; deletes any stale `FLR_`
  objects left by a previous run (`DeleteAllObjects()`); then
  hard-fails with `INIT_PARAMETERS_INCORRECT` when any of these hold:
  `InpProbLookback` outside 5–500; `InpMinSample` outside 5–100 or
  greater than `InpProbLookback`; `InpOpeningRangeMinutes` not in
  {15, 30, 60}; probability thresholds not strictly descending;
  `InpBrokerGMTOffset` outside −12…+14; `InpDSTShiftHours` outside 0–2;
  `InpApproachPoints` outside 1–1000; `InpRefreshSeconds` outside 1–600;
  `InpDayStartHour` outside 0–23 or `InpCutoffHour` outside 1–24. It
  returns `INIT_FAILED` when the chart has fewer than 50 bars.
  Zeroes all state arrays; parses `InpScanSymbols` into
  `g_scanSymbols[]` (max 30, empty entries skipped); sets
  `g_currentDayStart`; loads the scoreboard CSV when the scoreboard and
  persistent storage are both enabled; starts the timer; logs the
  initialisation line with symbol, timeframe, lookback,
  minimum sample, broker offset, and day start.

#### `void OnDeinit(const int reason)` — line 743

- **Purpose:** Clean up on removal / terminal shutdown / recompilation.
- **Returns:** void.
- **Behaviour:** `EventKillTimer()`; `DeleteAllObjects()`; log line with
  the deinitialisation reason code. No CSV flush is required (rows are
  appended at finalisation, not buffered).

#### `int OnCalculate(const int rates_total, const int prev_calculated, const datetime &time[], const double &open[], const double &high[], const double &low[], const double &close[], const long &tick_volume[], const long &volume[], const int &spread[])` — line 750

- **Purpose:** Per-tick entry point.
- **Returns:** `rates_total`.
- **Behaviour:** Returns immediately when `rates_total < 50`. Detects a
  new bar by comparing the last bar's open time with `g_lastBarTime`.
  Calls `RecalcAll(isNewBar)` on a new bar, on the first calculation, or
  when the refresh interval has elapsed; otherwise refreshes only the
  dashboard labels (`DrawDashboard()`). The price arrays are used only
  for the new-bar test and for `Close[1]`/`High[0]`/`Low[0]` in the alert
  and status checks — all aggregation uses H1 history functions, not the
  chart arrays.

#### `void OnTimer()` — line 771

- **Purpose:** Timer entry point (fires every `InpRefreshSeconds`).
- **Returns:** void.
- **Behaviour:** Same gating as `OnCalculate()`: full recalculation when
  the interval has elapsed, else a dashboard-only refresh.

#### `void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)` — line 779

- **Purpose:** Dashboard interaction.
- **Returns:** void.
- **Behaviour:** Handles `CHARTEVENT_OBJECT_CLICK` only, for four
  objects: `FLR_DASH_TOGGLE` (minimise/expand dashboard),
  `FLR_DASH_CLOSE` (hide dashboard and delete all objects — re-attach to
  restore), `FLR_SB_TOGGLE` (minimise/expand scoreboard),
  `FLR_SB_EXPORT` (write the summary CSV). No drag handling exists in
  v1.0. Never modifies market data.

### 2.6 Master recalculation and day rollover — Engine 5

#### `void RecalcAll(bool isNewBar)` — line 809

- **Purpose:** The single recalculation pipeline, run on a new bar, on
  first calculation, and on timer expiry.
- **Parameters:** `isNewBar` — whether a new bar was detected (passed to
  `CheckLiquidity()` for the excursion bar counter).
- **Returns:** void.
- **Order:** `CheckNewDay()` → `CalcSessions()` → `CalcLevels()` →
  `CalcProbabilities()` → `CheckLiquidity(isNewBar)` → `CheckAlerts()`
  → `DrawLevels()` → `DrawDashboard()` (if enabled) →
  `DrawScoreboardPanel()` (if enabled) → `DrawScanPanel()` (if enabled)
  → `ChartRedraw()`. Sets `g_lastCalcTime` and clears `g_firstCalc`.

#### `void CheckNewDay()` — line 827

- **Purpose:** Detect the trading-day rollover and reset daily state.
- **Returns:** void.
- **Behaviour:** Compares `TradingDayStart(TimeCurrent())` with
  `g_currentDayStart`. On change: calls `FinaliseYesterday()` first,
  then resets `g_touchedToday[]` and the excursion state, and resets
  the daily sweep/breakout counters (`g_sweepCount`,
  `g_breakoutCount`) so the dashboard's "SWEEPS TODAY / BREAKOUTS"
  are per-day, not cumulative since attach. If `InpDailyReset` is
  true, zeroes the *displayed* scoreboard totals (the CSV file is
  untouched).

### 2.7 Engine 1 — levels; Engine 3 — sessions

#### `void CalcSessions()` — line 851

- **Purpose:** Session windows, current session, market status, cutoff.
- **Returns:** void. **Engines:** 3, 5.
- **Behaviour:** Computes the three session windows for the current
  trading day (`SessionWindowForDay()`), sets
  `g_cutoffTime = g_currentDayStart + InpCutoffHour * 3600`, and derives
  the current session from the UTC hour: New York first, then London,
  then Asian (later-starting wins on overlap). A custom session
  (`InpUseCustomSession`) is checked first and overrides when the hour
  falls inside it. Market status is `Active` inside any session,
  `Closed` otherwise.

#### `void CalcLevels()` — line 881

- **Purpose:** Rebuild all 17 levels for the current trading day.
- **Returns:** void. **Engine:** 1.
- **Behaviour:** Resets `g_levels[]`/`g_levelValid[]`; previous day via
  `GetDayHL(1, …)` → PDH/PDL/PDC/PDO; day-before-previous via
  `GetDayHL(2, …)` → `g_prevLevels[]`; current day open via
  `GetDayHL(0, …)` → DO; Asian window capped at now → ONH/ONL **and**
  ASH/ASL (same scan, same prices — see `User_Manual.md` §2.2); London
  and New York windows capped at now, only once the session has started;
  opening range `[dayStart, min(dayStart + InpOpeningRangeMinutes, now))`
  → ORH/ORL. Levels whose window contains no bars stay invalid. A
  comment in the code states the invariant: completed levels never shift,
  because their scans are capped at their window ends.

### 2.8 Engine 2 — probability

#### `void CalcProbabilities()` — line 951

- **Purpose:** The seven probabilities, their live statuses, and the
  forecast capture for the scoreboard.
- **Returns:** void. **Engine:** 2.
- **Behaviour:** For each probability level, loops days 1…`InpProbLookback`
  (lookback clamped to ≥ 5, minimum sample clamped to ≥ 5 in the logic):
  reconstructs the day's level (`ForecastLevelValue()`), evaluates the
  touch (`EvalWindow()` + `TouchInWindow()`), counts eligible days and
  touches, and accumulates the per-day-of-week counts. Sets `g_prob[]`,
  `g_probN[]`, `g_probTouches[]`, `g_probValid[]`. Then computes the live
  status for today (`"Hit"` / `"Waiting"` / `"Insufficient"`) from the
  current bar's High/Low plus an H1 scan of today's evaluation window up
  to now. The live check is direction-aware: upward levels use the
  current bar's High, downward levels its Low, and the neutral PDC
  requires the bar's range to contain the level (the same AND rule as
  `TouchInWindow()`). Finally, captures today's forecast into `g_yestForecast[]` /
  `g_yestN[]` the first time the current trading day is seen — frozen
  from then on.
- **Not implemented:** Wilson intervals, Brier skill vs. climatology,
  and any display of the per-day-of-week probabilities (the counts are
  computed but unused by the dashboard).

### 2.9 Engine 4 — liquidity

#### `void RecordSweep(int sweepIdx, double excursionPts, datetime confirmTime)` — line 1039

- **Purpose:** Record a classified sweep and draw its chart marker.
- **Parameters:** `sweepIdx` — 0–7 into the sweep tables;
  `excursionPts` — excursion beyond the level, in points;
  `confirmTime` — confirmation time.
- **Returns:** void. **Engine:** 4.
- **Behaviour:** Writes the ring-buffer slot (`g_sweepHead`, wraps at
  100), increments `g_sweepCount` (capped at 100), and creates/updates
  the arrow object `FLR_SWEEP_<slot>` (`OBJ_ARROW`, code 234 for
  buy-side / 233 for sell-side, orange-red / dodger blue, width 2) at
  the excursion extreme price and `Time[1]`.

#### `void CheckLiquidity(bool isNewBar)` — line 1063

- **Purpose:** Sweep vs. sustained-breakout classification for the 8
  monitored levels.
- **Parameters:** `isNewBar` — increments the per-level excursion bar
  counter.
- **Returns:** void. **Engine:** 4.
- **Behaviour:** Per level: if not exceeded and the live Bid is beyond
  the level, enter the exceeded state (record time, extreme, bar count
  0, and the open time of the excursion bar). While exceeded, track the
  worst excursion; classification is **deferred until the excursion bar
  has closed** (`Time[1] >= g_exceedBarTime[s]`) — no sweep or breakout
  is recorded on ticks while the excursion candle is still forming.
  On the last closed bar's close: closed back inside within
  `InpConfirmBars` bars **and** with no intervening close beyond the
  level → sweep (`RecordSweep()` + throttled alert); a close back
  inside *after* a close went beyond the level is a **failed breakout**,
  not a sweep — the state is cleared without recording (no
  failed-breakout event class exists in v1.0); still beyond for
  `InpBreakoutBars` bars → sustained breakout (`g_breakoutCount++`,
  OR alert only for ORH/ORL); closed back after the confirmation window
  but before the breakout window → state dropped silently. State resets
  at the day rollover.
- **Note:** the excursion trigger is the live Bid, not a closed candle's
  high/low — this differs from the design documents' closed-candle
  excursion detection.

### 2.10 Alerts — Engine 5

#### `bool BarTouchesLevel(int lv, double h, double l, double c)` — line 1168

- **Purpose:** Direction-aware touch test for one closed bar, used by
  `CheckAlerts()`.
- **Parameters:** `lv` — level index 0–16; `h` / `l` / `c` — the bar's
  high, low, close.
- **Returns:** `bool`.
- **Engine:** 5.
- **Behaviour:** Under `TOUCH_HIGH_LOW`: upward levels (PDH, ONH, ASH,
  LONH, NYH, ORH) touch when `High >= level − adj`; downward levels
  (PDL, ONL, ASL, LONL, NYL, ORL) when `Low <= level + adj`; neutral
  levels (PDC, PDO, DO, LONO, NYO) when the bar's range contains the
  level (`High >= level − adj` **and** `Low <= level + adj`). Under
  `TOUCH_CLOSE`: up `Close >= level − adj`, down
  `Close <= level + adj`, neutral `|Close − level| <= adj`.
  `adj = InpSpreadAdjPoints * g_point`. (Added in the 2026-11-27 QA
  pass, Test Report F3: the old code tested every level with the
  range-contains test, which misses touches where the whole bar sits
  beyond an upward/downward level, and tested the Close method with
  `|Close − level| <= adj` for every level, which with `adj = 0` only
  fires on an exact close.)

#### `void CheckAlerts()` — line 1194

- **Purpose:** Approach and touch alerts for all 17 levels.
- **Returns:** void. **Engine:** 5.
- **Behaviour:** Returns immediately when both approach and touch alerts
  are off. Approach: live Bid within `InpApproachPoints` of a level.
  Touch: the last closed bar, tested direction-aware via
  `BarTouchesLevel()` (see above). Each alert is throttled to one
  per hour per level (`g_lastApproachAlert[]`, `g_lastTouchAlert[]`) and
  delivered via `Alert()` / `PlaySound("alert.wav")` /
  `SendNotification()` according to `InpAlertPopup` / `InpAlertSound` /
  `InpAlertPush`. A touch alert also sets `g_touchedToday[]`.

### 2.11 Engine 6 — scoreboard

#### `string ScoreboardFileName()` — line 1232

- **Purpose:** Scoreboard file name for the chart symbol.
- **Returns:** `"FLR_Scoreboard_" + _Symbol + ".csv"`. **Engine:** 6.

#### `bool ScoreboardKeyExists(string key)` — line 1236

- **Purpose:** Deduplication lookup over `g_sbLoadedKeys[]`.
- **Parameters:** `key` — `"Date|Level"`.
- **Returns:** `bool`. **Engine:** 6.

#### `void ScoreboardAddKey(string key)` — line 1242

- **Purpose:** Append a key to `g_sbLoadedKeys[]` (cap 5,000).
- **Returns:** void. **Engine:** 6.

#### `void ScoreboardAccumulate(int probIdx, double forecast, int touched, int dow)` — line 1250

- **Purpose:** Fold one finalised forecast into all in-memory
  aggregates (totals, per-level, per-day-of-week, Brier sum,
  calibration bins).
- **Parameters:** `probIdx` — 0–6; `forecast` — probability %;
  `touched` — 0/1; `dow` — 0–6.
- **Returns:** void. **Engine:** 6.

#### `void LoadScoreboard()` — line 1272

- **Purpose:** Load the scoreboard CSV into memory at `OnInit()`.
- **Returns:** void. **Engine:** 6.
- **Behaviour:** Opens the file `FILE_CSV | FILE_READ` with delimiter
  `","`. Missing file → log line, fresh start. Resets all aggregates,
  then reads row by row: skips the header (`"Date"`), skips rows whose
  level abbreviation is not one of the 7 probability levels, records
  each key, and accumulates. Logs the loaded observation count.

#### `void AppendScoreboardRow(string dateStr, int probIdx, double forecast, int n, int touched, int dow)` — line 1319

- **Purpose:** Append one finalised forecast row to the CSV.
- **Parameters:** `dateStr` — `"yyyy.mm.dd"`; `probIdx`; `forecast` —
  frozen %; `n` — sample size; `touched` — 0/1; `dow` — 0–6.
- **Returns:** void. **Engine:** 6.
- **Behaviour:** Returns without writing when the scoreboard, persistent
  storage, or CSV export is disabled, or when the `Date|Level` key
  already exists. Otherwise opens the file `FILE_READ | FILE_WRITE`,
  seeks to the end, writes the header when the file is empty
  (`Date,Level,ForecastPct,N,Touched,DOW`), writes the row (forecast to
  2 dp), closes, records the key, and accumulates. Note:
  `InpExportCSV` gates the per-row append as well as the summary export.

#### `void FinaliseYesterday()` — line 1345

- **Purpose:** Evaluate yesterday's frozen forecasts and append one
  scoreboard row per level.
- **Returns:** void. **Engine:** 6.
- **Behaviour:** Returns when the scoreboard is disabled, no forecast is
  held, or yesterday's cutoff has not passed yet. It also refuses to
  finalise the current trading day (the guard compares against
  `TradingDayStart(TimeCurrent())`, not against `g_currentDayStart`,
  which `CheckNewDay()` has not yet updated at the time of the call).
  For each of the 7 levels, **skips the level when yesterday's forecast
  had insufficient data** (`g_yestN[p] < InpMinSample` — no forecast
  is scored for that level); otherwise reconstructs yesterday's forecast
  level from the day before yesterday (daily levels) / yesterday's Asian
  window / yesterday's opening range, evaluates the touch over
  yesterday's evaluation window (same rules as `EvalWindow()`), and
  calls `AppendScoreboardRow()` with the frozen forecast and N. Clears
  `g_yestHasForecast` afterwards and logs the finalised date. Past rows
  are never edited.

#### `void ExportScoreboardSummary()` — line 1410

- **Purpose:** Write the two-column summary CSV.
- **Returns:** void. **Engine:** 6.
- **Behaviour:** Writes `FLR_Scoreboard_Summary_<SYMBOL>.csv`
  (`FILE_CSV | FILE_WRITE`, overwrites): Symbol, TotalObservations,
  TotalTouches, AverageForecastPct, ActualTouchRatePct,
  ForecastMinusActualPct, BrierScore (4 dp), per-level Obs/ForecastPct/
  ActualPct, and per-bin Obs/ActualPct. Called from `OnChartEvent()`
  (`FLR_SB_EXPORT`).

### 2.12 Object helpers and drawing — Engine 7

#### `void DeleteAllObjects()` — line 1448

- **Purpose:** Delete every chart object owned by the indicator.
- **Returns:** void. **Engine:** 7.
- **Behaviour:** `ObjectsDeleteAll(0, g_prefix)` with `g_prefix =
  "FLR_"`.

#### `void PutLabel(string name, int x, int y, string text, color clr, int size)` — line 1452

- **Purpose:** Create-or-update a dashboard label (`OBJ_LABEL`, Arial,
  corner `InpDashCorner`, not selectable, not in the background).
- **Parameters:** `name` — without the `FLR_` prefix (added inside);
  `x` / `y` — pixel offsets from the corner; `text`; `clr`; `size`.
- **Returns:** void. **Engine:** 7.

#### `void PutRect(string name, int x, int y, int w, int h, color bg, color border)` — line 1467

- **Purpose:** Create-or-update a panel background
  (`OBJ_RECTANGLE_LABEL`, flat border, not selectable).
- **Parameters:** `name`; `x` / `y`; `w` / `h` — pixels; `bg`;
  `border`.
- **Returns:** void. **Engine:** 7.

#### `bool LevelVisible(int lv)` — line 1483

- **Purpose:** Map a level index to its show/hide input.
- **Parameters:** `lv` — 0–16.
- **Returns:** `bool`. **Engine:** 7.
- **Mapping:** PDH→`InpShowPDH`, PDL→`InpShowPDL`, PDC→`InpShowPDC`,
  PDO→`InpShowPDO`, DO→`InpShowDO`, ONH→`InpShowONH`, ONL→`InpShowONL`,
  ASH/ASL→`InpShowAsianHL`, LONH/LONL/LONO→`InpShowLondonHL`,
  NYH/NYL/NYO→`InpShowNYHL`, ORH/ORL→`InpShowORHL`.

#### `color LevelColour(int lv)` — line 1501

- **Purpose:** Colour per level kind.
- **Returns:** `color`. **Engine:** 7.
- **Mapping:** PDH dodger blue; PDL orange-red; PDC gold; PDO grey; DO
  white; ONH/ONL medium purple; ASH/ASL aqua; LONH/LONL/LONO lime
  green; NYH/NYL/NYO hot pink; ORH/ORL orange; default silver.

#### `int LevelStyle(int lv)` — line 1518

- **Purpose:** Line style per level kind.
- **Returns:** `int` (`STYLE_SOLID` / `STYLE_DASH` / `STYLE_DOT` /
  `STYLE_DASHDOT`). **Engine:** 7.
- **Mapping:** PDH/PDL solid; PDC dash; PDO/DO dot; ONH/ONL dash-dot;
  ASH/ASL dash; LONH/LONL solid; NYH/NYL dash; ORH/ORL solid.

#### `void DrawLevels()` — line 1537

- **Purpose:** Draw (or delete) all level lines and labels.
- **Returns:** void. **Engine:** 7.
- **Behaviour:** For each of the 17 levels: when visible and valid,
  create-or-update `FLR_LVL_<ABBR>` (`OBJ_HLINE`, width 2 for PDH/PDL,
  1 otherwise, in the background) and `FLR_LBL_<ABBR>` (`OBJ_TEXT`,
  Arial 8, anchored at the current bar's time, `" <ABBR> <price>"`);
  otherwise delete both objects. Then the prior-day lines
  `FLR_PREV_<ABBR>` (dim grey, dotted, PDH/PDL/PDC/PDO only) when
  `InpShowPriorDay` is on and the day-before-previous values exist.

#### `void DrawDashboard()` — line 1591

- **Purpose:** Draw the main dashboard panel.
- **Returns:** void. **Engine:** 7.
- **Behaviour:** Background `FLR_DASH_BG` (322 × 556 px expanded, 34 px
  minimised); title `FOREX LEVEL RADAR PRO`; toggle `[-]`/`[+]` and
  close `[x]` (made selectable after creation, so `OnChartEvent()`
  receives the clicks); header rows (pair, timeframe, session, market
  status, current price, daily open, PDH/PDL/PDC, Asian/London/NY H/L,
  OR H/L with duration, sweeps/breakouts counts, cutoff and time
  remaining); probability table header `LEVEL   PRICE        ODDS   N
  STATUS` and one row per probability level (insufficient-data rows show
  `--` and `INSUFFICIENT DATA` in the muted colour); two footnote lines.
  Returns early when minimised (title bar only).

#### `void DrawScoreboardPanel()` — line 1656

- **Purpose:** Draw the scoreboard panel below the dashboard.
- **Returns:** void. **Engine:** 7.
- **Behaviour:** Background `FLR_SB_BG` (322 px wide, Y + 566; 430 px
  tall with calibration, 300 px without; 34 px minimised); title
  `SCOREBOARD`, toggle, `[Export]` button (both selectable); headline
  rows (total observations, average forecast, actual touch rate,
  forecast-minus-actual, Brier score to 4 dp); per-level rows; per-day-
  of-week rows (Sun–Sat, 8 pt, muted); calibration table when
  `InpShowCalibration` is on. Returns early when the scoreboard is
  disabled or the panel is minimised.

#### `double CalcSymbolPDHProb(string sym, int &nOut, int &tOut)` — line 1715

- **Purpose:** PDH touch probability for one symbol, for the multi-pair
  scan.
- **Parameters:** `sym` — symbol; `nOut` / `tOut` — eligible days and
  touches (outputs).
- **Returns:** `double` — probability %, or −1 when the symbol has no
  usable data.
- **Engine:** 7 (scan).
- **Behaviour:** Uses the symbol's own point size (resolved inside
  `TouchInWindow()` via `MarketInfo(sym, MODE_POINT)`); caps the
  lookback at 50 days for speed; returns −1 when the symbol has fewer
  than 100 H1 bars, and −1 when fewer than 5 eligible days are found.
  Same touch logic as the main engine — the scan calls
  `TouchInWindow()`, which honours the `InpTouchMethod` input and the
  spread adjustment in the scanned symbol's points.

#### `void DrawScanPanel()` — line 1742

- **Purpose:** Draw the multi-pair scan panel.
- **Returns:** void. **Engine:** 7.
- **Behaviour:** Returns when the scan is disabled. Background
  `FLR_SCAN_BG` (250 px wide, at X + 332, height 34 + 17 × symbol count
  + 8); title `MULTI-PAIR PDH ODDS`; one `FLR_SCAN_<i>` label per
  symbol, coloured by `ProbColour()` or muted with `-- (no data)`.
  Updates `g_scanText[]` as it goes.

---

## 3. Input catalogue

Every `input` in the file, in declaration order (lines 58–131), with its
type, default, and meaning. This is the authoritative list for presets:
a `.set` file must only contain names from this table.

### 3.1 General

| Input | Type | Default | Meaning / valid range |
|---|---|---|---|
| `InpShowDashboard` | bool | `true` | Show the dashboard panel |
| `InpDashCorner` | `ENUM_BASE_CORNER` | `CORNER_LEFT_UPPER` | Dashboard anchor corner |
| `InpDashX` | int | `10` | Dashboard X offset (px) from the corner |
| `InpDashY` | int | `15` | Dashboard Y offset (px) from the corner |
| `InpTheme` | `ENUM_FLR_THEME` | `THEME_DARK` | `0` = Dark, `1` = Light |
| `InpRefreshSeconds` | int | `5` | Recalculation / timer interval (seconds). Hard-fail outside 1–600; warning outside 5–300 |
| `InpHistoryDays` | int | `200` | **Declared but unused in v1.0.** No function reads it |

### 3.2 Levels — show / hide

| Input | Type | Default | Controls |
|---|---|---|---|
| `InpShowPDH` | bool | `true` | PDH line/label |
| `InpShowPDL` | bool | `true` | PDL line/label |
| `InpShowPDC` | bool | `true` | PDC line/label |
| `InpShowPDO` | bool | `false` | PDO line/label |
| `InpShowDO` | bool | `true` | DO line/label |
| `InpShowONH` | bool | `true` | ONH line/label |
| `InpShowONL` | bool | `true` | ONL line/label |
| `InpShowAsianHL` | bool | `true` | ASH/ASL lines/labels |
| `InpShowLondonHL` | bool | `true` | LONH/LONL/LONO lines/labels |
| `InpShowNYHL` | bool | `true` | NYH/NYL/NYO lines/labels |
| `InpShowORHL` | bool | `true` | ORH/ORL lines/labels |
| `InpShowPriorDay` | bool | `true` | Faded day-before-previous PDH/PDL/PDC/PDO lines |

### 3.3 Sessions

| Input | Type | Default | Meaning / valid range |
|---|---|---|---|
| `InpUseUTCReference` | bool | `true` | Convert UTC session windows to broker time. `false` = broker time is treated as UTC |
| `InpBrokerGMTOffset` | int | `0` | Broker offset from UTC, hours (−12…+14). Hard-fail outside that range |
| `InpDSTMode` | `ENUM_FLR_DST` | `DST_AUTO` | `0` = Auto (Apr–Oct), `1` = Manual, `2` = Off |
| `InpDSTShiftHours` | double | `1.0` | DST shift, hours (0–2) |
| `InpAsianStartUTC` | int | `0` | Asian session start, UTC hour |
| `InpAsianEndUTC` | int | `9` | Asian session end, UTC hour |
| `InpLondonStartUTC` | int | `7` | London session start, UTC hour |
| `InpLondonEndUTC` | int | `16` | London session end, UTC hour |
| `InpNYStartUTC` | int | `12` | New York session start, UTC hour |
| `InpNYEndUTC` | int | `21` | New York session end, UTC hour |
| `InpDayStartHour` | int | `0` | Trading-day start, **broker** hour (0–23). Hard-fail outside |
| `InpOpeningRangeMinutes` | int | `30` | Opening-range duration, minutes. Must be 15, 30 or 60 — `OnInit()` hard-fails otherwise |
| `InpUseCustomSession` | bool | `false` | Use the single custom session instead of the three standard ones |
| `InpCustomStartUTC` | int | `8` | Custom session start, UTC hour |
| `InpCustomEndUTC` | int | `12` | Custom session end, UTC hour |
| `InpCustomName` | string | `"Custom"` | Custom session display name |

### 3.4 Probability

| Input | Type | Default | Meaning / valid range |
|---|---|---|---|
| `InpProbLookback` | int | `100` | Lookback, eligible trading days (20/50/100/200 or custom, ≥ 5). Hard-fail outside 5–500; clamped to 5 in the logic |
| `InpMinSample` | int | `20` | Minimum sample size N (≥ 5). Hard-fail outside 5–100 or above the lookback; clamped to 5 in the logic. **Default 20, matching the design documents** |
| `InpCutoffHour` | int | `21` | Evaluation cutoff, hours after the trading-day start (1–24). Hard-fail outside. **Broker-time hours from the day start** |
| `InpTouchMethod` | `ENUM_FLR_TOUCH` | `TOUCH_HIGH_LOW` | `0` = High/Low, `1` = Close |
| `InpSpreadAdjPoints` | double | `0.0` | Spread adjustment, points (0–50). Widens the touch zone; see `TouchInWindow()` |
| `InpThreshVeryHigh` | double | `80.0` | Very High threshold % |
| `InpThreshHigh` | double | `65.0` | High threshold % |
| `InpThreshModerate` | double | `50.0` | Moderate threshold % |
| `InpThreshLow` | double | `30.0` | Low threshold % |

Thresholds must be strictly descending; `OnInit()` hard-fails otherwise
(`ValidateInputs()` also warns). The probability categories are documented in
`User_Manual.md` §3.4.

### 3.5 Scoreboard

| Input | Type | Default | Meaning |
|---|---|---|---|
| `InpEnableScoreboard` | bool | `true` | Enable the scoreboard (panel + finalisation) |
| `InpPersistentStorage` | bool | `true` | Load/append the CSV file |
| `InpDailyReset` | bool | `false` | Reset displayed totals each morning (CSV kept) |
| `InpExportCSV` | bool | `true` | Write the CSV files. **Gates both the per-row append and the summary export** |
| `InpShowCalibration` | bool | `true` | Show the calibration table in the scoreboard panel |

### 3.6 Alerts

| Input | Type | Default | Meaning / valid range |
|---|---|---|---|
| `InpAlertApproach` | bool | `false` | Alert when price approaches a level |
| `InpAlertTouch` | bool | `true` | Alert when a level is touched |
| `InpAlertSweep` | bool | `true` | Alert on a liquidity sweep |
| `InpAlertORBreakout` | bool | `false` | Alert on an opening-range breakout (ORH/ORL only) |
| `InpAlertSound` | bool | `true` | Play `alert.wav` |
| `InpAlertPopup` | bool | `true` | MT4 `Alert()` popup |
| `InpAlertPush` | bool | `false` | `SendNotification()` push (requires MT4 push configured) |
| `InpApproachPoints` | int | `100` | Approach distance, points (1–1000). Note: points, not pips |
| `InpConfirmBars` | int | `3` | Sweep confirmation window, bars (1–10) |
| `InpBreakoutBars` | int | `3` | Sustained-breakout bars (1–10) |

### 3.7 Multi-pair scan

| Input | Type | Default | Meaning |
|---|---|---|---|
| `InpEnableScan` | bool | `false` | Enable the multi-pair scan panel |
| `InpScanSymbols` | string | `"EURUSD,GBPUSD,USDJPY,USDCHF,USDCAD,AUDUSD,NZDUSD,EURGBP,EURJPY,GBPJPY,AUDJPY,CADJPY,CHFJPY,EURAUD,GBPAUD"` | Comma-separated symbols, up to 30 |

---

## 4. Chart-object naming scheme

Every object the indicator creates starts with the prefix `FLR_`
(`g_prefix`, line 174). `DeleteAllObjects()` removes exactly that prefix.

| Object name | Type | Created by | Notes |
|---|---|---|---|
| `FLR_LVL_<ABBR>` | `OBJ_HLINE` | `DrawLevels()` | One per level kind; ABBR from `g_levelAbbr[]` (PDH, LONH, …) |
| `FLR_LBL_<ABBR>` | `OBJ_TEXT` | `DrawLevels()` | Label next to the line, `" <ABBR> <price>"` |
| `FLR_PREV_<ABBR>` | `OBJ_HLINE` | `DrawLevels()` | Prior-day PDH/PDL/PDC/PDO only, dim grey dotted |
| `FLR_SWEEP_<slot>` | `OBJ_ARROW` | `RecordSweep()` | Slot 0–99, ring buffer; arrow code 234 (buy-side) / 233 (sell-side) |
| `FLR_DASH_BG` | `OBJ_RECTANGLE_LABEL` | `DrawDashboard()` | Dashboard background, 322 × 556 px (34 px minimised) |
| `FLR_DASH_TITLE` | `OBJ_LABEL` | `DrawDashboard()` | `FOREX LEVEL RADAR PRO` |
| `FLR_DASH_TOGGLE` | `OBJ_LABEL` | `DrawDashboard()` | `[-]` / `[+]`, selectable |
| `FLR_DASH_CLOSE` | `OBJ_LABEL` | `DrawDashboard()` | `[x]`, selectable |
| `FLR_D_*` | `OBJ_LABEL` | `DrawDashboard()` | Header rows and probability rows (`D_PAIR`, `D_TF`, `D_SESS`, `D_STATUS`, `D_PRICE`, `D_DO`, `D_PDH`, `D_PDL`, `D_PDC`, `D_ASH`, `D_LON`, `D_NY`, `D_OR`, `D_SWEEP`, `D_CUT`, `D_PROB_H`, `D_PROB_<0–6>`, `D_NOTE`, `D_NOTE2`) |
| `FLR_SB_BG` | `OBJ_RECTANGLE_LABEL` | `DrawScoreboardPanel()` | Scoreboard background, 322 × 430/300 px (34 px minimised) |
| `FLR_SB_TITLE` | `OBJ_LABEL` | `DrawScoreboardPanel()` | `SCOREBOARD` |
| `FLR_SB_TOGGLE` | `OBJ_LABEL` | `DrawScoreboardPanel()` | `[-]` / `[+]`, selectable |
| `FLR_SB_EXPORT` | `OBJ_LABEL` | `DrawScoreboardPanel()` | `[Export]`, selectable |
| `FLR_SB_*` | `OBJ_LABEL` | `DrawScoreboardPanel()` | Totals, per-level, per-day-of-week, calibration rows (`SB_TOT`, `SB_FC`, `SB_ACT`, `SB_DIFF`, `SB_BRIER`, `SB_LV_<0–6>`, `SB_DOW_<0–6>`, `SB_CAL_H`, `SB_CAL_<0–4>`) |
| `FLR_SCAN_BG` | `OBJ_RECTANGLE_LABEL` | `DrawScanPanel()` | Scan background, 250 px wide |
| `FLR_SCAN_TITLE` | `OBJ_LABEL` | `DrawScanPanel()` | `MULTI-PAIR PDH ODDS` |
| `FLR_SCAN_<i>` | `OBJ_LABEL` | `DrawScanPanel()` | One row per scanned symbol |

Objects are created once and updated in place on each draw
(`ObjectFind()` → create if missing, then set properties). Objects for
levels that become hidden or invalid are deleted on the next draw. No
object is ever left behind by design: removal of the indicator deletes
the whole `FLR_` prefix.

---

## 5. Global state — quick index

| Group | Globals |
|---|---|
| Control | `g_prefix`, `g_lastBarTime`, `g_lastCalcTime`, `g_currentDayStart`, `g_dashMinimized`, `g_dashHidden`, `g_sbMinimized`, `g_firstCalc`, `g_digits`, `g_point` |
| Levels | `g_levels[17]`, `g_levelValid[17]`, `g_prevLevels[17]`, `g_prevValid[17]`, `g_touchedToday[17]` |
| Probability | `g_prob[7]`, `g_probN[7]`, `g_probTouches[7]`, `g_probValid[7]`, `g_probStatus[7]`, `g_probDowN[7][7]`, `g_probDowTouch[7][7]` |
| Sessions | `g_sessionName`, `g_marketStatus`, `g_cutoffTime`, `g_asianStart/End`, `g_londonStart/End`, `g_nyStart/End` |
| Liquidity | `g_sweepTime[100]`, `g_sweepLevel[100]`, `g_sweepDir[100]`, `g_sweepExcPts[100]`, `g_sweepConfirm[100]`, `g_sweepHead`, `g_sweepCount`, `g_breakoutCount`, `g_exceeded[8]`, `g_exceedTime[8]`, `g_exceedMax[8]`, `g_exceedBars[8]`, `g_exceedClosedBeyond[8]`, `g_exceedBarTime[8]`, `g_lastSweepAlert[8]`, `g_lastApproachAlert[17]`, `g_lastTouchAlert[17]`, `g_lastORAlert` |
| Scoreboard | `g_sbTotalObs`, `g_sbTotalTouches`, `g_sbSumForecast`, `g_sbSumBrier`, `g_sbBrierN`, `g_sbLevelObs[7]`, `g_sbLevelTouches[7]`, `g_sbLevelSumFc[7]`, `g_sbDowObs[7]`, `g_sbDowTouch[7]`, `g_sbCalObs[5]`, `g_sbCalTouch[5]`, `g_sbLoadedKeys[5000]`, `g_sbLoadedCount`, `g_yestForecast[7]`, `g_yestN[7]`, `g_yestDayStart`, `g_yestHasForecast`, `g_yestDateStr` |
| Scan | `g_scanSymbols[30]`, `g_scanCount`, `g_scanText[30]` |
| Theme | `g_cBg`, `g_cBg2`, `g_cText`, `g_cMuted`, `g_cAccent`, `g_cBorder`, `g_cGreen`, `g_cYellow`, `g_cRed`, `g_cPanel` |

---

*End of Source Code Documentation — FLR-MT4-001 v1.0.*
