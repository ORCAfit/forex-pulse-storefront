# Forex Level Radar Pro — Technical Specification

| Field | Value |
|---|---|
| Project ID | FLR-MT4-001 |
| Product | Forex Level Radar Pro |
| Platform | MetaTrader 4 (MT4) |
| Language | MQL4 |
| Version | 1.0 |
| Status | Phase 1 — Design Authority |
| Companion document | `Probability_Methodology.md` (mathematical authority) |
| Source spec | `../FLR-MT4-001-spec.md` |

> **Authority rule.** This document and `Probability_Methodology.md` are the design
> authority for the MQL4 implementation. Where the two documents disagree, the
> more restrictive (no-look-ahead, no-repaint) reading governs, and the
> discrepancy must be resolved by amending both documents before code is changed.
> No value in either document is a placeholder. Every default, range, and
> formula stated here is the value the implementation must use unless the user
> changes it through a documented input.
>
> This is an **analytical indicator, not an Expert Advisor**. It never places,
> modifies, or closes trades. It never requires a paid third-party indicator
> and must not rely on any undocumented external DLL.

---

## 1. Purpose and scope

Forex Level Radar Pro identifies important market levels, calculates the
historical probability that price touches each level, monitors session-based
liquidity, updates its display as new candles develop, and maintains a
persistent, objective performance scoreboard.

In scope:

- Automatic daily, overnight/Asian, London, New York, and opening-range levels.
- Historical touch probabilities, conditioned by pair, level, session, and
  day of week.
- Session intelligence for Asian, London, and New York.
- Liquidity-sweep, breakout, and failed-breakout classification.
- Candle-by-candle live analysis without repainting completed history.
- A dark-themed interactive MT4 dashboard.
- A persistent scoreboard with Brier score and calibration analysis.
- Historical replay without look-ahead bias.
- Multi-pair support for the 15 pairs in §11.

Out of scope: trade execution, trade signals as buy/sell advice, account
management, and any prediction presented as a guarantee. A touch probability
is a descriptive historical frequency (see `Probability_Methodology.md` §1–§2),
never a promise that price will touch a level today.

---

## 2. System architecture — the seven engines

All seven engines communicate only through the shared data structures in §3.
No engine reads another engine's private state directly; it reads the
records that engine publishes. This is what makes historical replay possible:
replay re-runs the same engines over the same records in chronological order.

```
Historical bars (MQL4 series: Open/High/Low/Close/Time, Bid basis)
        │
        ▼
┌─────────────────────────────────────────────────────────────┐
│ 1. Key Level Detection Engine (§4)                          │
│    → LevelRecord[]  (one record per level per trading day)  │
├─────────────────────────────────────────────────────────────┤
│ 2. Historical Probability Calculation Engine (§5, and      │
│    Probability_Methodology.md)                              │
│    → ProbabilityRecord[] (one per level × condition)        │
├─────────────────────────────────────────────────────────────┤
│ 3. Forex Session Intelligence Engine (§6)                   │
│    → SessionRecord[] (one per session per trading day)      │
├─────────────────────────────────────────────────────────────┤
│ 4. Liquidity Monitoring Engine (§8)                         │
│    → SweepEventRecord[] (one per classified event)          │
├─────────────────────────────────────────────────────────────┤
│ 5. Candle-by-Candle Analysis Engine (§9)                    │
│    → live LevelState per active level; emits ForecastRecord │
│      at forecast time; finalises it at the evaluation cutoff│
├─────────────────────────────────────────────────────────────┤
│ 6. Historical Performance Scoreboard (§10)                  │
│    → ScoreboardRecord[] (persistent, append-only)           │
├─────────────────────────────────────────────────────────────┤
│ 7. Interactive MT4 Dashboard (§11)                         │
│    → reads LevelRecord / ProbabilityRecord / SessionRecord /│
│      ScoreboardRecord; writes no market data               │
└─────────────────────────────────────────────────────────────┘
        │
        ▼
Chart objects (level lines, labels, session boundaries,
sweep markers) + dashboard + CSV persistence (§12)
```

### 2.1 Engine responsibilities

| # | Engine | Inputs | Outputs | When it runs |
|---|---|---|---|---|
| 1 | Key Level Detection | Bars, trading-day boundary (§6.1), session windows (§6.2), opening-range duration (§4.5) | `LevelRecord[]` | On new trading day / new session; on `OnCalculate` when the current day's or session's levels are still provisional |
| 2 | Historical Probability | `LevelRecord[]` history, lookback (§5.2), minimum sample (§5.3), touch rule (§7), spread/touch method (§5.5) | `ProbabilityRecord[]` | At forecast time (session/day start) and on lookback or input change; never recomputed from future bars |
| 3 | Session Intelligence | Bars, session windows (§6.2), broker offset (§6.3) | `SessionRecord[]` | As each session develops; finalised at session end |
| 4 | Liquidity Monitoring | `LevelRecord[]`, bars, sweep/breakout parameters (§8) | `SweepEventRecord[]` | On each new closed candle |
| 5 | Candle-by-Candle Analysis | Live bars, active `LevelRecord[]`, `ProbabilityRecord[]` | Live level state; `ForecastRecord` at forecast time, finalised at cutoff | On each new closed candle; optional intrabar visual refresh only (§9.3) |
| 6 | Performance Scoreboard | Finalised `ForecastRecord[]` | `ScoreboardRecord[]`, Brier score, calibration bins (§10) | On forecast finalisation; on load (reads CSV) |
| 7 | Dashboard | All published records | Chart objects + dashboard panel | On timer (`InpRefreshSeconds`) and on new-candle events |

### 2.2 MT4 event model

| MQL4 entry point | Responsibility |
|---|---|
| `OnInit()` | Validate inputs (§13.6); resolve broker offset (§6.3); load scoreboard CSV (§12); build the dashboard skeleton; subscribe the timer if `InpRefreshSeconds > 0`. Return `INIT_FAILED` on invalid input — never silently correct an invalid input. |
| `OnCalculate()` | Detect a new bar (`Time[0]` changed). Run Engines 1, 3, 4, 5 in that order. Do **not** recompute the full history on every tick: full recomputation happens only on init, timeframe/symbol change, input change, or when the bar count changes by more than the cached count (e.g. after a history reload). |
| `OnTimer()` | Refresh the dashboard display (clock, time-to-cutoff, distance to level). Never recompute probabilities or finalise forecasts on the timer. |
| `OnDeinit()` | Delete every chart object created by the indicator (prefix `FLR_`); flush pending scoreboard rows to CSV; kill the timer. |
| `OnChartEvent()` | Dashboard interaction only: drag/reposition, minimise/maximise, level-visibility toggles. Must never alter a `LevelRecord`, `ProbabilityRecord`, or `ScoreboardRecord`. |

### 2.3 Recalculation and caching rules

1. **Incremental by default.** Only the current (still-forming) trading day,
   the current session, and the current bar are recomputed on a new bar.
   Completed days/sessions are read from cache and never recomputed.
2. **Full recomputation triggers:** init, symbol change, timeframe change,
   input change, history reload (bar count decreases or jumps), manual
   refresh. A full recomputation replays history chronologically from the
   oldest bar, applying the no-look-ahead rule at every step (§14).
3. **No tick-level probability recomputation.** Probabilities are computed
   from closed bars only. Intrabar ticks may move the live price, the
   distance-to-level display, and the provisional session high/low, but they
   must not change a published probability, a forecast, or a scoreboard row.
4. **CPU budget.** Full history scans are bounded by the lookback
   (`InpLookbackDays`, max 200 by default catalogue, custom values allowed
   up to 500 — see §13.3) plus one extra year of bars for session/day
   aggregation. The indicator must not scan the entire terminal history on
   every bar.

---

## 3. Data structures

All structures are defined here in MQL4-style pseudocode. Field names are
normative: the implementation must use these names (or document a rename in
both documents). Prices are `double` in symbol price units. Times are
`datetime` in **reference time** (UTC by default, §6.3) unless a field name
says otherwise. Pips are counted in points: 1 pip = 10 points on 5/3-digit
symbols, 1 point on 4/2-digit symbols (`_Digits` handling per §3.6).

### 3.1 Enumerations

```mql4
enum FLR_LevelKind
{
   LEVEL_PDH, LEVEL_PDL, LEVEL_PDC, LEVEL_PDO, LEVEL_DO,
   LEVEL_ONH, LEVEL_ONL,
   LEVEL_ASIAN_HIGH, LEVEL_ASIAN_LOW,
   LEVEL_LONDON_HIGH, LEVEL_LONDON_LOW, LEVEL_LONDON_OPEN,
   LEVEL_NY_HIGH, LEVEL_NY_LOW, LEVEL_NY_OPEN,
   LEVEL_ORH, LEVEL_ORL
};

enum FLR_LevelDirection { DIR_UP, DIR_DOWN, DIR_NEUTRAL }; // PDC/PDO/DO/opens: NEUTRAL
enum FLR_LevelStatus
{
   STATUS_WAITING,    // forecast open, level not yet touched
   STATUS_HIT,        // touched at or before the cutoff
   STATUS_MISSED,     // cutoff passed without a touch
   STATUS_EXPIRED,    // session/day ended; replaced by STATUS_HIT/MISSED on finalisation
   STATUS_INSUFFICIENT_DATA
};
enum FLR_SessionId   { SESSION_ASIAN, SESSION_LONDON, SESSION_NEWYORK, SESSION_OVERNIGHT };
enum FLR_EventKind   { EVENT_SWEEP_BUY, EVENT_SWEEP_SELL, EVENT_BREAKOUT_UP,
                       EVENT_BREAKOUT_DOWN, EVENT_FAILED_BREAKOUT_UP,
                       EVENT_FAILED_BREAKOUT_DOWN };
enum FLR_TouchMethod { TOUCH_BID_ONLY, TOUCH_SPREAD_ADJUSTED, TOUCH_ASK_BASED };
enum FLR_PriceBasis  { BASIS_BID, BASIS_ASK, BASIS_MID };
```

### 3.2 Level record — `LevelRecord`

One record per level per trading day. A level that does not exist for a day
(e.g. a session that has not started yet) has no record for that day; a
record is never created with a placeholder price.

```mql4
struct LevelRecord
{
   string           symbol;          // e.g. "EURUSD"
   datetime         tradingDay;      // trading-day start, reference time (§6.1)
   FLR_LevelKind    kind;            // LEVEL_PDH, LEVEL_ORH, ...
   string           abbreviation;    // "PDH", "ORL", ...
   double           price;           // level price; 0.0 only if not yet computable
   bool             isFinal;         // true once its source window has closed
   bool             isProvisional;   // !isFinal; price may still move (session in progress)
   FLR_LevelDirection direction;     // DIR_UP for highs, DIR_DOWN for lows, DIR_NEUTRAL for opens/closes
   datetime         sourceStart;     // start of the window the level was computed from
   datetime         sourceEnd;       // end of that window (exclusive)
   datetime         computedAt;      // when this record was created/finalised (reference time)
   color            lineColor;       // per §13.1
   int              lineStyle;       // STYLE_SOLID / STYLE_DASH / STYLE_DOT
   int              lineWidth;
   bool             visible;         // user visibility toggle for this level kind
   string           objectName;      // chart-object name, unique per §13.2
};
```

Rules:

- **Immutability of completed levels.** Once `isFinal == true`, `price`,
  `sourceStart`, and `sourceEnd` must never change, even if later bars
  arrive. A final level is historical fact (§14, Invariant I-1).
- **Provisional levels.** A session high/low for a session still in progress
  is provisional: its price is the running extreme so far and may move. The
  dashboard must mark provisional levels (e.g. with a `~` prefix or a
  "live" marker) and must never present a provisional price as a final level.
- **Historical levels.** The indicator retains `LevelRecord`s for the full
  lookback plus the scoreboard history. Historical levels remain drawn (if
  `InpShowHistoricalLevels` is true) but are never shifted.

### 3.3 Probability record — `ProbabilityRecord`

One record per level × conditioning set, computed at forecast time.

```mql4
struct ProbabilityRecord
{
   string           symbol;
   datetime         tradingDay;      // day the forecast applies to
   FLR_LevelKind    kind;
   string           abbreviation;
   FLR_SessionId    session;         // session the probability is conditioned on
   int              dayOfWeek;       // 0=Sunday .. 6=Saturday; -1 = all days
   int              lookbackDays;    // 20 / 50 / 100 / 200 / custom (§5.2)
   int              touches;         // eligible observations where the level was touched
   int              misses;          // eligible observations where it was not touched
   int              observations;    // touches + misses; == N
   double           probabilityPct;  // 0–100; undefined when observations < minimum sample
   double           wilsonLowerPct;  // Wilson 95% lower bound (§5.6)
   double           wilsonUpperPct;  // Wilson 95% upper bound (§5.6)
   string           category;        // "Very High" | "High" | "Moderate" | "Low" | "Very Low" | "INSUFFICIENT DATA"
   bool             sufficientData;  // observations >= InpMinSampleSize
   datetime         forecastTime;    // when this probability was computed/shown
   datetime         cutoffTime;      // evaluation cutoff (§5.4)
   FLR_TouchMethod  touchMethod;
   FLR_PriceBasis   priceBasis;
};
```

Display rule (§4 of the companion methodology): **never display a
probability without its sample size.** The dashboard always shows `N`
alongside the percentage, and shows `INSUFFICIENT DATA` (not a number) when
`sufficientData == false`.

### 3.4 Sweep event record — `SweepEventRecord`

One record per classified liquidity event. Created only on a closed candle.

```mql4
struct SweepEventRecord
{
   string           symbol;
   datetime         eventTime;       // open time of the confirmation candle (reference time)
   datetime         excursionTime;   // open time of the candle that first crossed the level
   FLR_LevelKind    levelKind;
   string           abbreviation;
   double           levelPrice;
   FLR_EventKind    kind;            // EVENT_SWEEP_BUY, EVENT_BREAKOUT_UP, ...
   double           excursionPrice;  // most extreme price reached beyond the level
   double           excursionPips;   // |excursionPrice - levelPrice| in pips
   datetime         confirmationTime;// open time of the candle confirming the classification
   int              confirmationBars;// candles from excursion to confirmation
   double           followThroughPips; // price movement in the N bars after confirmation
                                       // (N = InpFollowThroughBars, default 3); signed:
                                       // positive = continuation in the breakout direction
   bool             isFinal;         // true once confirmed; never revised afterwards
};
```

### 3.5 Scoreboard record — `ScoreboardRecord`

One record per finalised forecast (one level × one trading day). This is the
unit of the scoreboard: **one forecast per level per trading day, never
duplicates** (§10.2).

```mql4
struct ScoreboardRecord
{
   string           symbol;
   datetime         tradingDay;
   FLR_LevelKind    kind;
   string           abbreviation;
   FLR_SessionId    session;
   int              dayOfWeek;       // day of week of tradingDay
   datetime         forecastTime;
   datetime         cutoffTime;
   double           forecastPct;     // probability shown at forecast time (0–100)
   double           forecastProb;    // forecastPct / 100.0 (0–1), for Brier score
   int              outcome;         // 1 = touched at or before cutoff; 0 = not touched
   int              observations;    // N behind the forecast
   double           brierContribution; // (forecastProb - outcome)^2
   datetime         touchTime;       // first touch time, or 0 if outcome == 0
   datetime         finalisedAt;     // when the outcome was recorded
};
```

Aggregations (computed on demand from `ScoreboardRecord[]`, never stored as
the only copy) are defined in §10.

### 3.6 Numeric conventions

- **Digits / point.** All price formatting uses the symbol's `_Digits`.
  Pip size: `_Point * 10` when `_Digits` is 3 or 5, otherwise `_Point`.
- **Rounding.** Probabilities are displayed rounded to the nearest whole
  percent; the stored `probabilityPct` keeps one decimal place
  (e.g. 72.0). Brier scores are stored to 4 decimal places.
- **Missing bars.** A bar that does not exist (weekend gap, holiday,
  history hole) is not an observation and is not synthesised. A trading day
  with missing bars in its source window is flagged incomplete (§5.1) and
  excluded from probability eligibility.
- **Division by zero.** Any ratio with a zero denominator yields
  `INSUFFICIENT DATA`, never 0% and never a manufactured value.

---

## 4. Key level definitions and calculation rules

All levels are computed from **closed bars** on the chart timeframe, in
reference time (§6). A level's source window is a half-open interval
`[sourceStart, sourceEnd)`: a bar belongs to the window when its **open
time** falls inside it. This single rule prevents double-counting a bar in
two adjacent windows.

### 4.1 Daily levels

The trading day is defined in §6.1. Let `D` be the current trading day and
`D-1` the previous trading day.

| Level | Abbrev. | Direction | Definition |
|---|---|---|---|
| Previous Day High | PDH | Up | `max(High)` over all bars with open time in `D-1` |
| Previous Day Low | PDL | Down | `min(Low)` over all bars with open time in `D-1` |
| Previous Day Close | PDC | Neutral | `Close` of the last bar with open time in `D-1` |
| Previous Day Open | PDO | Neutral | `Open` of the first bar with open time in `D-1` |
| Current Day Open | DO | Neutral | `Open` of the first bar with open time in `D` |

Notes:

- If `D-1` has no bars (e.g. after a long holiday, or at the start of
  available history), PDH/PDL/PDC/PDO have **no record** for day `D` — they
  are absent, not zero. The dashboard shows `—` for that level.
- DO becomes final at the open of the first bar of `D` and never changes
  thereafter.
- PDH/PDL/PDC/PDO become final at the start of `D` (when `D-1` is complete)
  and are immutable for the whole of `D` (§3.2).

### 4.2 Overnight / Asian session levels

| Level | Abbrev. | Direction | Source window (reference time) |
|---|---|---|---|
| Overnight High | ONH | Up | `[21:00 UTC previous calendar day, 07:00 UTC current day)` — New York close to London open |
| Overnight Low | ONL | Down | Same window as ONH |
| Asian Session High | ASH | Up | Asian session window (§6.2): `[00:00, 09:00)` UTC by default |
| Asian Session Low | ASL | Down | Same window as ASH |

Notes:

- ONH/ONL and ASH/ASL intentionally overlap over `[00:00, 07:00)`. They
  are different windows answering different questions (overnight liquidity
  vs. the Asian session proper) and must be computed independently. The
  overlap is not a bug and must not be "deduplicated".
- ONH/ONL are final at 07:00 UTC (London open). Before that they are
  provisional. ASH/ASL are final at 09:00 UTC.
- On Mondays, the overnight window starts at 21:00 UTC on Friday; bars
  between Friday 21:00 UTC and Monday 00:00 UTC do not exist (weekend),
  so the effective window is the bars that exist in that interval.
- If a window contains no bars, the level has no record for that day.

### 4.3 London session levels

| Level | Abbrev. | Direction | Definition |
|---|---|---|---|
| London Session High | LSH | Up | `max(High)` over bars in the London window `[07:00, 16:00)` UTC by default |
| London Session Low | LSL | Down | `min(Low)` over the same window |
| London Session Open | LSO | Neutral | `Open` of the first bar in the London window |

LSH/LSL are provisional until 16:00 UTC, then final. LSO is final at the
first bar of the window.

### 4.4 New York session levels

| Level | Abbrev. | Direction | Definition |
|---|---|---|---|
| New York Session High | NYH | Up | `max(High)` over bars in the New York window `[12:00, 21:00)` UTC by default |
| New York Session Low | NYL | Down | `min(Low)` over the same window |
| New York Session Open | NYO | Neutral | `Open` of the first bar in the New York window |

NYH/NYL are provisional until 21:00 UTC, then final. NYO is final at the
first bar of the window. The New York window is also the default
**evaluation window** for daily levels: see §5.4.

### 4.5 Opening range levels

| Level | Abbrev. | Direction | Definition |
|---|---|---|---|
| Opening Range High | ORH | Up | `max(High)` over the opening-range window |
| Opening Range Low | ORL | Down | `min(Low)` over the opening-range window |

- **Opening-range window (normative):** the first `InpOpeningRangeMinutes`
  minutes after the start of the **New York session** (12:00 UTC by default).
  The source session is configurable via `InpOpeningRangeSession`
  (`London` / `New York` / `Asian` / `DayStart`); the default is
  `New York`, because §5 of the source spec assigns the opening range to
  New York session intelligence.
- **Duration:** `InpOpeningRangeMinutes` ∈ {15, 30, 60}; default **30**.
  Any other value is rejected at `OnInit()` (§13.6). The window is
  `[sessionStart, sessionStart + duration)`.
- ORH/ORL become final at the end of the opening-range window and are
  immutable thereafter for that trading day.
- If the opening-range window contains no bars (e.g. the chart timeframe
  is longer than the window — a 1-hour chart cannot resolve a 15-minute
  opening range), ORH/ORL have no record and the dashboard shows
  `— (TF too coarse)`. The indicator must not fabricate an opening range
  from a single bar that merely overlaps the window: a bar counts only if
  its open time is inside the window (§4 preamble).

### 4.6 Level display and identity

- Every level kind has a unique colour and line style (§13.1) and a unique
  chart-object name (§13.2).
- Daily levels (PDH/PDL/PDC/PDO/DO) extend horizontally across the whole
  visible chart and into the next trading day until replaced.
- Session levels extend across their own session window and, for the current
  day, to the right edge of the chart until the session ends.
- Each level line carries a label showing abbreviation and price
  (e.g. `PDH 1.08750`). Provisional levels carry a `~` prefix on the price
  (e.g. `LSH ~1.08750`).
- Visibility is controlled per level kind (§13.3, `InpShow*` inputs). Hiding
  a level removes its line and label but does **not** stop its probability
  or scoreboard computation.

---

## 5. Historical probability engine

This section states the engine's contract. The mathematics — formula,
eligibility, conditioning, Wilson interval, Brier score, calibration — are
specified in full in `Probability_Methodology.md`; this section states how
the engine implements them and where each value comes from. The two
documents must agree on every number.

### 5.1 Core formula

For a level `L`, a conditioning set `C` (pair, session, day of week), and a
lookback of `N` eligible observations:

```
P_touch(L, C) = (touches / eligible observations) × 100
```

where a touch is defined by §7. The formula is applied per level, never
pooled across levels: PDH's 72% says nothing about PDL.

### 5.2 Lookbacks

| Input value | Meaning |
|---|---|
| 20 / 50 / 100 / 200 | The most recent 20 / 50 / 100 / 200 **eligible** trading days |
| Custom | `InpLookbackDays` set to any integer in [5, 500] |

- **Default lookback: 100 trading days.**
- "Most recent N eligible days" means: walk backwards from the forecast
  time, count only days that pass the eligibility rules
  (`Probability_Methodology.md` §3), and stop at N. Ineligible days do not
  consume a lookback slot.
- The dashboard shows the probability for the selected lookback
  (`InpLookbackDays`). The scoreboard records which lookback produced each
  forecast (`ProbabilityRecord.lookbackDays`).
- Changing the lookback recomputes all probabilities from the same bar
  history; it never changes a finalised `ScoreboardRecord`.

### 5.3 Minimum sample size and INSUFFICIENT DATA

- `InpMinSampleSize`, default **20**, range [5, 100].
- If `observations < InpMinSampleSize`, the probability is **not displayed
  as a number**. The dashboard and chart label show `INSUFFICIENT DATA`
  and the record's `category` is `INSUFFICIENT DATA`, `sufficientData`
  is `false`, and `probabilityPct` is left undefined (stored as `-1.0` as a
  sentinel, never displayed).
- No forecast is written to the scoreboard for a level with insufficient
  data on that day: an unmeasured forecast cannot be scored. The day is
  skipped for that level, not scored as a miss.
- Insufficient data is not an error and not a zero. It is a normal state
  at the start of available history and on thinly traded symbols.

### 5.4 Forecast time and evaluation cutoff

A **forecast** is the probability shown at a defined moment, scored against
what happens before a defined cutoff. Both moments are normative:

| Forecast type | Forecast time | Evaluation cutoff (default) |
|---|---|---|
| Daily levels (PDH/PDL/PDC/PDO/DO/ONH/ONL) | Trading-day start (`InpDayStartHourUTC`, default 00:00 UTC) | **21:00 UTC** same trading day (New York close) |
| Asian session levels (ASH/ASL) | Asian session start (00:00 UTC) | Asian session end (09:00 UTC) |
| London session levels (LSH/LSL/LSO) | London session start (07:00 UTC) | London session end (16:00 UTC) |
| New York session levels (NYH/NYL/NYO) | New York session start (12:00 UTC) | New York session end (21:00 UTC) |
| Opening range (ORH/ORL) | End of the opening-range window | New York session end (21:00 UTC) |

- `InpEvaluationCutoffUTC` (default `21:00`) overrides the daily-level
  cutoff only; session-level cutoffs always equal their session end.
- **Outcome:** `outcome = 1` if the level is touched at any time in
  `[forecastTime, cutoffTime]` on a closed bar (§7); otherwise `0`. A touch
  after the cutoff does not change the outcome. A touch before the forecast
  time does not count (the level was not yet forecast).
- **One forecast per level per trading day.** The engine must not emit a
  second forecast for the same level and day if the dashboard is refreshed,
  the terminal restarts, or the timeframe changes. Deduplication key:
  `(symbol, tradingDay, kind, session)`.
- The forecast probability is **frozen** at forecast time. Later bars may
  change the live status (Waiting → Hit) but never the frozen probability.

### 5.5 Touch calculation method and spread adjustment

`InpTouchMethod` (default `TOUCH_BID_ONLY`):

| Method | Upward level touch condition | Downward level touch condition |
|---|---|---|
| `TOUCH_BID_ONLY` (default) | Bid `High >= level` | Bid `Low <= level` |
| `TOUCH_SPREAD_ADJUSTED` | Bid `High >= level + spread` | Bid `Low <= level - spread` |
| `TOUCH_ASK_BASED` | Ask `High >= level` (Ask High = Bid High + spread) | Ask `Low <= level` (Ask Low = Bid Low + spread) |

- `spread` is the symbol's current spread in price units at the time of
  evaluation, obtained from `MarketInfo(symbol, MODE_SPREAD) * _Point`.
  For historical bars the spread at the bar's close is not recoverable in
  MT4, so `TOUCH_SPREAD_ADJUSTED` uses the **current** spread as a constant
  for the whole lookback and records that fact in the probability record.
  This approximation must be disclosed on the dashboard footnote when the
  method is active ("spread-adjusted using current spread").
- `InpPriceBasis` (default `BASIS_BID`) selects which series the level
  itself is computed from. Levels are computed from Bid bars by default;
  `BASIS_ASK` shifts every level price up by the current spread, `BASIS_MID`
  by half the spread. The chosen basis is recorded in every
  `ProbabilityRecord` and `ScoreboardRecord` it affects, so a scoreboard is
  never mixed across bases without that being visible.
- The **default configuration is pure Bid, no spread adjustment**, so that
  historical probabilities are exactly reproducible from the bar history
  alone. Spread adjustment is an option, not the default.

### 5.6 Confidence intervals

Every displayed probability carries a Wilson score interval (95%,
z = 1.96) — see `Probability_Methodology.md` §8 for the formula and a
worked example. The dashboard shows the interval on hover/detail view (or
in the probability table's detail row where space allows); the scoreboard
CSV stores `wilsonLowerPct` and `wilsonUpperPct` for every forecast. The
interval is a property of the sample size, not of the market: a 72% estimate
from N=20 is far less certain than 72% from N=200, and the display must
make that visible.

### 5.7 Probability categories

| Probability | Category | Dashboard colour |
|---|---|---|
| 80–100% | Very High | Green (dark green fill) |
| 65–79% | High | Green (light green fill) |
| 50–64% | Moderate | Yellow |
| 30–49% | Low | Red (light red / amber-red fill) |
| 0–29% | Very Low | Red (dark red fill) |
| Insufficient data | INSUFFICIENT DATA | Grey |

Category boundaries are configurable via `InpCatVeryHigh`, `InpCatHigh`,
`InpCatModerate`, `InpCatLow` (§13.3), but the defaults above are the
shipped values and the category names must not be renamed.

---

## 6. Sessions, trading days, and time handling

This is the section most likely to produce silent errors. Every rule here
is normative.

### 6.1 Trading-day boundary

- The trading day is **not** assumed to be broker midnight. It is defined
  by `InpDayStartHourUTC` (default **0**, i.e. 00:00 UTC; range 0–23) plus
  `InpDayStartMinuteUTC` (default 0, range 0–59).
- Trading day `D` is the interval
  `[D_start, D_start + 24h)` in **reference time**, where `D_start` is the
  most recent occurrence of the configured day-start time at or before the
  current reference time.
- Example with the default: a bar at 2026-11-27 00:00 UTC belongs to trading
  day 2026-11-27; a bar at 2026-11-26 23:59 UTC belongs to trading day
  2026-11-26.
- Example with `InpDayStartHourUTC = 17` (17:00 UTC, the common Forex
  "5 pm EST" rollover expressed in UTC): a bar at 2026-11-27 16:59 UTC
  belongs to trading day 2026-11-26; a bar at 17:00 UTC belongs to
  2026-11-27.
- **All** daily levels (§4.1), all probability lookbacks (§5.2), and all
  scoreboard days (§10) use this boundary. There is exactly one trading-day
  definition in the system.
- Changing the day-start hour changes every daily level and every historical
  probability. The indicator must recompute from scratch on such a change
  and must not mix records computed under different day-start settings in
  one scoreboard file: the scoreboard CSV header records the day-start
  setting (§12.2), and a mismatch on load produces a warning and starts a
  new scoreboard file (suffixed with the setting), never a silent merge.

### 6.2 Session windows (UTC reference)

| Session | Default window (UTC) | Configurable inputs |
|---|---|---|
| Asian | **00:00–09:00** | `InpAsianStartUTC`, `InpAsianEndUTC` |
| London | **07:00–16:00** | `InpLondonStartUTC`, `InpLondonEndUTC` |
| New York | **12:00–21:00** | `InpNYStartUTC`, `InpNYEndUTC` |

- Windows are half-open `[start, end)`. A bar belongs to a session when its
  open time is inside the window.
- **Overlaps are intentional and must be preserved.** London overlaps Asian
  07:00–09:00; New York overlaps London 12:00–16:00. Each session is
  computed independently from its own window. The engine must not
  "deduplicate" overlapping bars, must not assign a bar to a single session,
  and must not double-count a bar *within* one session.
- A session window may cross the trading-day boundary (e.g. if the user
  sets Asian to 22:00–07:00). In that case the session is attributed to the
  trading day in which it **starts** (reference time), and its bars are
  taken from both calendar days as needed. The overnight window (§4.2)
  always crosses midnight by definition.
- `InpUseCustomSessions` (default `false`): when `true`, the three windows
  above are replaced by user-supplied start/end pairs
  (`InpCustomSession1Start/End`, etc.). Custom sessions are still computed
  in reference time and still follow the half-open rule. At most three
  custom sessions are supported; fewer is allowed (an empty window disables
  that session).
- Session start/end times are validated at `OnInit()`: start ≠ end, and
  each must be a valid time of day. A zero-length window is rejected.

### 6.3 Broker-server offset and DST handling

- **Reference time is UTC.** All session windows, the trading-day boundary,
  the evaluation cutoff, and all stored datetimes are expressed in
  reference time. UTC itself has no daylight saving.
- **Broker time is never assumed to be UTC.** The broker server's offset
  from UTC is `InpBrokerOffsetHours` (default `0`, range −12…+14, step 0.5)
  plus, when `InpBrokerUsesDST` is `true` (default `false`), a DST shift of
  `InpBrokerDSTShiftHours` (default `1`) applied during the broker's DST
  period.
- Conversion rule (the only conversion in the system):
  `referenceTime = brokerTime − brokerOffset`, where
  `brokerOffset = InpBrokerOffsetHours + (InpBrokerUsesDST && IsBrokerDST(brokerTime) ? InpBrokerDSTShiftHours : 0)`.
- `IsBrokerDST()` is determined from `InpBrokerDSTStartRule` /
  `InpBrokerDSTEndRule` (default: US rules — second Sunday in March to
  first Sunday in November — because most retail Forex brokers follow US
  DST; EU rules are selectable via `InpBrokerDSTRegion` = `US` / `EU` /
  `None`). The rule, not a hardcoded date list, is stored, so the
  calculation stays correct in future years.
- **Auto-detection (optional, default off):** when
  `InpAutoDetectBrokerOffset` is `true`, the indicator estimates the offset
  once at init by comparing `TimeCurrent()` (broker server time) with the
  terminal's UTC clock, rounds to the nearest 0.5 h, and logs the result.
  Auto-detection never overrides an explicit `InpBrokerOffsetHours ≠ 0`
  set by the user, and its result is displayed on the dashboard so a wrong
  detection is visible.
- **Failure mode:** if the offset is wrong, session windows shift by the
  error and every session level is wrong. The dashboard therefore always
  shows the active reference time, the broker time, and the applied offset
  (e.g. `UTC 14:32 | Broker 16:32 | Offset +2`). A user who sees the wrong
  broker time can correct the offset without guessing.
- Session windows are defined in reference time and converted **to** broker
  time only for bar selection (bars are timestamped in broker time by MT4).
  The conversion is applied once, at bar selection, never per level.

### 6.4 Market status

`MARKET STATUS` on the dashboard is derived from reference time:

- **Active** when the current reference time falls inside at least one
  configured session window on a trading day that has bars.
- **Closed** otherwise (including weekends: Saturday 00:00 UTC to Monday
  00:00 UTC by default, and any day with no bars).
- The current session shown is the session whose window contains the
  current reference time; when two overlap (e.g. 13:00 UTC is both London
  and New York), the **later-starting** session is shown as current
  (New York at 13:00 UTC), and the other is listed as overlapping.
  When no session is active, the dashboard shows the next session and the
  time until it starts.

---

## 7. Level touch definitions

A touch is evaluated on **closed bars only**, in the evaluation window
`[forecastTime, cutoffTime]`.

| Level direction | Touch condition (Bid basis, §5.5) |
|---|---|
| Upward (highs: PDH, ONH, ASH, LSH, NYH, ORH) | `High >= level` |
| Downward (lows: PDL, ONL, ASL, LSL, NYL, ORL) | `Low <= level` |
| Neutral (opens/closes: PDC, PDO, DO, LSO, NYO) | `High >= level` **and** `Low <= level` (the bar's range must contain the level; a neutral level is a price, not a direction) |

> **Errata (2026-11-27).** This row originally read "`High >= level`
> **or** `Low <= level`". That was wrong: for any bar, one of those two
> is always true, so the rule as written would count every bar as a
> touch and every neutral-level probability would be 100%. The correct
> rule — and the one the code implements (`TouchInWindow()`,
> `BarTouchesLevel()`, and the live-status check in
> `CalcProbabilities()`) — is **AND**: the bar's range must contain the
> level (under the Close method, `|Close − level| <=` the spread
> adjustment). A neutral level can be touched from either side, but one
> side alone is not a touch. See Test Report F2 and the matching errata
> in `Probability_Methodology.md` §2.

Rules:

1. **Equality counts.** `High == level` is a touch. Floating-point
   comparison uses an epsilon of half a point (`_Point / 2`): a high within
   half a point below the level is treated as equal, to avoid missing
   touches on rounding.
2. **Wick touches count.** A touch needs only the high/low to reach the
   level; the close does not need to cross it. This is what distinguishes
   a touch from a breakout (§8).
3. **First touch time** is the open time of the first bar satisfying the
   condition. It is recorded in `ScoreboardRecord.touchTime`.
4. **Live status.** Before the cutoff, a level is `Waiting` until its first
   touch, then `Hit`. After the cutoff it is finalised as `Hit` or
   `Missed` in the scoreboard. A level touched and then never again is
   still `Hit` — the outcome is "touched at least once", not "closed
   beyond".
5. **Spread-adjusted touches** follow §5.5. The touch method in force is
   recorded per forecast, so a probability computed with one method is
   never silently compared with an outcome computed with another.

---

## 8. Liquidity monitoring engine — sweep vs breakout vs failed breakout

Classification happens on **closed candles only**, in this order, and a
single excursion is classified exactly once. The classification is final
once recorded (§3.4, `isFinal`).

### 8.1 Inputs

| Input | Default | Meaning |
|---|---|---|
| `InpSweepMinExcursionPips` | 0.0 | Minimum excursion beyond the level for a sweep to be recorded. 0.0 = any excursion counts. |
| `InpSweepReturnBars` | 3 | Max candles after the excursion candle within which price must close back inside the level for a sweep. |
| `InpBreakoutConfirmBars` | 1 | Candles after the breakout close that must also close beyond the level to confirm a breakout. |
| `InpFailedBreakoutBars` | 3 | Max candles after a breakout close within which a close back inside the level makes it a failed breakout. |
| `InpFollowThroughBars` | 3 | Bars after confirmation over which follow-through is measured. |

### 8.2 Decision procedure (per level, per excursion)

Let `L` be the level, `UP` the upward case (`High > L` excursion,
`Close > L` beyond). The downward case is the mirror image.

1. **Excursion detected** on closed candle `i`: `High[i] > L` (strictly
   beyond; equality is a touch, §7, not an excursion).
2. **Sweep test (wick only).** If `Close[i] < L` (the excursion candle
   itself closed back inside) **or** any of the next
   `InpSweepReturnBars` candles closes back inside (`Close < L`) without
   any intervening close beyond `L`, classify **`EVENT_SWEEP_BUY`**
   (buy-side liquidity sweep above a high). Confirmation candle = the
   first candle closing back inside. Record and stop.
   - Downward mirror: `Low[i] < L`, close back above `L` →
     `EVENT_SWEEP_SELL`.
3. **Breakout test (close beyond).** Else if `Close[i] > L`:
   a. Wait `InpBreakoutConfirmBars` further closed candles. If all of them
      also close beyond `L`, classify **`EVENT_BREAKOUT_UP`**. Confirmation
      candle = the last confirming candle. Record and stop.
   b. If instead, within `InpFailedBreakoutBars` candles after the
      breakout close, a candle closes back inside (`Close <= L`),
      classify **`EVENT_FAILED_BREAKOUT_UP`**. Confirmation candle = the
      candle closing back inside. Record and stop.
   c. If neither (a) nor (b) resolves within the windows (e.g. price hovers
      exactly at the level), no event is recorded. Unresolved excursions
      are not events.
4. **No classification** is recorded for an excursion that is still within
   its confirmation window at the current bar. Pending excursions are
   tracked in memory only and never shown as final events.

### 8.3 Decision table

| What happened | Classification | Why it is not the other thing |
|---|---|---|
| Wick beyond `L`, close back inside, no close beyond | **Sweep** | No close beyond `L`, so it was never a breakout |
| Close beyond `L`, stays beyond for `InpBreakoutConfirmBars` | **Breakout** | Confirmed by subsequent closes, not a wick |
| Close beyond `L`, then closes back inside within `InpFailedBreakoutBars` | **Failed breakout** | It *was* a breakout (close beyond) that failed — different from a sweep, where the close never went beyond |
| Wick beyond `L`, later close beyond, stays beyond | **Breakout** (not a sweep) | The sweep test in §8.2 step 2 requires no intervening close beyond; once a close goes beyond, the sweep path is closed |
| Price touches `L` exactly (`High == L`), never beyond | **No event** | A touch (§7), not an excursion |

### 8.4 What is recorded and what is not

- Every classified event records the fields in §3.4, including
  `excursionPips` and `followThroughPips` (measured over
  `InpFollowThroughBars` after confirmation; positive = continuation in
  the breakout direction for breakouts, positive = reversal back inside
  for sweeps — the sign convention is documented on the event, not left
  implicit).
- **Do not classify every breakout as manipulation or a liquidity sweep.**
  The dashboard and any export use the neutral terms "sweep", "breakout",
  "failed breakout". No event is labelled "manipulation", "stop hunt", or
  "smart money" anywhere in the indicator, its dashboard, or its exports.
- Events are drawn as markers on the chart (arrow + label, §13.1) and
  listed in the dashboard's event feed (most recent first, max
  `InpMaxEventsShown`, default 10).
- A sweep/breakout is evaluated against the **level as known at the time
  of the excursion** (the final level for completed days, the provisional
  level for the current session). If a provisional session level later
  moves beyond the excursion price, the event is **not** retroactively
  reclassified — the classification used the information available at the
  time (§14, Invariant I-3).

---

## 9. Candle-by-candle analysis engine

### 9.1 Live level state

For each active level (levels of the current trading day whose cutoff has
not passed), the engine tracks on every new closed candle:

| Field | Definition |
|---|---|
| Distance to level | `\|Bid − level\|` in pips, signed: positive when price is below an upward level or above a downward level (distance still to travel) |
| Direction to target | `Above` / `Below` (current Bid relative to the level) |
| Historical probability | Frozen forecast probability from `ProbabilityRecord` |
| Touched? | Whether §7 has been satisfied in `[forecastTime, now]` |
| Crossed? | Whether a close has gone beyond the level (distinct from touched) |
| Time elapsed | `now − forecastTime` |
| Time remaining | `cutoffTime − now` (0 once the cutoff passes; never negative on display — shows `00:00` and status `Expired`) |
| Current session | Per §6.4 |
| Market status | `Active` / `Closed` per §6.4 |

### 9.2 Update rules

- On a new **closed** candle: update all live fields, run the Liquidity
  Monitoring Engine (§8), check for touches (§7), and finalise any forecast
  whose cutoff has passed (§5.4).
- On a new **tick** (intrabar): only the live price, distance, and the
  provisional session high/low may move. No probability, forecast,
  scoreboard row, or historical level may change on a tick.
- Forecasts are emitted exactly once, at forecast time (§5.4). If the
  terminal was off at forecast time (e.g. started at 10:00 UTC when the
  forecast time was 00:00 UTC), the forecast is emitted **late** on the
  first bar after startup, computed **only from bars available at the
  original forecast time** (replay, §14.2), and marked `lateIssued = true`
  in the log. It is never computed from bars after the forecast time.

### 9.3 Intrabar updates

`InpIntrabarUpdates` (default `false`): when `true`, the dashboard price,
distance, and provisional session extremes refresh on ticks for visual
monitoring. When `false` (default), the dashboard refreshes on the timer
and on new candles only. Either way, §9.2's prohibition on changing
finalised data on a tick is absolute.

---

## 10. Historical performance scoreboard

### 10.1 What the scoreboard measures

The scoreboard evaluates **forecasts against outcomes**. A forecast is the
probability shown at forecast time (§5.4); the outcome is 1 if the level
was touched before the cutoff, else 0. Nothing else is scored.

The scoreboard does **not** measure trading profitability. A forecast can
be perfectly calibrated and a trade based on it can still lose money
(spread, entry, position sizing, and exit are not part of the forecast).
The dashboard carries the footnote: *"Forecast accuracy ≠ trading
profitability."*

### 10.2 Scoreboard rules

1. **One row per forecast.** Key `(symbol, tradingDay, kind, session)`.
   Duplicates are rejected on insert and on CSV load.
2. **Append-only.** Finalised rows are never edited or deleted by the
   indicator. A wrong row can only be removed by the user deleting the CSV
   file (or the row) manually, outside the indicator.
3. **No future data.** A row's `forecastPct` is the probability computed
   from data available at `forecastTime` only. The scoreboard never
   recomputes a past forecast from later data.
4. **Completeness.** A row is written only when its outcome is known
   (cutoff passed). Open forecasts are held in memory, not in the CSV.
5. **Restart persistence.** On `OnInit()`, the CSV is loaded into memory.
   On forecast finalisation, the row is appended and the file flushed.
   A terminal restart loses no finalised row (§12).

### 10.3 Aggregate metrics

Computed from `ScoreboardRecord[]` on demand (overall, and grouped by
level, session, pair, and day of week — each group computed independently
from the same rows):

| Metric | Definition |
|---|---|
| Total forecasts (`N`) | Count of finalised rows in the group |
| Total touches | `sum(outcome)` |
| Total misses | `N − sum(outcome)` |
| Average forecast | `mean(forecastProb)` × 100 (%) |
| Actual touch rate | `mean(outcome)` × 100 (%) |
| Forecast − Actual difference | Average forecast − actual touch rate (percentage points; positive = over-forecasting) |
| Brier score | `mean((forecastProb − outcome)²)` — 0 is perfect, 1 is worst; 0.25 is the score of a constant 50% forecast. See `Probability_Methodology.md` §7 |
| Brier skill vs. climatology | `1 − Brier / Brier_climatology`, where `Brier_climatology` is the Brier score of forecasting the group's base rate on every row. Positive = better than the base rate |
| Calibration (per bin) | Rows binned by forecast probability (bins: 0–29, 30–49, 50–64, 65–79, 80–100 — the §5.7 categories); per bin: mean forecast vs. actual touch rate and row count. See `Probability_Methodology.md` §9 |

- A group with `N < InpMinSampleSize` shows its metrics with an
  `INSUFFICIENT DATA` flag rather than suppressing them: scoreboard metrics
  are descriptive of what happened, but the flag warns the reader not to
  over-interpret a small group.
- The example in the source spec (§9) — 1,015 observations, average
  forecast 54%, actual 49%, PDH 145 observations / forecast 47% / actual
  40% — is an **illustrative example from the source video's scoreboard**,
  not a target. The implementation must display its own computed numbers.

### 10.4 Scoreboard display

```
FOREX LEVEL RADAR SCOREBOARD
Total Forecasts: <N>   Touches: <n>   Misses: <n>
Average Forecast: <%>   Actual Touch Rate: <%>   Difference: <±pp>
Brier Score: <0.0000>   (vs. climatology: <±0.0000>)
Per level / session / pair / day-of-week breakdown (same columns)
Calibration: per-bin forecast vs. actual (see §10.3)
```

The dashboard shows the overall block plus the per-level breakdown; the
full breakdown (session, pair, day-of-week) is available in the exported
CSV and in the dashboard's detail view.

---

## 11. Dashboard — layout and fields

### 11.1 General

- Title: `FOREX LEVEL RADAR PRO` (exact text, top of the panel).
- Theme: dark by default (`InpTheme = Dark`): deep navy/charcoal
  background (`#0F1420`-family), white primary text, muted grey secondary
  text, gold accents for headers. Light theme inverts background/text but
  keeps the same probability colours (§5.7).
- Position: configurable corner + X/Y offset (§13.3). Draggable by its
  title bar. Minimisable to the title bar only; the minimise state
  persists across `OnCalculate` calls but not across restarts (it resets
  to expanded on init, unless `InpDashboardMinimised` is `true`).
- Resizing: the panel sizes to its content; the probability table scrolls
  internally if more than `InpMaxTableRows` (default 7) levels are shown.
  MT4 chart objects cannot be truly resized by the user, so "resizing" is
  implemented as the panel growing/shrinking with its content and with the
  font-size input (`InpDashboardFontSize`).
- Refresh: on the timer (`InpRefreshSeconds`, default 5) and on new candles.
  The clock field updates every second when the timer allows it.

### 11.2 Header block

| Field | Source |
|---|---|
| Title | `FOREX LEVEL RADAR PRO` |
| PAIR | Chart symbol |
| TIMEFRAME | Chart timeframe (e.g. `H1`, `M15`) |
| SESSION | Current session per §6.4, plus overlapping session if any |
| MARKET STATUS | `Active` / `Closed` per §6.4 |
| CURRENT PRICE | Live Bid, formatted to `_Digits` |
| REFERENCE TIME | Current reference (UTC) time `HH:MM:SS` |
| BROKER TIME / OFFSET | Broker time and applied offset (§6.3) |
| DAILY OPEN | DO (§4.1) |
| PREVIOUS DAY HIGH / LOW / CLOSE | PDH / PDL / PDC (§4.1) |
| ASIAN HIGH / LOW | ASH / ASL (§4.2) |
| LONDON HIGH / LOW | LSH / LSL (§4.3) |
| NEW YORK HIGH / LOW | NYH / NYL (§4.4) |
| OPENING RANGE HIGH / LOW | ORH / ORL (§4.5) |

Values that do not exist yet (e.g. NYH before 12:00 UTC) show `—`.
Provisional values show a `~` prefix (§4.6).

### 11.3 Probability table

Columns (exact order): `LEVEL | PRICE | ODDS | SAMPLE | STATUS`.

| Column | Content |
|---|---|
| LEVEL | Abbreviation (`PDH`, `PDL`, `PDC`, `ONH`, `ONL`, `ORH`, `ORL`, …) |
| PRICE | Level price to `_Digits`; `—` if no record; `~` prefix if provisional |
| ODDS | Probability % + category colour (§5.7); `INSUFFICIENT DATA` when §5.3 applies |
| SAMPLE | `N=<observations>` (touches shown as `T=<touches>` in the detail view) |
| STATUS | `Waiting` / `Hit` / `Missed` / `Expired` (§7 rule 4); `—` before forecast time |

Rows shown by default (the seven from the source spec, in this order):
PDH, PDL, PDC, ONH, ONL, ORH, ORL. Additional rows (PDO, DO, ASH, ASL,
LSH, LSL, NYH, NYL, LSO, NYO) are shown when `InpShowAllLevelsInTable`
is `true` (default `false`) or when the user expands the table.

Each row also carries, in its detail/hover view: touches/misses, Wilson
interval (§5.6), time remaining until cutoff (§9.1), distance in pips,
and the lookback (`N days`) behind the probability.

### 11.4 Scoreboard block and event feed

- Scoreboard block: the overall metrics from §10.4 (compact form).
- Event feed: the most recent sweep/breakout/failed-breakout events
  (§8), newest first, format `HH:MM <ABBREV> <KIND> <excursion>pips`.
- Footnotes (always visible, small text):
  1. `Probabilities are historical frequencies, not guarantees.`
  2. `Forecast accuracy ≠ trading profitability.`
  3. Spread-adjustment note when `InpTouchMethod = TOUCH_SPREAD_ADJUSTED`
     (§5.5).

### 11.5 Colours

Probability colours follow §5.7. Status colours: `Waiting` = grey/white,
`Hit` = green, `Missed` = red, `Expired` = muted grey. Level-line colours
are in §13.1. No colour is used as the *only* carrier of meaning: every
colour-coded value also carries its text (%, `Hit`, category name).

---

## 12. File persistence format

### 12.1 Location and naming

- MT4 files folder: `MQL4\Files\ForexLevelRadarPro\`.
- Scoreboard: `Scoreboard_<Symbol>.csv` (e.g. `Scoreboard_EURUSD.csv`).
- Forecasts (open + finalised, for audit/replay): `Forecasts_<Symbol>.csv`.
- Sweep events: `Sweeps_<Symbol>.csv`.
- All files are plain UTF-8 CSV, comma-delimited, with a header row.
  No binary format, no proprietary encoding — the user must be able to
  open them in a spreadsheet.

### 12.2 Scoreboard CSV — exact format

Header (exact column order, exact names):

```
symbol,trading_day,level,session,day_of_week,forecast_time,cutoff_time,forecast_pct,observations,touches_at_forecast,forecast_prob,outcome,touch_time,brier_contribution,wilson_lower_pct,wilson_upper_pct,price_basis,touch_method,lookback_days,day_start_hour_utc,finalised_at
```

- `trading_day`, `forecast_time`, `cutoff_time`, `touch_time`,
  `finalised_at`: `YYYY.MM.DD HH:MM` in reference time. `touch_time` is
  empty when `outcome = 0`.
- `forecast_pct`, `wilson_lower_pct`, `wilson_upper_pct`: one decimal place.
- `forecast_prob`, `brier_contribution`: four decimal places.
- `day_start_hour_utc`: the `InpDayStartHourUTC` in force when the forecast
  was made — this is what prevents silent mixing across day-boundary
  settings (§6.1).
- One row per finalised forecast. Append-only. No row is ever rewritten.

`Forecasts_<Symbol>.csv` uses the same columns plus `status`
(`Waiting`/`Hit`/`Missed`) and `late_issued` (`0`/`1`, §9.2), and is
updated when a forecast is emitted and when it is finalised (the row is
replaced in *this* file only — the scoreboard file stays append-only).

`Sweeps_<Symbol>.csv` header:

```
symbol,event_time,excursion_time,level,level_price,event_kind,excursion_price,excursion_pips,confirmation_time,confirmation_bars,follow_through_pips
```

### 12.3 Load, save, and failure behaviour

- On load: parse the header first. If the header does not match §12.2
  exactly, do **not** load the file; log an error and start a new file
  named `Scoreboard_<Symbol>_v2.csv` (or the next free suffix). Never
  guess at a mismatched file's columns.
- On load: skip duplicate keys (§10.2 rule 1) and malformed rows; count
  and log both. Load the rest.
- On save: append the new row and flush (`FileFlush`) immediately, so a
  terminal crash loses at most the row in flight.
- `InpScoreboardDailyReset` (default `false`): when `true`, the in-memory
  scoreboard display resets at each trading-day start, but the CSV is
  **never** truncated by this option — the reset affects the display window
  only. Permanent deletion requires manual file deletion by the user.
- `InpExportScoreboard` (default `true`): when `false`, no CSV is written
  and the scoreboard is memory-only for the session (the dashboard shows
  `Memory only — not saved`).

---

## 13. Input settings catalogue

Every input below is a real MT4 `input` variable. Names are normative.
Defaults are the shipped values. Ranges are enforced at `OnInit()` —
see §13.6.

### 13.1 General

| Input | Type | Default | Range / values | Description |
|---|---|---|---|---|
| `InpIndicatorName` | string | `"Forex Level Radar Pro"` | — | Dashboard title and object prefix base |
| `InpDashboardEnabled` | bool | `true` | — | Show/hide the dashboard panel |
| `InpDashboardCorner` | enum | `CORNER_LEFT_UPPER` | MT4 corners | Dashboard anchor corner |
| `InpDashboardX` | int | `10` | 0–2000 | Horizontal offset from the corner (px) |
| `InpDashboardY` | int | `10` | 0–2000 | Vertical offset from the corner (px) |
| `InpDashboardFontSize` | int | `9` | 7–14 | Dashboard font size |
| `InpTheme` | enum | `Dark` | `Dark` / `Light` | Dashboard theme (§11.1) |
| `InpDashboardMinimised` | bool | `false` | — | Start minimised |
| `InpRefreshSeconds` | int | `5` | 0–60 (0 = no timer) | Dashboard refresh interval |
| `InpLookbackDays` | int | `100` | 5–500; presets 20/50/100/200 | Historical lookback (§5.2) |
| `InpMaxTableRows` | int | `7` | 1–17 | Max probability-table rows before scrolling |
| `InpShowAllLevelsInTable` | bool | `false` | — | Show all level rows, not just the default seven (§11.3) |
| `InpShowHistoricalLevels` | bool | `true` | — | Draw completed days' levels |
| `InpIntrabarUpdates` | bool | `false` | — | Intrabar visual refresh (§9.3) |

### 13.2 Levels — visibility and style

One `InpShow<LEVEL>` bool per level kind, all default `true` except
`InpShowPDO` (default `false`) and `InpShowDO` (default `true`):
`InpShowPDH`, `InpShowPDL`, `InpShowPDC`, `InpShowPDO`, `InpShowDO`,
`InpShowONH`, `InpShowONL`, `InpShowAsianHigh`, `InpShowAsianLow`,
`InpShowLondonHigh`, `InpShowLondonLow`, `InpShowLondonOpen`,
`InpShowNYHigh`, `InpShowNYLow`, `InpShowNYOpen`,
`InpShowORH`, `InpShowORL`.

Line colours/styles (defaults; user-changeable):

| Level group | Colour | Style | Width |
|---|---|---|---|
| PDH / PDL | Gold `#FFD700` / Orange `#FF8C00` | `STYLE_SOLID` | 1 |
| PDC / PDO / DO | White `#FFFFFF` / Grey `#808080` / Cyan `#00BFFF` | `STYLE_DOT` / `STYLE_DOT` / `STYLE_SOLID` | 1 |
| ONH / ONL | Violet `#8A2BE2` | `STYLE_DASH` | 1 |
| Asian High / Low | Dodger blue `#1E90FF` | `STYLE_DASH` | 1 |
| London High / Low / Open | Lime green `#32CD32` | `STYLE_SOLID` / `STYLE_SOLID` / `STYLE_DOT` | 1 |
| NY High / Low / Open | Magenta `#FF00FF` | `STYLE_SOLID` / `STYLE_SOLID` / `STYLE_DOT` | 1 |
| ORH / ORL | Yellow `#FFFF00` | `STYLE_SOLID` | 2 |

Chart-object naming (unique, cleaned up on deinit — §2.2):
`FLR_<Symbol>_<Kind>_<YYYYMMDD>` for level lines,
`FLR_<Symbol>_<Kind>_<YYYYMMDD>_LBL` for labels,
`FLR_DASH_*` for dashboard objects,
`FLR_EVT_<YYYYMMDDHHMMSS>_<Kind>` for sweep markers,
`FLR_SESS_<Session>_<YYYYMMDD>` for session-boundary lines.
No two objects ever share a name; `ObjectFind` is checked before
`ObjectCreate`, and stale objects with the `FLR_` prefix from a previous
run are deleted at init.

### 13.3 Sessions

| Input | Type | Default | Range / values | Description |
|---|---|---|---|---|
| `InpUseUTCReference` | bool | `true` | — | Use UTC as reference time (§6.3). If `false`, broker time is the reference (not recommended; sessions are then defined in broker time) |
| `InpBrokerOffsetHours` | double | `0.0` | −12…+14, step 0.5 | Broker server offset from UTC (§6.3) |
| `InpBrokerUsesDST` | bool | `false` | — | Broker observes DST |
| `InpBrokerDSTShiftHours` | double | `1.0` | 0…2 | DST shift applied in the DST period |
| `InpBrokerDSTRegion` | enum | `US` | `US` / `EU` / `None` | DST rule set (§6.3) |
| `InpAutoDetectBrokerOffset` | bool | `false` | — | One-time offset estimation at init (§6.3) |
| `InpDayStartHourUTC` | int | `0` | 0–23 | Trading-day start hour, reference time (§6.1) |
| `InpDayStartMinuteUTC` | int | `0` | 0–59 | Trading-day start minute |
| `InpAsianStartUTC` | string | `"00:00"` | `HH:MM` | Asian session start (§6.2) |
| `InpAsianEndUTC` | string | `"09:00"` | `HH:MM` | Asian session end |
| `InpLondonStartUTC` | string | `"07:00"` | `HH:MM` | London session start |
| `InpLondonEndUTC` | string | `"16:00"` | `HH:MM` | London session end |
| `InpNYStartUTC` | string | `"12:00"` | `HH:MM` | New York session start |
| `InpNYEndUTC` | string | `"21:00"` | `HH:MM` | New York session end |
| `InpUseCustomSessions` | bool | `false` | — | Replace the three sessions with custom ones (§6.2) |
| `InpCustomSession1Start/End` … `InpCustomSession3Start/End` | string | `""` (disabled) | `HH:MM` or empty | Custom session windows |
| `InpOpeningRangeSession` | enum | `New York` | `London` / `New York` / `Asian` / `DayStart` | Which session's open starts the opening range (§4.5) |
| `InpOpeningRangeMinutes` | int | `30` | 15 / 30 / 60 only | Opening-range duration (§4.5) |

Session times are stored as `HH:MM` strings (MT4 inputs have no time-of-day
type) and parsed strictly at init: exactly two digits, colon, two digits,
hour 00–23, minute 00–59.

### 13.4 Probability

| Input | Type | Default | Range / values | Description |
|---|---|---|---|---|
| `InpLookbackDays` | int | `100` | 5–500 (see §13.1) | Lookback in eligible trading days (§5.2) |
| `InpMinSampleSize` | int | `20` | 5–100 | Minimum N for a displayed probability (§5.3) |
| `InpEvaluationCutoffUTC` | string | `"21:00"` | `HH:MM` | Daily-level evaluation cutoff (§5.4) |
| `InpTouchMethod` | enum | `TOUCH_BID_ONLY` | §5.5 | Touch calculation method |
| `InpPriceBasis` | enum | `BASIS_BID` | `BASIS_BID` / `BASIS_ASK` / `BASIS_MID` | Price basis for levels (§5.5) |
| `InpSpreadAdjustment` | bool | `false` | — | Legacy alias: `true` ⇔ `InpTouchMethod = TOUCH_SPREAD_ADJUSTED`. Kept for preset compatibility; if both are set inconsistently, `InpTouchMethod` wins and a warning is logged |
| `InpCatVeryHigh` | int | `80` | 50–100 | Lower bound of Very High (%) |
| `InpCatHigh` | int | `65` | 40–99 | Lower bound of High (%) |
| `InpCatModerate` | int | `50` | 20–98 | Lower bound of Moderate (%) |
| `InpCatLow` | int | `30` | 1–97 | Lower bound of Low (%) |
| `InpSamplingMethod` | enum | `TradingDays` | `TradingDays` / `CalendarDays` | Historical sampling method. `TradingDays` (default): only days with bars count. `CalendarDays`: the lookback is a calendar window and days without bars count as misses — **not recommended**; it conflates "no trading" with "price did not touch" and is provided only for comparison. The scoreboard records which method produced each forecast |
| `InpShowWilsonInterval` | bool | `true` | — | Show Wilson interval in the detail view (§5.6) |

Category thresholds must satisfy
`InpCatVeryHigh > InpCatHigh > InpCatModerate > InpCatLow`; otherwise
`OnInit()` fails (§13.6).

### 13.5 Scoreboard

| Input | Type | Default | Range / values | Description |
|---|---|---|---|---|
| `InpScoreboardEnabled` | bool | `true` | — | Enable the scoreboard engine |
| `InpScoreboardPersistent` | bool | `true` | — | Write/read the CSV (§12). `false` = memory only |
| `InpScoreboardDailyReset` | bool | `false` | — | Reset the *display* window each trading day (§12.3) |
| `InpExportScoreboard` | bool | `true` | — | Write scoreboard CSV (§12.3) |
| `InpShowCalibration` | bool | `true` | — | Show calibration bins (§10.3) |
| `InpShowBrierScore` | bool | `true` | — | Show Brier score (§10.3) |

### 13.6 Alerts

| Input | Type | Default | Description |
|---|---|---|---|
| `InpAlertOnApproach` | bool | `false` | Alert when price comes within `InpApproachPips` of a level |
| `InpApproachPips` | double | `5.0` | Approach distance in pips (0.5–50) |
| `InpAlertOnTouch` | bool | `true` | Alert on a §7 touch |
| `InpAlertOnSweep` | bool | `true` | Alert on a classified sweep (§8) |
| `InpAlertOnBreakout` | bool | `true` | Alert on a classified breakout / failed breakout (§8) |
| `InpAlertOnOpeningRangeBreakout` | bool | `false` | Alert on an ORH/ORL breakout specifically |
| `InpAlertSound` | bool | `true` | Play sound (`PlaySound`) |
| `InpAlertPopup` | bool | `true` | Show `Alert()` popup |
| `InpAlertPush` | bool | `false` | Send push notification (`SendNotification`) |
| `InpAlertCooldownMinutes` | int | `15` | Minimum minutes between repeat alerts for the same level + alert type (1–1440). Prevents alert spam on choppy touches |

Alert rules: an alert fires **once per event** (a touch alerts once when
the level first becomes `Hit`, not on every subsequent candle that also
touches it). Approach alerts respect the cooldown; touch/sweep/breakout
alerts do not repeat for the same event at all. Alerts never fire for
historical/replay bars — only for the live, most recent bar.

### 13.7 Input validation (OnInit)

`OnInit()` returns `INIT_FAILED` (with a specific `Print` message) if any
of the following holds; it never silently substitutes a different value:

1. `InpLookbackDays` outside [5, 500].
2. `InpMinSampleSize` outside [5, 100], or `> InpLookbackDays`.
3. `InpOpeningRangeMinutes` not in {15, 30, 60}.
4. Any session start/end string malformed, or start == end.
5. `InpDayStartHourUTC` outside 0–23 or `InpDayStartMinuteUTC` outside 0–59.
6. `InpBrokerOffsetHours` outside −12…+14 or not a multiple of 0.5.
7. Category thresholds not strictly decreasing (§13.4).
8. `InpEvaluationCutoffUTC` malformed.
9. `InpRefreshSeconds` outside 0–60; `InpAlertCooldownMinutes` outside 1–1440.
10. `InpApproachPips` outside 0.5–50.

---

## 14. No-repaint / no-look-ahead invariants

These invariants are acceptance criteria (source spec §16, Tests 5 and 7).
A build that violates any of them fails acceptance, regardless of other
features.

- **I-1 — Completed levels are immutable.** Once a `LevelRecord` is final,
  its price never changes. (Tests: load history, record PDH for a past day,
  scroll forward 30 days, re-read PDH — identical.)
- **I-2 — Forecasts use only past data.** A forecast's probability is
  computed only from bars with open time `< forecastTime`. No bar at or
  after `forecastTime` contributes. (Test: recompute a past forecast from
  a truncated history ending at `forecastTime` — identical probability.)
- **I-3 — Classifications use only data available at classification time.**
  A sweep/breakout classification is made from closed candles up to the
  confirmation candle and is never revised when later candles arrive.
- **I-4 — Scoreboard rows are final.** A finalised `ScoreboardRecord`
  (and its CSV row) never changes. Later data cannot turn a recorded miss
  into a hit.
- **I-5 — No intrabar finalisation.** Ticks never finalise a level, a
  forecast, an event, or a scoreboard row. Only closed candles do.
- **I-6 — Replay equivalence.** Replaying history candle-by-candle from
  the oldest bar must produce the same forecasts, events, and scoreboard
  rows as the live run produced on the same bars (allowing only for
  `lateIssued` marking, §9.2). If replay and live disagree, the engine
  has look-ahead bias by construction.
- **I-7 — One forecast per level per day.** The deduplication key in
  §5.4 is enforced on emit, on load, and on CSV import.

### 14.1 Historical replay procedure (normative)

1. Start with an empty in-memory state (no levels, no forecasts, no events).
2. Feed bars in chronological order, one closed bar at a time, running
   Engines 1–5 exactly as `OnCalculate()` does on a new bar.
3. At each bar, apply the forecast-time rules of §5.4 as if that bar were
   "now": emit forecasts whose forecast time has been reached, finalise
   forecasts whose cutoff has passed.
4. Compare the replay's forecasts, events, and scoreboard rows with the
   live run's records. They must match exactly (same probabilities to one
   decimal, same outcomes, same event kinds and times).

### 14.2 Late-issued forecasts

If the terminal starts after a forecast time, the forecast is computed on
the first available bar **from the truncated history ending at the forecast
time** (per I-2), marked `lateIssued`, and scored normally. This keeps the
scoreboard complete without introducing look-ahead.

---

## 15. Multi-pair support

Supported pairs (initial configuration, exactly as in source spec §11):

```
EURUSD, GBPUSD, USDJPY, USDCHF, USDCAD, AUDUSD, NZDUSD,
EURGBP, EURJPY, GBPJPY, AUDJPY, CADJPY, CHFJPY, EURAUD, GBPAUD
```

- The indicator is attached to **one chart (one pair)** and computes that
  pair fully. That is the primary mode and the only mode required for
  acceptance.
- **Optional multi-pair dashboard** (`InpMultiPairDashboard`, default
  `false`): when enabled, the dashboard adds one row per pair from
  `InpMultiPairList` (default = the 15 pairs above, comma-separated) showing
  that pair's PDH probability and status. It uses `iHigh`/`iLow`/`iClose`
  on the other symbols and requires their history to be loaded; a pair
  whose history is not loaded shows `NO DATA`, never a copied value from
  another pair.
- **Additional symbols:** `InpExtraSymbols` (string, comma-separated,
  default `""`) adds pairs beyond the 15. Each extra symbol is validated
  (`MarketInfo(symbol, MODE_BID) > 0` or history exists); an invalid symbol
  is logged and skipped, and never blocks the other pairs.
- **Do not assume identical pairs.** Trading hours, spreads, volatility,
  digit counts, and session behaviour differ per pair (JPY pairs in
  particular have different pip sizes and often different liquidity
  around Tokyo hours). Every calculation is per symbol, from that symbol's
  own bars and spread. No parameter is shared across symbols except the
  user's inputs.
- Scoreboard files are per symbol (§12.1). There is no cross-pair
  scoreboard merge; an "all pairs" view is computed by reading the
  per-symbol files and labelling each row with its symbol.

---

## 16. Visual chart implementation

- Chart objects: horizontal level lines (`OBJ_HLINE` for daily levels,
  `OBJ_TREND` ray segments for session levels bounded to their window),
  level labels (`OBJ_TEXT`), probability text near the current price,
  session-boundary vertical lines (`OBJ_VLINE` at each session start),
  sweep markers (`OBJ_ARROW` + `OBJ_TEXT`), opening-range boundary
  rectangle (`OBJ_RECTANGLE` over the OR window).
- Every object name follows §13.2 and carries the `FLR_` prefix.
- On timeframe or symbol change, all `FLR_` objects are deleted and
  rebuilt from the cached records — never left pointing at stale prices.
- On `OnDeinit()`, all `FLR_` objects are deleted. A chart must be left
  exactly as it was before the indicator was attached, except for the
  user's own objects.
- Clutter rule: at most one label per level per day; historical levels
  older than the lookback are not drawn unless `InpShowHistoricalLevels`
  is true, and then only the daily levels (PDH/PDL/PDC), not every session
  level, to keep the chart readable.

---

## 17. Testing cross-reference

Each test from source spec §16 maps to this specification as follows:

| Test | What it verifies | Governing section(s) |
|---|---|---|
| TEST 1 — Key Levels | PDH/PDL/session high/low arithmetic | §4, §6 |
| TEST 2 — Session Boundaries | UTC conversion, broker offset, DST | §6.2–§6.3 |
| TEST 3 — Probability | Manual recomputation vs. engine | §5, `Probability_Methodology.md` |
| TEST 4 — Sample Size | INSUFFICIENT DATA behaviour | §5.3 |
| TEST 5 — No Repainting | Final levels/forecasts unchanged | §14 (I-1, I-4, I-5) |
| TEST 6 — Scoreboard | Touch/miss classification | §7, §10 |
| TEST 7 — Historical Replay | No future data in forecasts | §14.1 (I-2, I-6) |
| TEST 8 — Restart Persistence | CSV survives restart | §12 |
| TEST 9 — Multi-Pair | All 15 pairs compute | §15 |
| TEST 10 — Performance | Speed / memory | §2.3 |
| TEST 11 — Alerts | Each alert condition | §13.6 |
| TEST 12 — Compilation | Zero errors | §2.2, §13.6 |

---

## 18. Open design decisions (locked in Phase 1)

These points were ambiguous in the source spec and are decided here so the
implementation has one answer. Changing any of them requires amending this
document and `Probability_Methodology.md` together.

1. **Opening range = New York open by default** (§4.5), configurable to
   London / Asian / DayStart.
2. **Overnight window = 21:00 UTC previous day → 07:00 UTC current day**
   (§4.2). It overlaps the Asian session by design.
3. **Daily evaluation cutoff = 21:00 UTC** (New York close) by default
   (§5.4); session cutoffs equal their session ends.
4. **Default touch method = Bid only, no spread adjustment** (§5.5), so
   historical probabilities are exactly reproducible from bar history.
5. **Default lookback = 100; default minimum sample = 20** (§5.2–§5.3).
6. **Sweep = wick-only excursion with close back inside; failed breakout
   = close beyond then close back inside** (§8.2–§8.3). The two are
   mutually exclusive by construction.
7. **Neutral levels (opens/closes) count a touch when the bar's range
   contains the level** (§7) — `High >= level` **and** `Low <= level`.
   The level can be reached from either side, but one side alone is not
   a touch (the earlier wording "from either side" was corrected in the
   2026-11-27 errata; see §7).
8. **Scoreboard CSV is append-only; daily reset affects the display only**
   (§12.3).
9. **Reference time is UTC; broker offset + DST are conversions applied
   once, at bar selection** (§6.3).
10. **The Nov 26 source-spec example scoreboard numbers are illustrative
    only** (§10.3) and are not targets.

---

## 19. Document control

| Version | Date | Change |
|---|---|---|
| 1.0 | 2026-11-27 | Phase 1 initial issue. Companion: `Probability_Methodology.md` v1.0. |
| 1.0 + errata | 2026-11-27 | Neutral-touch rule corrected (OR → AND) in §7 and §18 item 7; errata note added. No other change. |

*End of Technical Specification — FLR-MT4-001 v1.0.*
