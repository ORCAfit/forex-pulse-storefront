# Forex Level Radar Pro — Installation Guide

| Field | Value |
|---|---|
| Project ID | FLR-MT4-001 |
| Product | Forex Level Radar Pro |
| Platform | MetaTrader 4 (MT4), MQL4, `#property strict` |
| Version | 1.0 |
| Source file | `Forex_Level_Radar_Pro.mq4` (1,774 lines) |
| Companion documents | `Technical_Specification.md`, `Probability_Methodology.md`, `User_Manual.md`, `Technical_Architecture.md`, `Backtesting_Protocol.md`, `Source_Code_Documentation.md` |

> **What this indicator is.** Forex Level Radar Pro is an **analytical indicator only**.
> It never places, modifies, or closes trades. The source contains no
> `OrderSend`, `OrderModify`, `OrderClose`, or `OrderDelete`, no DLL imports,
> no `WebRequest`, and no paid third-party service. It draws levels, computes
> historical touch probabilities, watches for liquidity sweeps, and keeps a
> persistent scoreboard. Nothing in it is a trading signal.

---

## 1. Requirements

| Requirement | Detail |
|---|---|
| Terminal | MetaTrader 4, **build 600 or newer** (the source uses `#property strict` and `input group`, which do not exist on older builds) |
| Operating system | Windows (MT4 desktop). The indicator runs inside the MT4 terminal; it has no standalone installer |
| Chart | Any Forex symbol, any chart timeframe (see §5 — the timeframe you attach to controls only the *display* refresh; all level and probability math scans H1 bars) |
| History | **H1 (1-hour) history** for the chart symbol, covering at least the lookback you choose plus a margin. With the default lookback of 100 days, load at least ~120 trading days of H1 bars (about 2,900 bars). With a 200-day lookback, load ~220 days (about 5,300 bars). See §5 |
| Bars on chart | At least **50 bars** on the chart timeframe, or `OnInit()` returns `INIT_FAILED` and the indicator will not attach |
| Disk | Negligible. Scoreboard CSVs are a few kilobytes each, in `MQL4/Files/` |

No extra libraries, DLLs, or accounts are needed. The indicator works on a
demo or live terminal identically — it reads price history only.

---

## 2. Installation — copy the source file

1. In MT4, open **File → Open Data Folder**.
2. Navigate to `MQL4/Indicators/`.
3. Copy `Forex_Level_Radar_Pro.mq4` into that folder. Do **not** put it in
   `MQL4/Experts/` — it is an indicator (`#property indicator_chart_window`),
   not an Expert Advisor, and it will not run from the Experts folder.
4. If you are replacing an older copy, close any chart that already has the
   indicator attached first, then overwrite the file.

There is no `.ex4` shipped with this package unless one was compiled on a
machine with a compatible MT4 compiler. The `.mq4` is the deliverable; §3
compiles it in your own terminal. Do not claim an `.ex4` exists unless it
was actually produced by MetaEditor.

---

## 3. Compiling in MetaEditor

1. In MT4, press **F4** (or Tools → MetaQuotes Language Editor) to open
   MetaEditor.
2. In MetaEditor's Navigator, expand **Indicators** and double-click
   `Forex_Level_Radar_Pro`.
3. Press **F7**, or click **Compile** on the toolbar.
4. Check the **Errors** tab at the bottom:
   - **Expected result: 0 errors, 0 warnings.**
   - If the compile reports errors, do not attach the indicator. The usual
     cause is an MT4 build older than 600 — check **Help → About** in the
     terminal and update MT4 first. Do not edit the source to silence an
     error unless you know exactly what the error means.
5. A successful compile creates `Forex_Level_Radar_Pro.ex4` in the same
   `MQL4/Indicators/` folder. Close MetaEditor.

> **Note on warnings.** `ValidateInputs()` prints informational messages to
> the Experts log when an input is outside its recommended range (see
> §6.4). Those are runtime log lines, not compiler warnings, and they do
> not stop the indicator.

---

## 4. Attaching to a chart

1. Open a chart for the symbol you want to analyse (e.g. EURUSD). Any
   timeframe works — H1 is a good default because it matches the scan
   timeframe (see §5) — but M15, H4, and D1 are all fine.
2. In the Navigator (**Ctrl+N** → Indicators), double-click
   **Forex_Level_Radar_Pro**, or drag it onto the chart.
3. The Inputs tab opens. All inputs are grouped (General, Levels,
   Sessions, Probability, Scoreboard, Alerts, Multi-Pair Scan). The
   defaults are a working configuration — you can attach with defaults and
   change settings later. The full input catalogue, with every default, is
   in `Source_Code_Documentation.md` §3 and summarised in §6 below.
4. Click **OK**. The indicator name appears in the top-left of the chart,
   level lines appear, and the dashboard panel appears at the top-left
   corner by default.

To change settings afterwards: right-click the chart → **Indicators List**
(**Ctrl+I**) → select Forex Level Radar Pro → **Edit**. Changing an input
forces a full recalculation from history (see `Technical_Architecture.md`
§6). To remove the indicator: same list → **Delete**. Removal deletes
every chart object the indicator created (all objects are prefixed `FLR_`);
it does **not** delete the scoreboard CSV files.

### 4.1 First-run checklist

After attaching, verify the following before trusting the display:

- [ ] The dashboard title reads **FOREX LEVEL RADAR PRO**.
- [ ] PAIR and TIMEFRAME match the chart.
- [ ] SESSION shows Asian, London, or New York during market hours, and
      MARKET STATUS shows **Active**.
- [ ] PDH / PDL / PDC show prices (not `--`). If they show `--`, the
      previous trading day has no H1 bars — see §5 and §7.
- [ ] The probability table shows percentages with `N=…`. If it shows
      `INSUFFICIENT DATA`, the lookback has fewer eligible days than
      `InpMinSample` (default 20) — see §5 and §7.
- [ ] The Experts tab (**Ctrl+T** → Experts) shows the line
      `FLR: Forex Level Radar Pro initialised on <SYMBOL> <TF> | lookback=…
      minSample=… brokerGMT+… dayStart=…:00`. If it shows an error instead,
      see §7.

---

## 5. Chart setup and history — read this first

This is the step most often done wrong, and it is the cause of nearly every
"the indicator shows nothing" report.

### 5.1 All aggregation scans H1 bars

Every level and every probability in v1.0 is computed by scanning
**PERIOD_H1 bars** (`ScanHighLow()`, `TouchInWindow()`), regardless of the
chart timeframe. An H1 bar's high/low are the true extremes of that hour,
so daily and session highs/lows are exact while the scan stays cheap. The
practical consequences:

- The **chart timeframe only affects display refresh** (new-bar detection
  and the live price/distance labels). It does not change any level price
  or any probability.
- You need **H1 history**, not history on the chart timeframe. Attaching
  to an M15 chart with plenty of M15 bars but only a few days of H1 bars
  will still produce `INSUFFICIENT DATA`.
- The opening range is the one place the chart timeframe matters
  indirectly: the opening range is scanned on H1 bars too, so a 15-minute
  opening range is resolved from H1 bars whose open time falls inside the
  15-minute window. On most brokers there is exactly one H1 bar opening
  inside a 15-minute window, so a 15-minute ORH/ORL is effectively that
  bar's high/low. The 30- and 60-minute settings are better resolved.

### 5.2 Loading enough H1 history

1. Open an **H1 chart** of the symbol.
2. Press **Home** repeatedly, or drag the chart's left edge, to scroll back
   until the chart stops loading older bars. Alternatively use
   **Tools → History Center (F2)** → select the symbol → **1 Hour** →
   **Download**. (On some brokers the Download button is disabled; scrolling
   back is then the way to load history.)
3. As a rule of thumb, load **at least the lookback plus 20 extra trading
   days**: 120 days for the default lookback of 100, 220 days for a
   lookback of 200.
4. Check the bar count: hover the chart and read the status, or open the
   Experts log — if the probability table still shows `INSUFFICIENT DATA`
   with a small N (e.g. `N=14`), you simply do not have enough eligible H1
   days yet. Ineligible days (holidays, history gaps) do not count toward
   the lookback, so a "100-day lookback" can span more than 100 calendar
   days.
5. Repeat for every symbol you attach the indicator to, and for every
   symbol in the multi-pair scan list (`InpScanSymbols`) if you enable the
   scan — the scan skips any symbol with fewer than 100 H1 bars and shows
   `-- (no data)` for it.

### 5.3 Recommended chart setup

| Setting | Recommendation | Why |
|---|---|---|
| Timeframe | H1 | Matches the scan timeframe; new-bar recalculation happens hourly, which is frequent enough for daily/session levels |
| Chart | Candlesticks, grid off (optional) | Level lines and labels stay readable |
| Max bars in chart | Tools → Options → Charts → **Max bars in chart: 100,000** (or at least 10,000) | MT4 truncates history at this limit; the default is often enough for 200 days of H1, but raising it removes a silent cause of short history |
| Max bars in history | Same panel, **1,000,000** | Same reason, for the stored history file |

### 5.4 Timezone / broker offset — set this before judging any level

Session windows are defined in **UTC** (Asian 00:00–09:00, London
07:00–16:00, New York 12:00–21:00 by default) and converted to broker time
using `InpBrokerGMTOffset` (default **0**) plus a DST shift
(`InpDSTMode`, default **AUTO** — approximate northern-hemisphere DST,
applied in April–October; see `Source_Code_Documentation.md` §2.1 for the
exact rule and its limits).

- Find your broker's GMT offset from the terminal clock: compare the time
  shown in MT4's Market Watch with UTC at a known moment, or check your
  broker's documentation. Common values are +2 (winter) / +3 (summer) for
  many retail brokers.
- If the offset is wrong, **every session level is shifted by the error** —
  the levels will be computed from the wrong hours. There is no warning for
  a wrong-but-in-range offset; the only check is that the session shown on
  the dashboard matches the real session at the time you look at it.
- `InpUseUTCReference = false` disables the offset entirely (broker time is
  treated as UTC). Only use this if your broker server genuinely runs on
  UTC.
- The trading day starts at `InpDayStartHour` **broker time** (default
  0 = midnight broker time), and the evaluation cutoff is
  `InpCutoffHour` hours after the trading-day start (default 21). These
  are broker-time settings in the code, even though the design documents
  describe them in UTC — set them in broker time.

---

## 6. Configuration quick reference

Defaults are the shipped configuration. Every input is documented in full
in `Source_Code_Documentation.md` §3; this table is the short version.

| Group | Key inputs | Default |
|---|---|---|
| General | `InpShowDashboard`, `InpDashCorner` / `InpDashX` / `InpDashY`, `InpTheme`, `InpRefreshSeconds`, `InpHistoryDays` | Dashboard on, top-left, (10, 15), Dark, **5 s**, 200 days |
| Levels | `InpShowPDH` … `InpShowORHL`, `InpShowPriorDay` | All on except PDO (off) |
| Sessions | `InpBrokerGMTOffset`, `InpDSTMode`, session start/end UTC hours, `InpDayStartHour`, `InpOpeningRangeMinutes`, custom session | Offset 0, DST Auto, Asian 0–9, London 7–16, NY 12–21, day start 0, OR 30 min |
| Probability | `InpProbLookback`, `InpMinSample`, `InpCutoffHour`, `InpTouchMethod`, `InpSpreadAdjPoints`, thresholds | Lookback **100**, min sample **20**, cutoff 21, High/Low touch, 0.0 pts, 80/65/50/30 |
| Scoreboard | `InpEnableScoreboard`, `InpPersistentStorage`, `InpDailyReset`, `InpExportCSV`, `InpShowCalibration` | On, on, off, on, on |
| Alerts | `InpAlertApproach` / `Touch` / `Sweep` / `ORBreakout`, sound/popup/push, `InpApproachPoints`, `InpConfirmBars`, `InpBreakoutBars` | Approach off, touch/sweep on, OR breakout off, sound+popup on, push off, 100 pts, 3, 3 |
| Multi-pair scan | `InpEnableScan`, `InpScanSymbols` | **Off**, the 15 pairs from the spec |

Three ready-made presets are shipped in `presets/` — `FLR_Standard.set`
(the defaults), `FLR_Conservative.set`, and `FLR_Aggressive.set`. To load
one: attach the indicator, click **Load** in the Inputs tab, select the
`.set` file. Only inputs that exist in the code are present in those files.

### 6.1 Settings that fail initialisation

`OnInit()` refuses to start (and prints the reason to the Experts log) if:

- `InpProbLookback` outside 5–500, or `InpMinSample` outside 5–100 or
  greater than `InpProbLookback` → `INIT_PARAMETERS_INCORRECT`
- `InpOpeningRangeMinutes` not in {15, 30, 60} →
  `INIT_PARAMETERS_INCORRECT`
- Probability thresholds not strictly descending →
  `INIT_PARAMETERS_INCORRECT`
- `InpBrokerGMTOffset` outside −12…+14, or `InpDSTShiftHours` outside
  0–2 → `INIT_PARAMETERS_INCORRECT`
- `InpApproachPoints` outside 1–1000 → `INIT_PARAMETERS_INCORRECT`
- `InpRefreshSeconds` outside 1–600 → `INIT_PARAMETERS_INCORRECT`
- `InpDayStartHour` outside 0–23, or `InpCutoffHour` outside 1–24 →
  `INIT_PARAMETERS_INCORRECT`
- Fewer than 50 bars on the chart → `INIT_FAILED`

Other out-of-range values do **not** stop the indicator; `ValidateInputs()`
prints a warning and the code uses the value as-is (or clamps it inside the
calculation — e.g. lookback below 5 is treated as 5, minimum sample below 5
as 5). The full hard-fail list is in `Source_Code_Documentation.md` §2.5.

### 6.2 A note on `InpHistoryDays`

`InpHistoryDays` (default 200) is accepted as an input but is **not used by
any calculation in v1.0** — no function reads it. The effective history
requirement is driven by `InpProbLookback` (and the extra day needed for
forecast levels). Changing `InpHistoryDays` alone changes nothing. It is
documented here so nobody mistakes it for a history control.

---

## 7. Where files land

| File | Location | When it is written |
|---|---|---|
| Scoreboard | `MQL4/Files/FLR_Scoreboard_<SYMBOL>.csv` | One row per level per finalised trading day, appended at the next day rollover after the cutoff has passed (see `User_Manual.md` §6). One file per symbol |
| Scoreboard summary | `MQL4/Files/FLR_Scoreboard_Summary_<SYMBOL>.csv` | Only when you click **[Export]** on the scoreboard panel |
| Compiled indicator | `MQL4/Indicators/Forex_Level_Radar_Pro.ex4` | On compile in MetaEditor |

To open the data folder quickly: **File → Open Data Folder** in MT4, then
`MQL4/Files/`. The scoreboard CSV format (header `Date,Level,ForecastPct,N,Touched,DOW`)
is specified in `Technical_Architecture.md` §5 and illustrated by the
shipped `Sample_Scoreboard.csv` in the project root — note that the sample
file is labelled EXAMPLE and contains invented numbers, not real results.

**Do not edit a scoreboard CSV while MT4 is running.** The indicator loads
the file once at `OnInit()` and appends to it; hand-editing it mid-session
will be overwritten or ignored, and deleting rows the indicator has already
loaded will not remove them from the in-memory totals until the indicator
is re-attached. If you must reset the scoreboard, remove the indicator,
delete (or rename) the CSV, then re-attach.

---

## 8. Troubleshooting

### 8.1 Indicator does not appear in the Navigator / will not attach

- **Cause:** the `.mq4` is in the wrong folder, or the compile failed.
- **Fix:** confirm the file is in `MQL4/Indicators/` (not `Experts/`).
  Recompile with F7 and read the Errors tab — 0 errors expected. If the
  Navigator still does not list it, right-click Navigator → **Refresh**,
  or restart MT4. Check **Help → About**: the build must be 600+.

### 8.2 "Not enough bars on chart" in the Experts log / indicator silently absent

- **Cause:** fewer than 50 bars on the chart timeframe (`OnInit()` returns
  `INIT_FAILED`).
- **Fix:** load more history on that chart/timeframe (§5.2), or attach to a
  chart with more bars. This is not a code fault.

### 8.3 Dashboard shows `--` for levels, or levels are missing

- **Cause:** the source window for that level contains no H1 bars.
  - PDH/PDL/PDC/PDO `--` means the previous trading day has no H1 bars
    (short history, or a holiday with no trading).
  - London/NY levels `--` before their session starts is normal — the
    level does not exist yet that day. London levels appear from 07:00 UTC,
    New York from 12:00 UTC.
  - ORH/ORL `--` means the opening-range window (first 30 minutes after
    the trading-day start, by default) contains no H1 bar.
- **Fix:** load more H1 history (§5.2). If the level is a session level
  and the session has not started yet, wait — this is correct behaviour,
  not a fault.

### 8.4 Probability table shows `INSUFFICIENT DATA`

- **Cause:** fewer than `InpMinSample` (default **20**) eligible days in
  the lookback. The display shows `INSUFFICIENT DATA` with the actual N
  (e.g. `N=14`) instead of a percentage. This is by design — a probability
  from too few observations is not shown.
- **Fix:** load more H1 history (§5.2), lower `InpMinSample` (not below 10
  without understanding the consequence — see `Probability_Methodology.md`
  §6), or shorten `InpProbLookback`. The shipped default minimum sample
  is **20**, matching the Phase 1 design documents.

### 8.5 Probabilities look wrong / session levels look shifted

- **Cause (most likely):** wrong broker GMT offset or DST setting (§5.4).
  Session windows are UTC converted to broker time; an offset error of
  one hour shifts every session level by one hour.
- **Fix:** verify `InpBrokerGMTOffset` and `InpDSTMode` against your
  broker. Check the dashboard SESSION field against the real time: at
  13:00 UTC the dashboard should say **New York** (NY takes priority over
  London when windows overlap). If it says London at 13:00 UTC, the offset
  is wrong.
- **Other cause:** the chart symbol's H1 history has gaps (holidays,
  broker history holes). Days with missing bars in the relevant window are
  excluded from the probability denominator — that is correct, but it
  reduces N.

### 8.6 Dashboard is off-screen / cannot be seen

- The dashboard is a set of chart objects anchored to `InpDashCorner`
  plus `InpDashX` / `InpDashY`. It is **not draggable by mouse** in v1.0
  (the design documents describe dragging; the code positions the panel
  only from the inputs — there is no drag handler in `OnChartEvent()`).
- **Fix:** open the indicator inputs and change `InpDashCorner`
  (e.g. `CORNER_LEFT_UPPER` → `CORNER_RIGHT_UPPER`) or reduce
  `InpDashX` / `InpDashY` until the 322-pixel-wide panel fits. If the
  panel was hidden with the **[x]** button, it cannot be brought back from
  the chart — remove and re-attach the indicator.
- The panel is 322 px wide and 556 px tall (expanded); the scoreboard
  panel sits directly below it at Y + 566. On a small chart window the two
  panels can cover most of the chart — minimise them with **[-]** or move
  them with `InpDashX` / `InpDashY`.

### 8.7 Objects left on the chart after removing the indicator

- **Expected behaviour:** `OnDeinit()` calls `DeleteAllObjects()`, which
  deletes every object whose name starts with `FLR_`. If objects remain,
  MT4 was closed abnormally or the indicator was removed while the
  terminal was busy.
- **Fix:** right-click the chart → **Objects List (Ctrl+B)** → select
  objects starting with `FLR_` → **Delete**. Or delete them by prefix from
  the Objects List using the list's filter. Never delete another
  indicator's objects by accident — only `FLR_` objects belong to this
  indicator.

### 8.8 Alerts are not firing / are firing too often

- Alerts are **throttled to at most once per hour per level per alert
  type** (approach, touch, sweep, OR breakout each have their own
  last-alert timestamp). This is deliberate — without it, an approach
  alert would fire on every tick while price sits near a level.
- Push notifications require MT4 push to be configured
  (**Tools → Options → Notifications → Enable Push Notifications** with a
  MetaQuotes ID) and `InpAlertPush = true` (default **false**).
- Sound alerts play `alert.wav` from the terminal's `Sounds/` folder.
  If the file is missing, the popup still appears but there is no sound.
- Approach alerts use the **live Bid** and `InpApproachPoints` (default
  100 points — note: *points*, not pips; on a 5-digit symbol 100 points =
  10 pips). Touch alerts are evaluated on the **last closed bar**
  (`High[1]`/`Low[1]`/`Close[1]`), tested direction-aware: upward levels
  by the bar's High, downward levels by its Low, neutral levels by the
  bar's range containing the level.

### 8.9 Scoreboard file is empty / has fewer rows than expected

- Rows are written only when a trading day is **finalised**: at the next
  day rollover *after* that day's cutoff (`InpCutoffHour`, default 21:00
  broker time) has passed. A day's 7 rows appear together, the following
  morning — not during the day itself. Open forecasts are held in memory
  only.
- If the terminal was off at the rollover, finalisation happens on the
  first recalculation after restart, provided the cutoff has passed by then.
- If `InpEnableScoreboard`, `InpPersistentStorage`, or `InpExportCSV` is
  `false`, `AppendScoreboardRow()` writes nothing. All three must be true
  for rows to be appended. (`InpExportCSV` gates both the per-row append
  and the summary export in v1.0, despite its name.)
- Rows are deduplicated by the key `Date|Level` — a day/level is written
  at most once, even across restarts. If a row already exists, the
  duplicate is silently skipped. This is what prevents double-counting,
  not a fault.

### 8.10 Terminal restarts / timeframe changes

- Restarting MT4 is safe: `OnInit()` reloads the scoreboard CSV into
  memory, so finalised rows survive. Open (unfinalised) forecasts are
  re-derived from history on the next calculation.
- Changing timeframe or symbol forces a full recalculation. Finalised
  scoreboard rows are **not** recomputed or altered by this — only the
  live display is rebuilt.
- Changing any input also forces a full recalculation. Changing the
  day-start hour, cutoff, lookback, or touch method changes future
  forecasts; it never rewrites rows already in the CSV. Note the design
  documents require a new scoreboard file when the day-start setting
  changes; v1.0 does **not** do this — rows computed under different
  settings accumulate in the same per-symbol file. If you change a
  structural setting (day start, cutoff, touch method, lookback), start a
  fresh scoreboard: remove the indicator, rename the old CSV
  (e.g. `FLR_Scoreboard_EURUSD_lookback100.csv`), and re-attach.

---

## 9. Uninstalling

1. Remove the indicator from every chart (Indicators List → Delete).
2. Delete `Forex_Level_Radar_Pro.mq4` and `.ex4` from `MQL4/Indicators/`.
3. Optionally delete the scoreboard CSVs from `MQL4/Files/` (they are
   yours — the indicator never deletes them itself).
4. Restart MT4 to clear the Navigator entry.

---

## 10. Version note — where v1.0 differs from the Phase 1 design documents

The implementation is the authority for behaviour. Where the code and the
Phase 1 documents (`Technical_Specification.md`,
`Probability_Methodology.md`) differ, the code governs and the difference
is recorded here so it is not mistaken for a bug:

| Area | Design documents | v1.0 code (actual) |
|---|---|---|
| Minimum sample default | 20 | **20** (`InpMinSample`) — aligned in the 2026-11-27 QA pass |
| Dashboard refresh default | 5 s | **5 s** (`InpRefreshSeconds`) — aligned in the 2026-11-27 QA pass |
| Opening range source | First 15/30/60 min of the New York session | First `InpOpeningRangeMinutes` after the **trading-day start** |
| Overnight high/low | 21:00–07:00 UTC window | **Same as the Asian session** high/low for the day |
| Touch methods | Bid-only / spread-adjusted / Ask-based | **High/Low** or **Close** (`InpTouchMethod`); spread adjustment is a points value that *widens* the touch zone |
| Wilson 95% interval | Computed and stored per forecast | **Not computed** in v1.0 |
| Failed-breakout classification | Defined (close beyond, then close back within 3 bars) | **Guard implemented, class not recorded** — a close beyond followed by a close back inside is recognised as a failed breakout (state cleared, no sweep recorded), but no failed-breakout event is stored |
| Dashboard dragging | Draggable by title bar | **Not draggable** — position from `InpDashCorner`/`InpDashX`/`InpDashY` only |
| `InpHistoryDays` | History limit | Declared but **unused** |
| Day-start change | New scoreboard file on change | Same file continues; start a fresh file manually (§8.10) |

These are documented limitations of v1.0, not installation faults. Do not
"fix" them by editing the installed copy — record them as change requests
against the project.

---

*End of Installation Guide — FLR-MT4-001 v1.0.*
