# Sample_Scoreboard.csv — EXAMPLE FILE, NOT REAL RESULTS

**All numbers in `Sample_Scoreboard.csv` are invented example values.
They are not results from the indicator, not backtest results, and not
performance claims of any kind.**

## What this file is

An illustration of the exact file format the indicator writes to
`MQL4/Files/FLR_Scoreboard_<SYMBOL>.csv` (one file per symbol), so you can
see the columns, the date format, and the value ranges before the
indicator has finalised any real forecasts.

## Format (identical to what the indicator writes)

```
Date,Level,ForecastPct,N,Touched,DOW
```

| Column | Format | Meaning |
|---|---|---|
| `Date` | `yyyy.mm.dd` | Trading day the forecast applied to |
| `Level` | `PDH` / `PDL` / `PDC` / `ONH` / `ONL` / `ORH` / `ORL` | Forecast level |
| `ForecastPct` | number, 2 decimal places | Frozen forecast probability (%) at that day's start |
| `N` | integer | Eligible observations behind the forecast |
| `Touched` | `0` / `1` | Outcome: `1` = touched before the cutoff, `0` = not touched |
| `DOW` | integer 0–6 | Day of week of the trading day (0 = Sunday … 6 = Saturday, MQL4 `TimeDayOfWeek()`) |

The file contains a header row plus 15 example rows across 5 trading days
(2026-11-23 to 2026-11-27) and all 7 probability levels. The `N` values
below 100 (98, 99) illustrate days on which some lookback days were
ineligible and therefore did not consume a lookback slot.

## Do not use this file as a scoreboard

- Do **not** copy it into `MQL4/Files/` and present it as the indicator's
  record. The indicator would load it and treat the invented rows as
  finalised forecasts.
- Do **not** quote its forecast or touch-rate numbers as the indicator's
  performance. They were made up for format illustration.
- If you want to check the format against a real file, let the indicator
  run live for a few days and open the real
  `FLR_Scoreboard_<SYMBOL>.csv` it creates instead.

See `docs/Technical_Architecture.md` §5 for the full persistence
specification, and `docs/Backtesting_Protocol.md` §6 for how to validate a
real scoreboard file against raw history.
